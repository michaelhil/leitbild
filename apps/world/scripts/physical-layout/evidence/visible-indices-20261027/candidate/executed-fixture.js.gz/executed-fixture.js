// ../../../Leitbild-campus-integration/node_modules/.bun/earcut@3.2.3/node_modules/earcut/src/earcut.js
var steiners = new Set;
var filteredOut = false;
function earcut(data, holeIndices, dim = 2) {
  const hasHoles = holeIndices && holeIndices.length;
  const outerLen = hasHoles ? holeIndices[0] * dim : data.length;
  if (steiners.size)
    steiners.clear();
  let outerNode = linkedList(data, 0, outerLen, dim, true);
  const triangles = [];
  if (!outerNode || outerNode.next === outerNode.prev)
    return triangles;
  let minX = 0, minY = 0, invSize = 0;
  if (hasHoles)
    outerNode = eliminateHoles(data, holeIndices, outerNode, dim);
  if (data.length > 80 * dim) {
    minX = data[0];
    minY = data[1];
    let maxX = minX;
    let maxY = minY;
    for (let i = dim;i < outerLen; i += dim) {
      const x = data[i];
      const y = data[i + 1];
      if (x < minX)
        minX = x;
      if (y < minY)
        minY = y;
      if (x > maxX)
        maxX = x;
      if (y > maxY)
        maxY = y;
    }
    invSize = Math.max(maxX - minX, maxY - minY);
    invSize = invSize !== 0 ? 32767 / invSize : 0;
  }
  earcutLinked(outerNode, triangles, minX, minY, invSize);
  return triangles;
}
function linkedList(data, start, end, dim, clockwise) {
  let last = null;
  if (clockwise === signedArea(data, start, end, dim) > 0) {
    for (let i = start;i < end; i += dim)
      last = insertNode(i / dim | 0, data[i], data[i + 1], last);
  } else {
    for (let i = end - dim;i >= start; i -= dim)
      last = insertNode(i / dim | 0, data[i], data[i + 1], last);
  }
  if (last && equals(last, last.next)) {
    removeNode(last);
    last = last.next;
  }
  return last;
}
function filterPoints(start, end = start) {
  const full = end === start;
  let p = start, again;
  do {
    again = false;
    if (p !== p.next && (steiners.size === 0 || !steiners.has(p)) && (equals(p, p.next) || area(p.prev, p, p.next) === 0)) {
      if (full || p === end)
        end = p.prev;
      filteredOut = true;
      removeNode(p);
      p = p.prev;
      again = true;
    } else if (full || p !== end) {
      p = p.next;
      again = !full;
    }
  } while (again || p !== end);
  return end;
}
function earcutLinked(ear, triangles, minX, minY, invSize) {
  if (invSize)
    indexCurve(ear, minX, minY, invSize);
  let stop = ear, cured = false;
  while (ear.prev !== ear.next) {
    const prev = ear.prev;
    const next = ear.next;
    if (area(prev, ear, next) < 0 && (invSize ? isEarHashed(ear, minX, minY, invSize) : isEar(ear))) {
      triangles.push(prev.i, ear.i, next.i);
      removeNode(ear);
      ear = next;
      stop = next;
      continue;
    }
    ear = next;
    if (ear === stop) {
      filteredOut = false;
      ear = filterPoints(ear);
      if (filteredOut) {
        stop = ear;
        continue;
      }
      if (!cured) {
        ear = cureLocalIntersections(ear, triangles);
        stop = ear;
        cured = true;
        continue;
      }
      splitEarcut(ear, triangles, minX, minY, invSize);
      break;
    }
  }
}
function isEar(ear) {
  const a = ear.prev, b = ear, c = ear.next, ax = a.x, bx = b.x, cx = c.x, ay = a.y, by = b.y, cy = c.y, x0 = Math.min(ax, bx, cx), y0 = Math.min(ay, by, cy), x1 = Math.max(ax, bx, cx), y1 = Math.max(ay, by, cy);
  let p = c.next;
  while (p !== a) {
    if (p.x >= x0 && p.x <= x1 && p.y >= y0 && p.y <= y1 && !(ax === p.x && ay === p.y) && pointInTriangle(ax, ay, bx, by, cx, cy, p.x, p.y) && area(p.prev, p, p.next) >= 0)
      return false;
    p = p.next;
  }
  return true;
}
function isEarHashed(ear, minX, minY, invSize) {
  const a = ear.prev, b = ear, c = ear.next, ax = a.x, bx = b.x, cx = c.x, ay = a.y, by = b.y, cy = c.y, x0 = Math.min(ax, bx, cx), y0 = Math.min(ay, by, cy), x1 = Math.max(ax, bx, cx), y1 = Math.max(ay, by, cy), minZ = zOrder(x0, y0, minX, minY, invSize), maxZ = zOrder(x1, y1, minX, minY, invSize);
  let p = ear.prevZ;
  while (p && p.z >= minZ) {
    if (p.x >= x0 && p.x <= x1 && p.y >= y0 && p.y <= y1 && p !== c && !(ax === p.x && ay === p.y) && pointInTriangle(ax, ay, bx, by, cx, cy, p.x, p.y) && area(p.prev, p, p.next) >= 0)
      return false;
    p = p.prevZ;
  }
  let n = ear.nextZ;
  while (n && n.z <= maxZ) {
    if (n.x >= x0 && n.x <= x1 && n.y >= y0 && n.y <= y1 && n !== c && !(ax === n.x && ay === n.y) && pointInTriangle(ax, ay, bx, by, cx, cy, n.x, n.y) && area(n.prev, n, n.next) >= 0)
      return false;
    n = n.nextZ;
  }
  return true;
}
function cureLocalIntersections(start, triangles) {
  let p = start;
  let cured = false;
  do {
    const a = p.prev, b = p.next.next;
    if (intersects(a, p, p.next, b, false) && locallyInside(a, b) && locallyInside(b, a)) {
      triangles.push(a.i, p.i, b.i);
      removeNode(p);
      removeNode(p.next);
      p = start = b;
      cured = true;
    }
    p = p.next;
  } while (p !== start);
  return cured ? filterPoints(p) : p;
}
function splitEarcut(start, triangles, minX, minY, invSize) {
  let a = start;
  do {
    let b = a.next.next;
    while (b !== a.prev) {
      if (a.i !== b.i && isValidDiagonal(a, b)) {
        let c = splitPolygon(a, b);
        a = filterPoints(a, a.next);
        c = filterPoints(c, c.next);
        earcutLinked(a, triangles, minX, minY, invSize);
        earcutLinked(c, triangles, minX, minY, invSize);
        return;
      }
      b = b.next;
    }
    a = a.next;
  } while (a !== start);
}
var indexActive = false;
function eliminateHoles(data, holeIndices, outerNode, dim) {
  const queue = [];
  for (let i = 0, len = holeIndices.length;i < len; i++) {
    const start = holeIndices[i] * dim;
    const end = i < len - 1 ? holeIndices[i + 1] * dim : data.length;
    const list = linkedList(data, start, end, dim, false);
    if (list === list.next)
      steiners.add(list);
    queue.push(getLeftmost(list));
  }
  queue.sort(compareXYSlope);
  buildBlockIndex(data.length / dim, holeIndices.length);
  indexSegment(outerNode, outerNode);
  indexActive = true;
  for (let i = 0;i < queue.length; i++) {
    outerNode = eliminateHole(queue[i], outerNode);
  }
  indexActive = false;
  return filterPoints(outerNode);
}
function compareXYSlope(a, b) {
  return a.x - b.x || a.y - b.y || (a.next.y - a.y) / (a.next.x - a.x) - (b.next.y - b.y) / (b.next.x - b.x);
}
function eliminateHole(hole, outerNode) {
  const bridge = findHoleBridge(hole, outerNode);
  if (!bridge) {
    return outerNode;
  }
  const bridgeReverse = splitPolygon(bridge, hole);
  const bridge2 = bridgeReverse.next;
  indexSegment(bridge, bridge2.next);
  filterPoints(bridgeReverse, bridgeReverse.next);
  return filterPoints(bridge, bridge.next);
}
var K = 16;
var blockBBox = new Float64Array(0);
var numBlocks = 0;
var blockHead = [];
var blockStop = [];
function buildBlockIndex(maxNodes, numHoles) {
  const maxBlocks = Math.ceil((maxNodes + 2 * numHoles) / K) + numHoles + 2;
  if (blockBBox.length < maxBlocks * 4)
    blockBBox = new Float64Array(maxBlocks * 4);
  numBlocks = 0;
}
function indexSegment(head, stop) {
  let p = head;
  do {
    const b = numBlocks++;
    blockHead[b] = p;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    let k = 0;
    do {
      const c = p.next;
      p.z = b;
      if (p.x < minX)
        minX = p.x;
      if (p.x > maxX)
        maxX = p.x;
      if (p.y < minY)
        minY = p.y;
      if (p.y > maxY)
        maxY = p.y;
      if (c.x < minX)
        minX = c.x;
      if (c.x > maxX)
        maxX = c.x;
      if (c.y < minY)
        minY = c.y;
      if (c.y > maxY)
        maxY = c.y;
      p = c;
    } while (++k < K && p !== stop);
    blockStop[b] = p;
    const g = b * 4;
    blockBBox[g] = minX;
    blockBBox[g + 1] = minY;
    blockBBox[g + 2] = maxX;
    blockBBox[g + 3] = maxY;
  } while (p !== stop);
}
function growBlock(head, tail) {
  const g = head.z * 4;
  if (tail.x < blockBBox[g])
    blockBBox[g] = tail.x;
  if (tail.y < blockBBox[g + 1])
    blockBBox[g + 1] = tail.y;
  if (tail.x > blockBBox[g + 2])
    blockBBox[g + 2] = tail.x;
  if (tail.y > blockBBox[g + 3])
    blockBBox[g + 3] = tail.y;
}
function liveBlockStop(b) {
  let stop = blockStop[b];
  while (stop.prev.next !== stop)
    stop = stop.next;
  blockStop[b] = stop;
  return stop;
}
function liveBlockHead(b) {
  let head = blockHead[b];
  while (head.prev.next !== head)
    head = head.next;
  blockHead[b] = head;
  return head;
}
function findHoleBridge(hole, outerNode) {
  let p = outerNode;
  const hx = hole.x;
  const hy = hole.y;
  let qx = -Infinity;
  let m;
  if (equals(hole, p))
    return p;
  for (let b = 0, g = 0;b < numBlocks; b++, g += 4) {
    if (hy < blockBBox[g + 1] || hy > blockBBox[g + 3] || blockBBox[g] > hx || blockBBox[g + 2] <= qx)
      continue;
    const stop = liveBlockStop(b);
    p = liveBlockHead(b);
    do {
      if (p.prev.next === p) {
        if (equals(hole, p.next))
          return p.next;
        else if (hy <= p.y && hy >= p.next.y && p.next.y !== p.y) {
          const x = p.x + (hy - p.y) * (p.next.x - p.x) / (p.next.y - p.y);
          if (x <= hx && x > qx) {
            qx = x;
            m = p.x < p.next.x ? p : p.next;
            if (x === hx)
              return m;
          }
        }
      }
      p = p.next;
    } while (p !== stop);
  }
  if (!m)
    return null;
  const mx = m.x;
  const my = m.y;
  const tminY = Math.min(hy, my);
  const tmaxY = Math.max(hy, my);
  let tanMin = Infinity;
  for (let b = 0, g = 0;b < numBlocks; b++, g += 4) {
    if (blockBBox[g + 2] < mx || blockBBox[g] > hx || blockBBox[g + 3] < tminY || blockBBox[g + 1] > tmaxY)
      continue;
    const stop = liveBlockStop(b);
    p = liveBlockHead(b);
    do {
      if (p.prev.next === p && hx >= p.x && p.x >= mx && hx !== p.x && pointInTriangle(hy < my ? hx : qx, hy, mx, my, hy < my ? qx : hx, hy, p.x, p.y)) {
        const tan = Math.abs(hy - p.y) / (hx - p.x);
        if ((locallyInside(p, hole) || p.y === hy && p.next.y === hy && p.next.x > hx) && (tan < tanMin || tan === tanMin && (p.x > m.x || p.x === m.x && sectorContainsSector(m, p)))) {
          m = p;
          tanMin = tan;
        }
      }
      p = p.next;
    } while (p !== stop);
  }
  return m;
}
function sectorContainsSector(m, p) {
  return area(m.prev, m, p.prev) < 0 && area(p.next, m, m.next) < 0;
}
var sortArr = [];
var sortBuf = [];
var zArr = new Uint32Array(0);
var zBuf = new Uint32Array(0);
var counts = new Uint32Array(256);
function indexCurve(start, minX, minY, invSize) {
  let p = start;
  let n = 0;
  do {
    p.z = zOrder(p.x, p.y, minX, minY, invSize);
    sortArr[n++] = p;
    p = p.next;
  } while (p !== start);
  sortNodes(n);
  let prev = null;
  for (let i = 0;i < n; i++) {
    const node = sortArr[i];
    node.prevZ = prev;
    if (prev)
      prev.nextZ = node;
    prev = node;
  }
  prev.nextZ = null;
}
function sortNodes(n) {
  if (n <= 32) {
    for (let i = 1;i < n; i++) {
      const node = sortArr[i], z = node.z;
      let j = i - 1;
      while (j >= 0 && sortArr[j].z > z) {
        sortArr[j + 1] = sortArr[j];
        j--;
      }
      sortArr[j + 1] = node;
    }
    return;
  }
  if (zArr.length < n) {
    zArr = new Uint32Array(n);
    zBuf = new Uint32Array(n);
    sortBuf = new Array(n);
  }
  for (let i = 0;i < n; i++)
    zArr[i] = sortArr[i].z;
  radixPass(n, sortArr, zArr, sortBuf, zBuf, 0);
  radixPass(n, sortBuf, zBuf, sortArr, zArr, 8);
  radixPass(n, sortArr, zArr, sortBuf, zBuf, 16);
  radixPass(n, sortBuf, zBuf, sortArr, zArr, 24);
}
function radixPass(n, src, srcZ, dst, dstZ, shift) {
  counts.fill(0);
  for (let i = 0;i < n; i++)
    counts[srcZ[i] >>> shift & 255]++;
  let sum = 0;
  for (let b = 0;b < 256; b++) {
    const c = counts[b];
    counts[b] = sum;
    sum += c;
  }
  for (let i = 0;i < n; i++) {
    const z = srcZ[i];
    const pos = counts[z >>> shift & 255]++;
    dst[pos] = src[i];
    dstZ[pos] = z;
  }
}
function zOrder(x, y, minX, minY, invSize) {
  x = (x - minX) * invSize | 0;
  y = (y - minY) * invSize | 0;
  x = (x | x << 8) & 16711935;
  x = (x | x << 4) & 252645135;
  x = (x | x << 2) & 858993459;
  x = (x | x << 1) & 1431655765;
  y = (y | y << 8) & 16711935;
  y = (y | y << 4) & 252645135;
  y = (y | y << 2) & 858993459;
  y = (y | y << 1) & 1431655765;
  return x | y << 1;
}
function getLeftmost(start) {
  let p = start, leftmost = start;
  do {
    if (p.x < leftmost.x || p.x === leftmost.x && p.y < leftmost.y)
      leftmost = p;
    p = p.next;
  } while (p !== start);
  return leftmost;
}
function pointInTriangle(ax, ay, bx, by, cx, cy, px, py) {
  return (cx - px) * (ay - py) >= (ax - px) * (cy - py) && (ax - px) * (by - py) >= (bx - px) * (ay - py) && (bx - px) * (cy - py) >= (cx - px) * (by - py);
}
function isValidDiagonal(a, b) {
  const zeroLength = equals(a, b) && area(a.prev, a, a.next) > 0 && area(b.prev, b, b.next) > 0;
  return a.next.i !== b.i && (zeroLength || locallyInside(a, b) && locallyInside(b, a) && (area(a.prev, a, b.prev) !== 0 || area(a, b.prev, b) !== 0)) && !intersectsPolygon(a, b) && (zeroLength || middleInside(a, b));
}
function area(p, q, r) {
  return (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
}
function equals(p1, p2) {
  return p1.x === p2.x && p1.y === p2.y;
}
function intersects(p1, q1, p2, q2, includeBoundary = true) {
  const o1 = area(p1, q1, p2);
  const o2 = area(p1, q1, q2);
  const o3 = area(p2, q2, p1);
  const o4 = area(p2, q2, q1);
  if ((o1 > 0 && o2 < 0 || o1 < 0 && o2 > 0) && (o3 > 0 && o4 < 0 || o3 < 0 && o4 > 0))
    return true;
  if (!includeBoundary)
    return false;
  if (o1 === 0 && onSegment(p1, p2, q1))
    return true;
  if (o2 === 0 && onSegment(p1, q2, q1))
    return true;
  if (o3 === 0 && onSegment(p2, p1, q2))
    return true;
  if (o4 === 0 && onSegment(p2, q1, q2))
    return true;
  return false;
}
function onSegment(p, q, r) {
  return q.x <= Math.max(p.x, r.x) && q.x >= Math.min(p.x, r.x) && q.y <= Math.max(p.y, r.y) && q.y >= Math.min(p.y, r.y);
}
function intersectsPolygon(a, b) {
  const minX = Math.min(a.x, b.x);
  const maxX = Math.max(a.x, b.x);
  const minY = Math.min(a.y, b.y);
  const maxY = Math.max(a.y, b.y);
  let p = a;
  do {
    const n = p.next;
    if (p.x > maxX && n.x > maxX || p.x < minX && n.x < minX || p.y > maxY && n.y > maxY || p.y < minY && n.y < minY) {
      p = n;
      continue;
    }
    if (p.i !== a.i && n.i !== a.i && p.i !== b.i && n.i !== b.i && intersects(p, n, a, b))
      return true;
    p = n;
  } while (p !== a);
  return false;
}
function locallyInside(a, b) {
  return area(a.prev, a, a.next) < 0 ? area(a, b, a.next) >= 0 && area(a, a.prev, b) >= 0 : area(a, b, a.prev) < 0 || area(a, a.next, b) < 0;
}
function middleInside(a, b) {
  let p = a;
  let inside = false;
  const px = (a.x + b.x) / 2;
  const py = (a.y + b.y) / 2;
  do {
    const n = p.next;
    if (p.y > py !== n.y > py && px < (n.x - p.x) * (py - p.y) / (n.y - p.y) + p.x)
      inside = !inside;
    p = n;
  } while (p !== a);
  return inside;
}
function splitPolygon(a, b) {
  const a2 = createNode(a.i, a.x, a.y), b2 = createNode(b.i, b.x, b.y), an = a.next, bp = b.prev;
  a.next = b;
  b.prev = a;
  a2.next = an;
  an.prev = a2;
  b2.next = a2;
  a2.prev = b2;
  bp.next = b2;
  b2.prev = bp;
  return b2;
}
function insertNode(i, x, y, last) {
  const p = createNode(i, x, y);
  if (!last) {
    p.prev = p;
    p.next = p;
  } else {
    p.next = last.next;
    p.prev = last;
    last.next.prev = p;
    last.next = p;
  }
  return p;
}
function removeNode(p) {
  p.next.prev = p.prev;
  p.prev.next = p.next;
  if (p.prevZ)
    p.prevZ.nextZ = p.nextZ;
  if (p.nextZ)
    p.nextZ.prevZ = p.prevZ;
  if (indexActive)
    growBlock(p.prev, p.next);
}
function createNode(i, x, y) {
  return {
    i,
    x,
    y,
    prev: null,
    next: null,
    z: 0,
    prevZ: null,
    nextZ: null
  };
}
function signedArea(data, start, end, dim) {
  let sum = 0;
  for (let i = start, j = end - dim;i < end; i += dim) {
    sum += (data[j] - data[i]) * (data[i + 1] + data[j + 1]);
    j = i;
  }
  return sum;
}

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/math.ts
var subtract = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
var dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
var cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
var normalize = (v) => {
  const length = Math.hypot(...v);
  return length ? [v[0] / length, v[1] / length, v[2] / length] : [0, 0, 1];
};
var inverse = (matrix) => {
  const rows = Array.from({ length: 4 }, (_, row) => Array.from({ length: 8 }, (_2, column) => column < 4 ? matrix[column * 4 + row] : Number(column - 4 === row)));
  for (let column = 0;column < 4; column++) {
    let pivot = column;
    for (let row = column + 1;row < 4; row++)
      if (Math.abs(rows[row][column]) > Math.abs(rows[pivot][column]))
        pivot = row;
    if (Math.abs(rows[pivot][column]) < 0.00000000000000000001)
      throw new Error("Physical scene projection is singular");
    [rows[column], rows[pivot]] = [rows[pivot], rows[column]];
    const divisor = rows[column][column];
    for (let k = 0;k < 8; k++)
      rows[column][k] /= divisor;
    for (let row = 0;row < 4; row++)
      if (row !== column) {
        const factor = rows[row][column];
        for (let k = 0;k < 8; k++)
          rows[row][k] -= factor * rows[column][k];
      }
  }
  return new Float64Array(Array.from({ length: 16 }, (_, index) => rows[index % 4][4 + Math.floor(index / 4)]));
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/geometry.ts
var position = (v) => [v[0], v[1], v[2]];
var pointKey = (p) => p.map((value) => Math.round(value * 1e5)).join(",");
var vertexAt = (object, index, normal) => [
  object.positions[index * 3],
  object.positions[index * 3 + 1],
  object.positions[index * 3 + 2],
  object.normals?.[index * 3] ?? normal[0],
  object.normals?.[index * 3 + 1] ?? normal[1],
  object.normals?.[index * 3 + 2] ?? normal[2],
  object.materialIndices?.[index] ?? 0
];
var clipPolygon = (vertices, height, above) => {
  if (!Number.isFinite(height))
    return vertices;
  const output = [];
  for (let index = 0;index < vertices.length; index++) {
    const a = vertices[index], b = vertices[(index + 1) % vertices.length];
    const insideA = above ? a[2] >= height : a[2] <= height;
    const insideB = above ? b[2] >= height : b[2] <= height;
    if (insideA)
      output.push(a);
    if (insideA !== insideB) {
      const ratio = (height - a[2]) / (b[2] - a[2]);
      output.push(a.map((value, component) => component === 6 ? a[6] : value + (b[component] - value) * ratio));
    }
  }
  return output;
};
var sectionSegment = (triangle, height) => {
  const intersections = [];
  for (let index = 0;index < 3; index++) {
    const a = triangle[index], b = triangle[(index + 1) % 3];
    if (a[2] < height && b[2] > height || a[2] > height && b[2] < height) {
      const ratio = (height - a[2]) / (b[2] - a[2]);
      intersections.push(a.map((value, component) => component === 6 ? a[6] : value + (b[component] - value) * ratio));
    } else if (Math.abs(a[2] - height) < 0.0000001)
      intersections.push(a);
  }
  const unique = [...new Map(intersections.map((v) => [pointKey(position(v)), v])).values()];
  return unique.length === 2 ? [unique[0], unique[1]] : null;
};
var signedArea2 = (points) => points.reduce((sum, point, index) => {
  const next = points[(index + 1) % points.length];
  return sum + point[0] * next[1] - next[0] * point[1];
}, 0) / 2;
var turn = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
var containsPoint = (loop, point) => {
  let inside = false;
  for (let index = 0, previous = loop.length - 1;index < loop.length; previous = index++) {
    const a = loop[index], b = loop[previous];
    if (a[1] > point[1] !== b[1] > point[1] && point[0] < (b[0] - a[0]) * (point[1] - a[1]) / (b[1] - a[1]) + a[0])
      inside = !inside;
  }
  return inside;
};
var appendCaps = (segments, output) => {
  const adjacent = new Map;
  for (const [a, b] of segments)
    for (const [from, to] of [[a, b], [b, a]]) {
      const key = pointKey(position(from)), next = { other: pointKey(position(to)), vertex: to };
      const entries = adjacent.get(key) ?? [];
      if (!entries.some((entry) => entry.other === next.other))
        entries.push(next);
      adjacent.set(key, entries);
    }
  const visited = new Set;
  const loops = [];
  for (const [start, entries] of adjacent) {
    if (visited.has(start) || entries.length !== 2)
      continue;
    const loop = [];
    let previous = "", current = start;
    do {
      visited.add(current);
      const choices = adjacent.get(current);
      if (!choices || choices.length !== 2)
        break;
      const next = choices.find((choice) => choice.other !== previous);
      loop.push(next.vertex);
      previous = current;
      current = next.other;
    } while (current !== start && !visited.has(current));
    if (current !== start || loop.length < 3)
      continue;
    for (let index = loop.length - 1;index >= 0 && loop.length > 3; index--)
      if (Math.abs(turn(loop[(index + loop.length - 1) % loop.length], loop[index], loop[(index + 1) % loop.length])) < 0.00000001)
        loop.splice(index, 1);
    loops.push(loop);
  }
  const areas = loops.map((loop) => Math.abs(signedArea2(loop)));
  const parents = loops.map((loop, index) => {
    let parent = -1;
    for (let other = 0;other < loops.length; other++)
      if (areas[other] > areas[index] && containsPoint(loops[other], loop[0]) && (parent < 0 || areas[other] < areas[parent]))
        parent = other;
    return parent;
  });
  const depth = (index) => parents[index] < 0 ? 0 : depth(parents[index]) + 1;
  for (let index = 0;index < loops.length; index++) {
    if (depth(index) % 2)
      continue;
    const vertices = [...loops[index]], holes = [];
    for (let child = 0;child < loops.length; child++)
      if (parents[child] === index) {
        holes.push(vertices.length);
        vertices.push(...loops[child]);
      }
    const indices = earcut(vertices.flatMap((vertex) => [vertex[0], vertex[1]]), holes, 2);
    for (let corner = 0;corner < indices.length; corner += 3) {
      const triangle = indices.slice(corner, corner + 3).map((vertex) => vertices[vertex]);
      if (turn(triangle[0], triangle[1], triangle[2]) < 0)
        triangle.reverse();
      for (const vertex of triangle)
        output.push(vertex[0], vertex[1], vertex[2], 0, 0, 1, vertex[6]);
    }
  }
};
var outline = (vertices) => {
  const edges = new Map;
  for (let index = 0;index < vertices.length; index += 21) {
    const a = position(vertices.slice(index, index + 3)), b = position(vertices.slice(index + 7, index + 10)), c = position(vertices.slice(index + 14, index + 17));
    const normal = normalize(cross(subtract(b, a), subtract(c, a)));
    for (const [from, to] of [[a, b], [b, c], [c, a]]) {
      const key = [pointKey(from), pointKey(to)].sort().join("/");
      const existing = edges.get(key);
      if (existing) {
        existing.count++;
        existing.crease ||= Math.abs(dot(existing.normal, normal)) < 0.85;
      } else
        edges.set(key, { a: from, b: to, normal, crease: false, count: 1 });
    }
  }
  return [...edges.values()].filter((edge) => edge.count === 1 || edge.crease).flatMap((edge) => [...edge.a, ...edge.b]);
};
var meshBounds = (vertices, stride = 7) => {
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (let index = 0;index < vertices.length; index += stride)
    for (let axis = 0;axis < 3; axis++) {
      min[axis] = Math.min(min[axis], vertices[index + axis]);
      max[axis] = Math.max(max[axis], vertices[index + axis]);
    }
  return { min, max };
};
var buildVisibleMeshes = (scene, view) => {
  const levels = [...scene.levels].sort((a, b) => a.elevation - b.elevation);
  const selected = view.levelId === "all" ? null : levels.find((level) => level.id === view.levelId);
  if (view.levelId !== "all" && !selected)
    throw new Error(`Physical scene ${scene.id} has no level ${view.levelId}`);
  const output = [];
  for (const object of scene.objects) {
    if (object.kind === "space" || object.kind === "opening" || object.kind === "assembly" || view.cutaway && object.kind === "roof")
      continue;
    const bands = selected ? [selected] : view.separation > 0 && object.levelId !== "site" ? levels : [null];
    for (const level of bands) {
      if (level && object.levelId !== "site" && object.levelIds && !object.levelIds.includes(level.id))
        continue;
      const authoredVolume = level ? object.inspectionLevels?.find((volume) => volume.levelId === level.id) : undefined;
      if (level && object.inspectionLevels && !authoredVolume)
        continue;
      if (level && object.kind === "slab" && object.levelId !== "site" && object.levelId !== level.id)
        continue;
      const clipLevel = object.levelId === "site" ? null : level;
      const next = clipLevel ? levels.find((candidate) => candidate.elevation > clipLevel.elevation) : undefined;
      let slabLow = Infinity;
      if (authoredVolume && object.kind === "slab" && object.levelId === clipLevel?.id)
        for (let index = 2;index < object.positions.length; index += 3)
          slabLow = Math.min(slabLow, object.positions[index]);
      const baseLow = clipLevel ? authoredVolume ? Math.min(authoredVolume.low, slabLow) : clipLevel.elevation - (object.kind === "slab" && object.levelId === clipLevel.id ? 1 : 0.01) : -Infinity;
      const upper = authoredVolume?.high ?? (next ? next.elevation - 0.001 : Infinity);
      const boundary = object.inspectionBoundary !== undefined && view.mode === "3d" && view.cutaway && object.levelId !== "site";
      const firstVolume = boundary && !clipLevel ? object.inspectionLevels?.reduce((first, volume) => volume.low < first.low ? volume : first) : undefined;
      const cutLevel = clipLevel ?? (boundary ? levels.find((level2) => level2.id === firstVolume?.levelId) ?? levels[0] : levels.at(-1));
      const sectioned = object.kind === "wall" || object.inspectionBoundary !== undefined || view.mode === "2d" && object.planDisplay === "section";
      const cut = view.cutaway && sectioned && object.levelId !== "site" ? authoredVolume ? authoredVolume.low + cutLevel.cutHeight - cutLevel.elevation : firstVolume ? firstVolume.low + cutLevel.cutHeight - cutLevel.elevation : cutLevel.cutHeight : Infinity;
      const allFloorCuts = boundary && !clipLevel ? object.inspectionLevels?.map((volume) => {
        const sourceLevel = levels.find((level2) => level2.id === volume.levelId);
        return { low: volume.low, high: Math.min(volume.high, volume.low + sourceLevel.cutHeight - sourceLevel.elevation), part: "cut", cutLevelId: volume.levelId };
      }) : undefined;
      const variants = allFloorCuts ? [{ high: upper, part: "full" }, ...allFloorCuts] : boundary && cut < upper ? [{ high: upper, part: "full" }, { high: Math.min(upper, cut), part: "cut" }] : [{ high: Math.min(upper, cut) }];
      for (const variant of variants) {
        const high = variant.high, low = variant.low ?? baseLow;
        const vertices = [], segments = [];
        const count = object.indices?.length ?? object.positions.length / 3;
        if (!Number.isFinite(low) && !Number.isFinite(high) && object.normals?.length === object.positions.length) {
          for (let index = 0;index < count; index++) {
            const id = object.indices?.[index] ?? index, at = id * 3;
            vertices.push(object.positions[at], object.positions[at + 1], object.positions[at + 2], object.normals[at], object.normals[at + 1], object.normals[at + 2], object.materialIndices?.[id] ?? 0);
          }
        } else
          for (let index = 0;index < count; index += 3) {
            const ids = [0, 1, 2].map((offset2) => object.indices?.[index + offset2] ?? index + offset2);
            const points = ids.map((id) => position(object.positions.slice(id * 3, id * 3 + 3)));
            const normal = normalize(cross(subtract(points[1], points[0]), subtract(points[2], points[0])));
            const triangle = ids.map((id) => vertexAt(object, id, normal));
            let polygon = clipPolygon(clipPolygon(triangle, low, true), high, false);
            for (let corner = 1;corner < polygon.length - 1; corner++)
              vertices.push(...polygon[0], ...polygon[corner], ...polygon[corner + 1]);
            if (sectioned && Number.isFinite(high)) {
              const segment = sectionSegment(triangle, high);
              if (segment)
                segments.push(segment);
            }
          }
        if (!vertices.length)
          continue;
        appendCaps(segments, vertices);
        const lines = object.edgePolicy === "none" || object.edgePolicy === "authored" ? [] : outline(vertices);
        const lineMaterials = Array(lines.length / 6).fill("line"), lineStyles = Array(lines.length / 6).fill(object.kind === "context" ? "context" : "feature");
        if (object.edgePolicy !== undefined)
          for (const [a, b] of segments) {
            lines.push(...position(a), ...position(b));
            lineMaterials.push("line");
            lineStyles.push("section");
          }
        const features = object.edgePolicy === "none" ? [] : object.featureLines ?? [];
        const authoredLines = view.mode === "2d" ? object.planLines ?? features : features;
        for (const line of authoredLines) {
          for (let index = 0;index < line.positions.length; index += 6) {
            let a = line.positions.slice(index, index + 3), b = line.positions.slice(index + 3, index + 6);
            let visible = true;
            for (const [height, above] of [[low, true], [high, false]]) {
              if (!Number.isFinite(height))
                continue;
              const inA = above ? a[2] >= height : a[2] <= height, inB = above ? b[2] >= height : b[2] <= height;
              if (!inA && !inB) {
                visible = false;
                break;
              }
              if (inA !== inB) {
                const ratio = (height - a[2]) / (b[2] - a[2]), point = a.map((value, axis) => value + (b[axis] - value) * ratio);
                if (inA)
                  b = point;
                else
                  a = point;
              }
            }
            if (visible) {
              lines.push(...a, ...b);
              lineMaterials.push(line.material ?? "line");
              lineStyles.push(object.kind === "context" ? "context" : "feature");
            }
          }
        }
        let planPriority;
        if (view.mode === "2d") {
          planPriority = object.kind === "slab" || object.kind === "pavement" ? 0 : object.kind === "context" ? 1 : object.kind === "wall" ? 2 : object.kind === "support" || object.kind === "stair" ? 3 : object.kind === "equipment" ? 4 : object.kind === "pipe" || object.kind === "riser" ? 5 : object.kind === "door" ? 6 : object.kind === "roof" ? 8 : 3;
        }
        const offset = [0, 0, view.mode === "3d" && level && !selected ? levels.indexOf(level) * view.separation : 0];
        output.push({ ...variant.part === undefined ? {} : { inspectionPart: variant.part }, ...planPriority === undefined ? {} : { planPriority }, key: `${object.id}/${level?.id ?? "all"}${variant.part === undefined ? "" : `/inspection-${variant.part}`}${variant.cutLevelId ? `/${variant.cutLevelId}` : ""}`, object, vertices: Float64Array.from(vertices), lines: Float64Array.from(lines), lineMaterials, lineStyles, levelId: variant.cutLevelId ?? level?.id ?? object.levelId, bounds: meshBounds(vertices), offset });
      }
    }
  }
  return output;
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/spatial-index.ts
var area2 = (b) => {
  const x = b.max[0] - b.min[0], y = b.max[1] - b.min[1], z = b.max[2] - b.min[2];
  return 2 * (x * y + y * z + z * x);
};
var union = (values, ids, first = 0, end = ids.length) => {
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (let at = first;at < end; at++)
    for (let axis = 0;axis < 3; axis++) {
      const id = ids[at];
      min[axis] = Math.min(min[axis], values[id].min[axis]);
      max[axis] = Math.max(max[axis], values[id].max[axis]);
    }
  return { min, max };
};
var createPhysicalSpatialIndex = (values, query = "ray") => {
  if (query === "overlap")
    return createPhysicalOverlapSpatialIndex(values);
  const nodes = [], order = [];
  const build = (ids, bounds = union(values, ids)) => {
    const index = nodes.length, node = { bounds, left: -1, right: -1, first: 0, count: 0 };
    nodes.push(node);
    const parentArea = area2(bounds);
    if (ids.length > 1 && parentArea > 0) {
      const spans = bounds.max.map((value, axis2) => value - bounds.min[axis2]), axis = spans.indexOf(Math.max(...spans));
      ids.sort((a, b) => values[a].min[axis] + values[a].max[axis] - values[b].min[axis] - values[b].max[axis] || a - b);
      const middle = Math.floor(ids.length / 2), left = ids.slice(0, middle), right = ids.slice(middle), leftBounds = union(values, left), rightBounds = union(values, right);
      const splitCost = 1 + (area2(leftBounds) * left.length + area2(rightBounds) * right.length) / parentArea;
      if (splitCost < ids.length) {
        node.left = build(left, leftBounds);
        node.right = build(right, rightBounds);
        return index;
      }
    }
    node.first = order.length;
    node.count = ids.length;
    order.push(...ids.sort((a, b) => a - b));
    return index;
  };
  if (values.length)
    build(values.map((_, index) => index));
  return { bounds: Float64Array.from(nodes.flatMap((node) => [...node.bounds.min, ...node.bounds.max])), children: Int32Array.from(nodes.flatMap((node) => [node.left, node.right])), ranges: Uint32Array.from(nodes.flatMap((node) => [node.first, node.count])), order: Uint32Array.from(order) };
};
var createPhysicalOverlapSpatialIndex = (values) => {
  const nodes = [], order = [];
  const sorted = [0, 1, 2].map((axis) => Uint32Array.from(values.map((_, id) => id).sort((a, b) => values[a].min[axis] + values[a].max[axis] - values[b].min[axis] - values[b].max[axis] || a - b)));
  const rank = sorted.map((ids) => {
    const result = new Uint32Array(values.length);
    ids.forEach((id, at) => {
      result[id] = at;
    });
    return result;
  }), scratch = new Uint32Array(values.length);
  const build = (first, end, bounds = union(values, sorted[0], first, end)) => {
    const count = end - first, index = nodes.length, node = { bounds, left: -1, right: -1, first: 0, count: 0 };
    nodes.push(node);
    const parentArea = area2(bounds);
    if (count > 1 && parentArea > 0) {
      const middle = first + Math.floor(count / 2), leftCount = middle - first;
      let best;
      for (let axis = 0;axis < 3; axis++) {
        const left = union(values, sorted[axis], first, middle), right = union(values, sorted[axis], middle, end);
        const cost = 1 + (area2(left) * leftCount + area2(right) * (count - leftCount)) / parentArea;
        if (!best || cost < best.cost)
          best = { axis, cost, left, right };
      }
      if (best.cost < count) {
        const ranks = rank[best.axis], pivot = ranks[sorted[best.axis][middle]];
        for (let axis = 0;axis < 3; axis++) {
          const ids = sorted[axis];
          let left = first, right = middle;
          for (let at = first;at < end; at++) {
            const id = ids[at];
            scratch[ranks[id] < pivot ? left++ : right++] = id;
          }
          ids.set(scratch.subarray(first, end), first);
        }
        node.left = build(first, middle, best.left);
        node.right = build(middle, end, best.right);
        return index;
      }
    }
    node.first = order.length;
    node.count = count;
    order.push(...Array.from(sorted[0].subarray(first, end)).sort((a, b) => a - b));
    return index;
  };
  if (values.length)
    build(0, values.length);
  return { bounds: Float64Array.from(nodes.flatMap((node) => [...node.bounds.min, ...node.bounds.max])), children: Int32Array.from(nodes.flatMap((node) => [node.left, node.right])), ranges: Uint32Array.from(nodes.flatMap((node) => [node.first, node.count])), order: Uint32Array.from(order) };
};
var physicalSpatialBoundsOverlap = (a, b) => {
  for (let axis = 0;axis < 3; axis++) {
    const low = a.min[axis], high = a.max[axis], scale = Math.max(1, Math.abs(low), Math.abs(high), Math.abs(b.min[axis]), Math.abs(b.max[axis])), error = scale * Number.EPSILON * 8;
    if (high < b.min[axis] - error || low > b.max[axis] + error)
      return false;
  }
  return true;
};
var visitPhysicalSpatialBounds = (index, bounds, visit) => {
  if (!index.order.length)
    return;
  const pending = [0];
  while (pending.length) {
    const node = pending.pop(), at = node * 6;
    let overlaps = true;
    for (let axis = 0;axis < 3; axis++) {
      const low = index.bounds[at + axis], high = index.bounds[at + axis + 3], scale = Math.max(1, Math.abs(low), Math.abs(high), Math.abs(bounds.min[axis]), Math.abs(bounds.max[axis]));
      const error = scale * Number.EPSILON * 8;
      if (high < bounds.min[axis] - error || low > bounds.max[axis] + error) {
        overlaps = false;
        break;
      }
    }
    if (!overlaps)
      continue;
    const left = index.children[node * 2], right = index.children[node * 2 + 1];
    if (left < 0) {
      const first = index.ranges[node * 2], count = index.ranges[node * 2 + 1];
      for (let offset = first;offset < first + count; offset++)
        visit(index.order[offset]);
    } else
      pending.push(right, left);
  }
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/picking.ts
var meshIndices = new WeakMap;
var sceneIndices = new WeakMap;
var inverses = new WeakMap;
var preparePhysicalMeshAcceleration = (mesh) => {
  const cached = meshIndices.get(mesh);
  if (cached)
    return cached;
  const bounds = [];
  for (let at = 0;at < mesh.vertices.length; at += 21) {
    const values = mesh.vertices;
    bounds.push({ min: [Math.min(values[at], values[at + 7], values[at + 14]), Math.min(values[at + 1], values[at + 8], values[at + 15]), Math.min(values[at + 2], values[at + 9], values[at + 16])], max: [Math.max(values[at], values[at + 7], values[at + 14]), Math.max(values[at + 1], values[at + 8], values[at + 15]), Math.max(values[at + 2], values[at + 9], values[at + 16])] });
  }
  const result = { triangles: createPhysicalSpatialIndex(bounds) };
  meshIndices.set(mesh, result);
  return result;
};
var preparePhysicalPickAcceleration = (meshes) => {
  const cached = sceneIndices.get(meshes);
  if (cached)
    return cached;
  const result = { meshes: createPhysicalSpatialIndex(meshes.map((mesh) => ({ min: mesh.bounds.min.map((value, axis) => value + mesh.offset[axis]), max: mesh.bounds.max.map((value, axis) => value + mesh.offset[axis]) }))), triangles: meshes.map(preparePhysicalMeshAcceleration) };
  sceneIndices.set(meshes, result);
  return result;
};
var admitPhysicalPickAcceleration = (meshes, acceleration) => {
  if (acceleration.triangles.length !== meshes.length)
    throw new Error("Physical pick acceleration does not match its mesh array");
  sceneIndices.set(meshes, acceleration);
  meshes.forEach((mesh, index) => meshIndices.set(mesh, acceleration.triangles[index]));
};
var derivePhysicalPickAcceleration = (meshes, source) => {
  for (const mesh of meshes) {
    const index = mesh.assetIndex;
    if (index === undefined || !source.triangles[index])
      throw new Error("Filtered physical fragment lost its source index");
    meshIndices.set(mesh, source.triangles[index]);
  }
  preparePhysicalPickAcceleration(meshes);
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/surface-ownership.ts
var vertex = (values, at) => [values[at], values[at + 1], values[at + 2], values[at + 3], values[at + 4], values[at + 5], values[at + 6]];
var onPlane = (triangle, p) => {
  const a = triangle[0], b = triangle[1], c = triangle[2];
  const ax = a[0] - p[0], ay = a[1] - p[1], az = a[2] - p[2], bx = b[0] - p[0], by = b[1] - p[1], bz = b[2] - p[2], cx = c[0] - p[0], cy = c[1] - p[1], cz = c[2] - p[2];
  const p0 = bx * cy, p1 = cx * by, p2 = cx * ay, p3 = ax * cy, p4 = ax * by, p5 = bx * ay;
  const determinant = az * (p0 - p1) + bz * (p2 - p3) + cz * (p4 - p5);
  const permanent = Math.abs(az) * (Math.abs(p0) + Math.abs(p1)) + Math.abs(bz) * (Math.abs(p2) + Math.abs(p3)) + Math.abs(cz) * (Math.abs(p4) + Math.abs(p5));
  return Math.abs(determinant) <= (7 + 56 * Number.EPSILON) * Number.EPSILON * permanent;
};
var distance = (a, b, p, axes) => {
  const [x, y] = axes, left = (b[x] - a[x]) * (p[y] - a[y]), right = (b[y] - a[y]) * (p[x] - a[x]), value = left - right;
  return Math.abs(value) <= (3 + 16 * Number.EPSILON) * Number.EPSILON * (Math.abs(left) + Math.abs(right)) ? 0 : value;
};
var area3 = (polygon, axes) => {
  let sum = 0, magnitude = 0;
  for (let at = 1;at < polygon.length - 1; at++) {
    const value = distance(polygon[0], polygon[at], polygon[at + 1], axes);
    sum += value;
    magnitude += Math.abs(value);
  }
  return Math.abs(sum) > (polygon.length * 4 + 2) * Number.EPSILON * magnitude ? Math.abs(sum) / 2 : 0;
};
var interpolate = (a, b, fraction) => a.map((value, component) => component === 6 ? a[6] : value + (b[component] - value) * fraction);
var split = (polygon, a, b, axes, orientation) => {
  const distances = polygon.map((v) => distance(a, b, v, axes) * orientation);
  if (distances.every((value) => value >= 0))
    return { inside: polygon, outside: [] };
  if (distances.every((value) => value <= 0))
    return { inside: [], outside: polygon };
  const inside = [], outside = [];
  for (let index = 0;index < polygon.length; index++) {
    const start = polygon[index], end = polygon[(index + 1) % polygon.length], da = distances[index], db = distances[(index + 1) % polygon.length];
    if (da >= 0)
      inside.push(start);
    if (da <= 0)
      outside.push(start);
    if (da * db < 0) {
      const crossing = interpolate(start, end, da / (da - db));
      inside.push(crossing);
      outside.push(crossing);
    }
  }
  return { inside, outside };
};
var partition = (region, cover, owner) => {
  if (region.coveredBy.includes(owner))
    return { regions: [region], overlap: 0 };
  const axes = cover.axes, orientation = Math.sign(cover.normal[3 - axes[0] - axes[1]]), pieces = [];
  let remaining = region.vertices;
  for (let edge = 0;edge < 3 && remaining.length; edge++) {
    const result = split(remaining, cover.vertices[edge], cover.vertices[(edge + 1) % 3], axes, orientation);
    if (area3(result.outside, axes) > 0)
      pieces.push({ vertices: result.outside, coveredBy: region.coveredBy });
    remaining = result.inside;
  }
  const overlap = area3(remaining, axes);
  if (!(overlap > 0))
    return { regions: [region], overlap: 0 };
  pieces.push({ vertices: remaining, coveredBy: [...region.coveredBy, owner] });
  return { regions: pieces, overlap: overlap * Math.hypot(...cover.normal) / Math.abs(cover.normal[3 - axes[0] - axes[1]]) };
};
var storage = (capacity) => ({ values: new Float64Array(capacity), length: 0 });
var append = (output, polygon) => {
  const required = output.length + Math.max(0, polygon.length - 2) * 21;
  if (required > output.values.length) {
    const grown = new Float64Array(Math.max(required, output.values.length * 2));
    grown.set(output.values);
    output.values = grown;
  }
  for (let corner = 1;corner < polygon.length - 1; corner++)
    for (const point of [polygon[0], polygon[corner], polygon[corner + 1]])
      for (let component = 0;component < 7; component++)
        output.values[output.length++] = point[component];
};
var appendTriangle = (output, triangle) => {
  const required = output.length + 21;
  if (required > output.values.length) {
    const grown = new Float64Array(Math.max(required, output.values.length * 2));
    grown.set(output.values);
    output.values = grown;
  }
  for (let corner = 0;corner < 3; corner++)
    for (let component = 0;component < 7; component++)
      output.values[output.length++] = triangle[corner][component];
};
var finish = (vertices) => vertices.length === vertices.values.length ? vertices.values : vertices.values.slice(0, vertices.length);
var preparePhysicalSurfaceOwnership = (meshes) => {
  const cohorts = new Map, pieces = meshes.map(() => new Map), pairs = new Map;
  let triangles = 0, partitionedTriangles = 0, broadPhaseCandidates = 0, coplanarCandidates = 0;
  meshes.forEach((mesh, meshIndex) => {
    const key = `${mesh.planPriority ?? "physical"}|${mesh.offset.join(",")}`, faces = cohorts.get(key) ?? [];
    for (let at = 0;at < mesh.vertices.length; at += 21) {
      const vertices = [vertex(mesh.vertices, at), vertex(mesh.vertices, at + 7), vertex(mesh.vertices, at + 14)], [a, b, c] = vertices;
      const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2], normal = [uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx];
      const nx = Math.abs(normal[0]), ny = Math.abs(normal[1]), nz = Math.abs(normal[2]), dominant = nx >= ny && nx >= nz ? 0 : ny >= nz ? 1 : 2;
      if (normal[dominant] === 0)
        continue;
      const axes = [(dominant + 1) % 3, (dominant + 2) % 3];
      faces.push({ mesh: meshIndex, vertices, normal, axes, bounds: { min: [Math.min(a[0], b[0], c[0]), Math.min(a[1], b[1], c[1]), Math.min(a[2], b[2], c[2])], max: [Math.max(a[0], b[0], c[0]), Math.max(a[1], b[1], c[1]), Math.max(a[2], b[2], c[2])] } });
      triangles++;
    }
    cohorts.set(key, faces);
  });
  for (const faces of cohorts.values()) {
    const index = createPhysicalSpatialIndex(faces.map((face) => face.bounds), "overlap");
    faces.forEach((face, faceIndex) => {
      const candidates = [];
      let earlierCandidates = 0;
      visitPhysicalSpatialBounds(index, face.bounds, (candidate) => {
        if (candidate >= faceIndex)
          return;
        earlierCandidates++;
        const cover = faces[candidate];
        const x = cover.axes[0], y = cover.axes[1];
        if (Math.min(face.bounds.max[x], cover.bounds.max[x]) <= Math.max(face.bounds.min[x], cover.bounds.min[x]) || Math.min(face.bounds.max[y], cover.bounds.max[y]) <= Math.max(face.bounds.min[y], cover.bounds.min[y]))
          return;
        if (!physicalSpatialBoundsOverlap(face.bounds, cover.bounds))
          return;
        if (!onPlane(face.vertices, cover.vertices[0]) || !onPlane(face.vertices, cover.vertices[1]) || !onPlane(face.vertices, cover.vertices[2]))
          return;
        candidates.push(candidate);
      });
      broadPhaseCandidates += earlierCandidates;
      coplanarCandidates += candidates.length;
      if (!candidates.length) {
        const target2 = pieces[face.mesh];
        let base = target2.get("[]");
        if (!base) {
          base = { coveredBy: [], vertices: storage(meshes[face.mesh].vertices.length) };
          target2.set("[]", base);
        }
        appendTriangle(base.vertices, face.vertices);
        return;
      }
      candidates.sort((a, b) => a - b);
      let regions = [{ vertices: face.vertices, coveredBy: [] }];
      for (const candidate of candidates) {
        const cover = faces[candidate];
        const owner = meshes[cover.mesh].key, next = [];
        for (const region of regions) {
          const result2 = partition(region, cover, owner);
          next.push(...result2.regions);
          if (result2.overlap > 0) {
            const first = meshes[cover.mesh].object.id, later = meshes[face.mesh].object.id, pairKey = JSON.stringify([first, later]), pair = pairs.get(pairKey) ?? { first, later, area: 0 };
            pair.area += result2.overlap;
            pairs.set(pairKey, pair);
          }
        }
        regions = next;
      }
      if (regions.some((region) => region.coveredBy.length))
        partitionedTriangles++;
      const target = pieces[face.mesh];
      for (const region of regions) {
        const key = JSON.stringify(region.coveredBy), group = target.get(key) ?? { coveredBy: region.coveredBy, vertices: storage(key === "[]" ? meshes[face.mesh].vertices.length : Math.max(0, region.vertices.length - 2) * 21) };
        append(group.vertices, region.vertices);
        target.set(key, group);
      }
    });
  }
  const result = [];
  meshes.forEach((mesh, index) => {
    const groups = pieces[index], base = groups.get("[]");
    const baseVertices = base ? finish(base.vertices) : new Float64Array;
    result.push({ ...mesh, vertices: baseVertices, bounds: baseVertices.length ? meshBounds(baseVertices) : mesh.bounds });
    for (const [key, group] of groups)
      if (key !== "[]") {
        const vertices = finish(group.vertices);
        result.push({ ...mesh, vertices, bounds: meshBounds(vertices), lines: new Float64Array, lineMaterials: [], lineStyles: [], occludedBy: group.coveredBy });
      }
  });
  return { meshes: result, diagnostics: { broadPhaseCandidates, coplanarCandidates, triangles, partitionedTriangles, retainedCandidates: result.length - meshes.length, coincidentPairs: [...pairs.values()] } };
};
var visible = new WeakMap;
var indexed = new WeakSet;
var visiblePhysicalSurfaceOwners = (meshes, acceleration) => {
  let selected = visible.get(meshes);
  if (!selected) {
    const candidates = new Set(meshes.map((mesh) => mesh.key));
    selected = meshes.some((mesh) => mesh.occludedBy?.length) ? meshes.filter((mesh) => !mesh.occludedBy?.some((owner) => candidates.has(owner))) : meshes;
    visible.set(meshes, selected);
  }
  if (acceleration && selected !== meshes && !indexed.has(selected)) {
    derivePhysicalPickAcceleration(selected, acceleration);
    indexed.add(selected);
  }
  return selected;
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/render-buffers.ts
var preparePhysicalRenderBuffers = (meshes) => {
  const roles = [], indices = new Map;
  const role = (name) => {
    const prior = indices.get(name);
    if (prior !== undefined)
      return prior;
    const next = roles.length;
    roles.push(name);
    indices.set(name, next);
    return next;
  };
  const vertices = new Float32Array(meshes.reduce((count, mesh) => count + mesh.vertices.length / 7 * 8, 0)), lines = new Float32Array(meshes.reduce((count, mesh) => count + mesh.lines.length / 3 * 6, 0));
  let solidAt = 0, lineAt = 0;
  meshes.forEach((mesh, objectIndex) => {
    for (let at = 0;at < mesh.vertices.length; at += 7) {
      for (let component = 0;component < 6; component++)
        vertices[solidAt + component] = mesh.vertices[at + component];
      vertices[solidAt + 6] = role(mesh.materials?.[mesh.vertices[at + 6]] ?? mesh.object.materials?.[mesh.vertices[at + 6]] ?? mesh.object.material ?? mesh.object.kind);
      vertices[solidAt + 7] = objectIndex;
      solidAt += 8;
    }
    for (let at = 0;at < mesh.lines.length; at += 3) {
      lines[lineAt] = mesh.lines[at];
      lines[lineAt + 1] = mesh.lines[at + 1];
      lines[lineAt + 2] = mesh.lines[at + 2];
      lines[lineAt + 3] = role(mesh.lineMaterials?.[Math.floor(at / 6)] ?? "line");
      lines[lineAt + 4] = objectIndex;
      const style = mesh.lineStyles?.[Math.floor(at / 6)] ?? (mesh.object.kind === "context" ? "context" : "feature");
      lines[lineAt + 5] = style === "section" ? 2 : style === "context" ? 1 : 0;
      lineAt += 6;
    }
  });
  return { vertices, lines, roles, objectCount: meshes.length };
};
var physicalRenderMeshRanges = (meshes) => {
  const ranges = new Uint32Array(meshes.length * 4);
  let solid = 0, line = 0;
  meshes.forEach((mesh, index) => {
    const solids = mesh.vertices.length / 7, lines = mesh.lines.length / 3;
    if (!Number.isInteger(solids) || solids % 3 || !Number.isInteger(lines) || lines % 2 || solid + solids > 2 ** 32 - 1 || line + lines > 2 ** 32 - 1)
      throw Error("Physical render ranges exceed the exact native index address space");
    ranges.set([solid, solids, line, lines], index * 4);
    solid += solids;
    line += lines;
  });
  return ranges;
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/visible-elements.ts
var updatePhysicalOpaqueRunMask = (rows, objects, start, count, mask) => {
  if (!Number.isInteger(objects) || objects < 0 || mask.length !== objects || !Number.isInteger(start) || start < 0 || !Number.isInteger(count) || count < 1 || (start + count) * objects * 12 > rows.length)
    throw Error("Physical visibility mask does not match its actual instance table");
  let changed = false;
  for (let object = 0;object < objects; object++) {
    let visible2 = 0;
    for (let instance = start;instance < start + count; instance++) {
      const alpha = rows[(instance * objects + object) * 12 + 7];
      if (!Number.isFinite(alpha))
        throw Error("Physical instance visibility must be finite");
      if (alpha >= 1) {
        visible2 = 1;
        break;
      }
    }
    if (mask[object] !== visible2) {
      mask[object] = visible2;
      changed = true;
    }
  }
  return changed;
};
var physicalVisibleElements = (ranges, mask) => {
  if (ranges.length !== mask.length * 4)
    throw Error("Physical visibility ranges do not match their source mesh ordinals");
  let solidCount = 0, lineCount = 0;
  for (let mesh = 0;mesh < mask.length; mesh++)
    if (mask[mesh]) {
      solidCount += ranges[mesh * 4 + 1];
      lineCount += ranges[mesh * 4 + 3];
    }
  const solid = new Uint32Array(solidCount), lines = new Uint32Array(lineCount);
  let a = 0, b = 0;
  for (let mesh = 0;mesh < mask.length; mesh++)
    if (mask[mesh]) {
      const at = mesh * 4;
      for (let vertex2 = ranges[at], end = vertex2 + ranges[at + 1];vertex2 < end; vertex2++)
        solid[a++] = vertex2;
      for (let vertex2 = ranges[at + 2], end = vertex2 + ranges[at + 3];vertex2 < end; vertex2++)
        lines[b++] = vertex2;
    }
  return { solid, lines };
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/architecture-opacity.ts
var physicalArchitectureOpacity = (object, view) => object.kind === "wall" ? view.wallOpacity ?? 1 : object.kind === "slab" ? view.floorOpacity ?? 1 : 1;

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/object-table.ts
var write = (data, at, a, b, c, d) => {
  let changed = false;
  if (data[at] !== Math.fround(a)) {
    data[at] = a;
    changed = true;
  }
  if (data[at + 1] !== Math.fround(b)) {
    data[at + 1] = b;
    changed = true;
  }
  if (data[at + 2] !== Math.fround(c)) {
    data[at + 2] = c;
    changed = true;
  }
  if (data[at + 3] !== Math.fround(d)) {
    data[at + 3] = d;
    changed = true;
  }
  return changed;
};
var createPhysicalObjectTableRows = () => {
  const states = [], shownCache = new WeakMap;
  let target = null;
  return (data, base, draws, fallback, force = false) => {
    const allocated = force || target?.deref() !== data;
    target = new WeakRef(data);
    let changed = false, updatedInstances = 0, reusedInstances = 0;
    for (let instance = 0;instance < draws.length; instance++) {
      const draw = draws[instance], previous = states[instance], wall = draw.architecture?.wallOpacity ?? 1, floor = draw.architecture?.floorOpacity ?? 1, highlight = draw.highlight?.color ?? null;
      const sameHighlight = previous?.highlighted === draw.highlight?.occurrenceId && (previous?.highlight === highlight || previous?.highlight !== null && highlight !== null && previous?.highlight?.every((value, axis) => value === highlight[axis]));
      if (!allocated && previous && previous.asset.deref() === draw.asset && previous.base.deref() === base && previous.meshes.deref() === draw.meshes && previous.styles.deref() === draw.styles && previous.wall === wall && previous.floor === floor && previous.red === fallback[0] && previous.green === fallback[1] && previous.blue === fallback[2] && sameHighlight) {
        reusedInstances++;
        continue;
      }
      updatedInstances++;
      let shown = shownCache.get(draw.meshes);
      if (!shown || shown.base.deref() !== base) {
        const values = new Map;
        for (const mesh of draw.meshes)
          values.set(mesh.assetIndex ?? base.indexOf(mesh), mesh);
        shown = { base: new WeakRef(base), values };
        shownCache.set(draw.meshes, shown);
      }
      for (let object = 0;object < base.length; object++) {
        const mesh = base[object], displayed = shown.values.get(object), style = draw.styles[object], at = (instance * base.length + object) * 12, color = style?.color ?? fallback, offset = displayed?.offset ?? mesh.offset;
        changed = write(data, at, color[0], color[1], color[2], style?.color ? style.emphasis : 0) || changed;
        changed = write(data, at + 4, offset[0], offset[1], offset[2], displayed ? physicalArchitectureOpacity(mesh.object, draw.architecture ?? {}) : 0) || changed;
        const selection = draw.highlight?.occurrenceId === mesh.object.id ? draw.highlight.color : null;
        changed = write(data, at + 8, selection?.[0] ?? 0, selection?.[1] ?? 0, selection?.[2] ?? 0, selection ? 0.24 : 0) || changed;
      }
      states[instance] = { asset: new WeakRef(draw.asset), base: new WeakRef(base), meshes: new WeakRef(draw.meshes), styles: new WeakRef(draw.styles), wall, floor, red: fallback[0], green: fallback[1], blue: fallback[2], highlighted: draw.highlight?.occurrenceId, highlight: highlight ? [...highlight] : null };
    }
    states.length = draws.length;
    return { changed, updatedInstances, reusedInstances };
  };
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/backend.ts
var physicalMaterialColor = (palette, role) => {
  if (role === "line")
    return palette.line;
  if (role.startsWith("continuation/")) {
    const [, material, radius] = role.split("/");
    if (!material || !Number.isFinite(Number(radius)) || !(Number(radius) > 0))
      throw Error(`Invalid physical continuation material: ${role}`);
    return palette.materials[material] ?? palette.defaultMaterial;
  }
  if (role.startsWith("surface/")) {
    const [, accent, material] = role.split("/");
    if (accent !== "access" && accent !== "outage" || !material)
      throw Error(`Invalid physical surface decoration role: ${role}`);
    const base = palette.materials[material] ?? palette.defaultMaterial, overlay = palette.materials[accent] ?? palette.defaultMaterial;
    return base.map((value, axis) => value * 0.58 + overlay[axis] * 0.42);
  }
  return palette.materials[role] ?? palette.defaultMaterial;
};
var physicalVertexSource = `#version 300 es
precision highp float;
precision highp int;
layout(location=0) in vec3 position;
layout(location=1) in vec3 normal;
layout(location=2) in float materialIndex;
layout(location=3) in float objectIndex;
layout(location=4) in float strokeStyle;
layout(location=5) in mat4 instanceMatrix;
layout(location=9) in uint instanceData;
layout(location=10) in vec3 sourcePosition;
uniform sampler2D uObjects;
uniform int uObjectWidth;
uniform bool uOrdered;
out vec3 vNormal;
out vec3 vLocalPosition;
out float vCameraDepth;
flat out int vMaterial;
flat out int vObject;
flat out float vStroke;
flat out float vOpacity;
vec4 objectData(int i){return texelFetch(uObjects,ivec2(i%uObjectWidth,i/uObjectWidth),0);}
void main(){
  int i=int(instanceData)+int(objectIndex)*3;
  vec4 placement=objectData(i+1);
  gl_Position=placement.w<=0.?vec4(2.,2.,2.,1.):instanceMatrix*vec4(position+placement.xyz,1.);
  vCameraDepth=gl_Position.w;
  vLocalPosition=uOrdered?sourcePosition:position;
  vNormal=normal;vMaterial=int(materialIndex);vObject=i;vStroke=strokeStyle;vOpacity=placement.w;
}
`;
var physicalFragmentSource = `#version 300 es
precision highp float;
precision highp int;
in vec3 vNormal;
in vec3 vLocalPosition;
in float vCameraDepth;
flat in int vMaterial;
flat in int vObject;
flat in float vStroke;
flat in float vOpacity;
uniform sampler2D uMaterials;
uniform sampler2D uObjects;
uniform int uMaterialWidth;
uniform int uObjectWidth;
uniform float uDepthNear;
uniform bool uFlat;
uniform bool uLines;
uniform bool uArchitecturePass;
uniform vec2 uLineOpacity;
uniform vec3 uIllustrationLine;
out vec4 outColor;
void main(){
  if(vOpacity<=0.||(!uArchitecturePass&&vOpacity<1.))discard;
  // Original clip coordinates still own clipping and screen coverage. A
  // reversed floating camera depth avoids subtracting two almost equal clip
  // coordinates for widely viewed, genuinely thin physical objects.
  gl_FragDepth=uFlat||uDepthNear==0.?1.-gl_FragCoord.z:uDepthNear/vCameraDepth;
  vec3 n=normalize(vNormal);
  // Preserve the accepted illustration's Y-up lighting in scene-local Z-up.
  float light=uFlat?1.:.60+.10*n.z+.28*max(dot(n,normalize(vec3(-.45,.55,.88))),0.)+.12*max(dot(n,normalize(vec3(.65,-.8,.4))),0.);
  vec4 surface=texelFetch(uMaterials,ivec2(vMaterial%uMaterialWidth,vMaterial/uMaterialWidth),0);
  vec3 material=surface.rgb;
  vec4 state=texelFetch(uObjects,ivec2(vObject%uObjectWidth,vObject/uObjectWidth),0);
  float edgeAlpha=uFlat||vStroke>1.5?1.:vStroke>.5?uLineOpacity.y:uLineOpacity.x;
  // Operational severity accents the existing drawing contours. Recolouring
  // solid faces destroys the authored material hierarchy and, in Plan, turns
  // neighbouring machines into one opaque alarm block. The owner-qualified
  // status badge remains the explicit alarm/count target in either view.
  vec3 edge=mix(material,state.rgb,state.a);
  vec3 solid=material*light;
  // Interaction tint belongs to the existing surface, so it has exactly the
  // same depth/occlusion as its machinery. It is independent of alarm colour.
  int selectionAt=vObject+2;
  vec4 selection=texelFetch(uObjects,ivec2(selectionAt%uObjectWidth,selectionAt/uObjectWidth),0);
  solid=mix(solid,selection.rgb*light,selection.a);
  if(selection.a>0.)edge=selection.rgb;
  if(!uLines&&surface.a>.5){
    // Hatch is part of the owning floor fragment's material. Its local metre
    // coordinates are stable under pan/orbit; derivatives keep a fine stroke
    // without another coincident depth-tested line surface.
    float phase=(vLocalPosition.x-vLocalPosition.y)/.8;
    float width=fwidth(phase);
    float ink=1.-smoothstep(.5*width,1.5*width,abs(fract(phase+.5)-.5));
    solid=mix(solid,uIllustrationLine,ink*uLineOpacity.x*.42);
  }
  if(!uLines&&surface.a<0.){
    // A true clipping cap carries an architectural continuation hatch in its
    // owning material; no coplanar decal, added Z, or new physical occurrence.
    vec3 axis=abs(n);
    vec2 uv=axis.z>=axis.x&&axis.z>=axis.y?vLocalPosition.xy:axis.y>=axis.x?vLocalPosition.xz:vLocalPosition.yz;
    float phase=(uv.x-uv.y)/(-surface.a*.5);
    float width=fwidth(phase);
    float ink=1.-smoothstep(.5*width,1.5*width,abs(fract(phase+.5)-.5));
    solid=mix(solid,uIllustrationLine,ink*.65);
  }
  float alpha=(uLines?max(max(edgeAlpha,state.a),selection.a>0.?1.:0.):1.)*vOpacity;
  vec3 color=uLines?edge:solid;
  outColor=vec4(color,alpha);
}
`;
var createPhysicalBackend = (gl, initialPalette) => {
  let palette = initialPalette, disposed = false, frame = 0;
  const shaders = [], cache = new Map, maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE);
  let program = null;
  try {
    for (const [kind, source] of [[gl.VERTEX_SHADER, physicalVertexSource], [gl.FRAGMENT_SHADER, physicalFragmentSource]]) {
      const shader = gl.createShader(kind);
      if (!shader)
        throw new Error("Unable to allocate physical scene shader");
      shaders.push(shader);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS))
        throw new Error(gl.getShaderInfoLog(shader) ?? "Physical scene shader compilation failed");
    }
    program = gl.createProgram();
    if (!program)
      throw new Error("Unable to allocate physical scene program");
    for (const shader of shaders)
      gl.attachShader(program, shader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS))
      throw new Error(gl.getProgramInfoLog(program) ?? "Physical scene program linking failed");
  } catch (error) {
    if (program)
      gl.deleteProgram(program);
    throw error;
  } finally {
    for (const shader of shaders)
      gl.deleteShader(shader);
  }
  const ownedProgram = program, uniforms = Object.fromEntries(["uDepthNear", "uObjects", "uMaterials", "uObjectWidth", "uMaterialWidth", "uFlat", "uLines", "uArchitecturePass", "uOrdered", "uLineOpacity", "uIllustrationLine"].map((name) => [name, gl.getUniformLocation(ownedProgram, name)]));
  const metrics = { visibilityUploads: 0, indexBytes: 0, geometryUploads: 0, geometryBytes: 0, residentCpuBytes: 0, draws: 0, buffers: 0, programs: 1, textures: 0, textureBytes: 0, instanceBytes: 0, instanceUploads: 0, statusUploads: 0, paletteUploads: 0, evictions: 0, peakRequiredBytes: 0, liveBuffersAfterDisposal: null, liveProgramsAfterDisposal: null, liveTexturesAfterDisposal: null };
  const texture = () => {
    const value = gl.createTexture();
    if (!value)
      throw new Error("Unable to allocate physical material/status table");
    metrics.textures++;
    return { texture: value, width: 0, height: 0, data: new Float32Array };
  };
  const dimensions = (pixels) => {
    const width = Math.min(maxTextureSize, Math.max(1, pixels)), height = Math.max(1, Math.ceil(pixels / width));
    if (height > maxTextureSize)
      throw new Error("Physical instance table exceeds this GPU texture allocation");
    return { width, height };
  };
  const resizeTexture = (value, pixels) => {
    const next = dimensions(pixels);
    if (next.width === value.width && next.height === value.height)
      return false;
    metrics.textureBytes -= value.data.byteLength;
    value.width = next.width;
    value.height = next.height;
    value.data = new Float32Array(value.width * value.height * 4);
    metrics.textureBytes += value.data.byteLength;
    return true;
  };
  const uploadTexture = (value, allocation) => {
    gl.bindTexture(gl.TEXTURE_2D, value.texture);
    if (allocation) {
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, value.width, value.height, 0, gl.RGBA, gl.FLOAT, value.data);
    } else
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, value.width, value.height, gl.RGBA, gl.FLOAT, value.data);
  };
  const updatePalette = (asset) => {
    const colors = asset.roles.map((role) => physicalMaterialColor(palette, role)), signature = JSON.stringify(colors);
    if (signature === asset.paletteSignature)
      return;
    const allocation = resizeTexture(asset.materials, colors.length);
    colors.forEach((color, index) => {
      const role = asset.roles[index], pattern = role.startsWith("continuation/") ? -Number(role.split("/")[2]) : role.startsWith("surface/outage/") ? 1 : 0;
      asset.materials.data.set([color[0], color[1], color[2], pattern], index * 4);
    });
    gl.activeTexture(gl.TEXTURE0);
    uploadTexture(asset.materials, allocation);
    asset.paletteSignature = signature;
    metrics.paletteUploads++;
  };
  const indexBytes = (value) => (value.solidCount + value.lineCount) * Uint32Array.BYTES_PER_ELEMENT;
  const releaseVisible = (value) => {
    gl.deleteBuffer(value.solid);
    gl.deleteBuffer(value.lines);
    metrics.buffers -= 2;
    const bytes = indexBytes(value);
    metrics.geometryBytes -= bytes;
    metrics.indexBytes -= bytes;
    metrics.residentCpuBytes -= value.mask.byteLength;
  };
  const release = (asset) => {
    for (const value of asset.visible.values())
      releaseVisible(value);
    asset.visible.clear();
    metrics.residentCpuBytes -= asset.ranges.byteLength;
    gl.deleteBuffer(asset.solid);
    gl.deleteBuffer(asset.lines);
    gl.deleteBuffer(asset.instances);
    gl.deleteVertexArray(asset.vao);
    gl.deleteVertexArray(asset.lineVao);
    gl.deleteTexture(asset.materials.texture);
    gl.deleteTexture(asset.objects.texture);
    metrics.geometryBytes -= asset.geometryBytes;
    metrics.instanceBytes -= asset.instanceData.byteLength;
    metrics.textureBytes -= asset.materials.data.byteLength + asset.objects.data.byteLength;
    metrics.buffers -= 3;
    metrics.textures -= 2;
  };
  const createAsset = (draw) => {
    const solid = gl.createBuffer(), lines = gl.createBuffer(), instances = gl.createBuffer(), vao = gl.createVertexArray(), lineVao = gl.createVertexArray();
    if (!solid || !lines || !instances || !vao || !lineVao) {
      for (const buffer of [solid, lines, instances])
        if (buffer)
          gl.deleteBuffer(buffer);
      for (const array of [vao, lineVao])
        if (array)
          gl.deleteVertexArray(array);
      throw new Error("Unable to allocate physical render buffers");
    }
    let materials = null, objects = null;
    try {
      materials = texture();
      objects = texture();
      const setupInstances = () => {
        gl.bindBuffer(gl.ARRAY_BUFFER, instances);
        for (let column = 0;column < 4; column++) {
          const location = 5 + column;
          gl.enableVertexAttribArray(location);
          gl.vertexAttribPointer(location, 4, gl.FLOAT, false, 17 * 4, column * 16);
          gl.vertexAttribDivisor(location, 1);
        }
        gl.enableVertexAttribArray(9);
        gl.vertexAttribIPointer(9, 1, gl.UNSIGNED_INT, 17 * 4, 64);
        gl.vertexAttribDivisor(9, 1);
      };
      gl.bindVertexArray(vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, solid);
      gl.bufferData(gl.ARRAY_BUFFER, draw.asset.buffers.vertices, gl.STATIC_DRAW);
      for (const [location, components, offset] of [[0, 3, 0], [1, 3, 12], [2, 1, 24], [3, 1, 28]]) {
        gl.enableVertexAttribArray(location);
        gl.vertexAttribPointer(location, components, gl.FLOAT, false, 32, offset);
      }
      gl.disableVertexAttribArray(4);
      setupInstances();
      gl.bindVertexArray(lineVao);
      gl.bindBuffer(gl.ARRAY_BUFFER, lines);
      gl.bufferData(gl.ARRAY_BUFFER, draw.asset.buffers.lines, gl.STATIC_DRAW);
      for (const [location, components, offset] of [[0, 3, 0], [2, 1, 12], [3, 1, 16], [4, 1, 20]]) {
        gl.enableVertexAttribArray(location);
        gl.vertexAttribPointer(location, components, gl.FLOAT, false, 24, offset);
      }
      gl.disableVertexAttribArray(1);
      setupInstances();
      const geometryBytes = draw.asset.buffers.vertices.byteLength + draw.asset.buffers.lines.byteLength;
      const value = { identity: draw.asset.identity, solid, lines, instances, vao, lineVao, geometryBytes, materials, objects, ranges: physicalRenderMeshRanges(draw.asset.meshes), visible: new Map, visibilityRevision: 0, objectRows: createPhysicalObjectTableRows(), instanceData: new Float32Array, instanceWords: new Uint32Array, lastUsed: frame, roles: draw.asset.buffers.roles, paletteSignature: "" };
      metrics.residentCpuBytes += value.ranges.byteLength;
      metrics.geometryUploads++;
      metrics.geometryBytes += geometryBytes;
      metrics.buffers += 3;
      return value;
    } catch (error) {
      for (const buffer of [solid, lines, instances])
        gl.deleteBuffer(buffer);
      gl.deleteVertexArray(vao);
      gl.deleteVertexArray(lineVao);
      for (const table of [materials, objects])
        if (table) {
          gl.deleteTexture(table.texture);
          metrics.textures--;
        }
      throw error;
    }
  };
  const visiblePacket = (asset, start, count) => {
    const key = `${start}/${count}`;
    let value = asset.visible.get(key), created = false;
    if (!value) {
      const solid = gl.createBuffer(), lines = gl.createBuffer();
      if (!solid || !lines) {
        if (solid)
          gl.deleteBuffer(solid);
        if (lines)
          gl.deleteBuffer(lines);
        throw Error("Unable to allocate exact physical visibility indices");
      }
      value = { solid, lines, mask: new Uint8Array(asset.ranges.length / 4), solidCount: 0, lineCount: 0, revision: -1, lastUsed: frame };
      asset.visible.set(key, value);
      metrics.buffers += 2;
      metrics.residentCpuBytes += value.mask.byteLength;
      created = true;
    }
    value.lastUsed = frame;
    const changed = value.revision !== asset.visibilityRevision && updatePhysicalOpaqueRunMask(asset.objects.data, value.mask.length, start, count, value.mask);
    value.revision = asset.visibilityRevision;
    if (created || changed) {
      const prior = indexBytes(value), elements = physicalVisibleElements(asset.ranges, value.mask);
      value.solidCount = elements.solid.length;
      value.lineCount = elements.lines.length;
      const delta = indexBytes(value) - prior;
      metrics.geometryBytes += delta;
      metrics.indexBytes += delta;
      gl.bindVertexArray(asset.vao);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, value.solid);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, elements.solid, gl.DYNAMIC_DRAW);
      gl.bindVertexArray(asset.lineVao);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, value.lines);
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, elements.lines, gl.DYNAMIC_DRAW);
      metrics.visibilityUploads++;
    }
    return value;
  };
  const ownedBytes = () => metrics.geometryBytes + metrics.instanceBytes + metrics.textureBytes;
  const evictUnused = (required) => {
    for (const [key, value] of [...cache].filter(([key2]) => !required.has(key2)).sort(([, a], [, b]) => a.lastUsed - b.lastUsed)) {
      if (ownedBytes() <= metrics.peakRequiredBytes)
        break;
      release(value);
      cache.delete(key);
      metrics.evictions++;
    }
  };
  return {
    metrics,
    setPalette(value) {
      palette = value;
    },
    retainGeometryIdentities(identities) {
      let changed = false;
      for (const [key, value] of cache)
        if (!identities.has(value.identity)) {
          release(value);
          cache.delete(key);
          changed = true;
        }
      if (changed)
        metrics.peakRequiredBytes = 0;
    },
    draw(draws, depthNear = 0) {
      if (disposed)
        throw new Error("Physical scene renderer has been disposed");
      frame++;
      const groups = new Map;
      draws = draws.map((draw) => ({ ...draw, meshes: visiblePhysicalSurfaceOwners(draw.meshes) }));
      for (const draw of draws) {
        const list = groups.get(draw.asset.key) ?? [];
        list.push(draw);
        groups.set(draw.asset.key, list);
      }
      let requiredBytes = 0;
      for (const list of groups.values()) {
        const first = list[0];
        requiredBytes += first.asset.buffers.vertices.byteLength + first.asset.buffers.lines.byteLength + list.length * (17 + first.asset.meshes.length * 12) * 4 + first.asset.buffers.roles.length * 16;
      }
      metrics.peakRequiredBytes = Math.max(metrics.peakRequiredBytes, requiredBytes);
      const required = new Set(groups.keys());
      evictUnused(required);
      gl.enable(gl.DEPTH_TEST);
      gl.depthFunc(gl.GEQUAL);
      gl.depthMask(true);
      gl.disable(gl.CULL_FACE);
      gl.disable(gl.STENCIL_TEST);
      gl.colorMask(true, true, true, true);
      gl.useProgram(ownedProgram);
      gl.uniform1f(uniforms.uDepthNear, depthNear);
      gl.bindSampler(0, null);
      gl.bindSampler(1, null);
      gl.uniform1i(uniforms.uMaterials, 0);
      gl.uniform1i(uniforms.uObjects, 1);
      gl.uniform1i(uniforms.uOrdered, 0);
      gl.uniform2f(uniforms.uLineOpacity, palette.lineOpacity ?? 1, palette.contextLineOpacity ?? palette.lineOpacity ?? 1);
      gl.uniform3f(uniforms.uIllustrationLine, ...palette.line);
      gl.lineWidth(palette.lineWidth ?? 1);
      for (const [key, list] of groups) {
        const first = list[0], asset = cache.get(key) ?? createAsset(first);
        cache.set(key, asset);
        asset.lastUsed = frame;
        updatePalette(asset);
        const objectCount = first.asset.meshes.length, allocation = resizeTexture(asset.objects, list.length * objectCount * 3);
        let statusChanged = allocation;
        if (asset.instanceData.length !== list.length * 17) {
          metrics.instanceBytes -= asset.instanceData.byteLength;
          asset.instanceData = new Float32Array(list.length * 17);
          asset.instanceWords = new Uint32Array(asset.instanceData.buffer);
          metrics.instanceBytes += asset.instanceData.byteLength;
        }
        list.forEach((draw, instanceIndex) => {
          asset.instanceData.set(draw.matrix, instanceIndex * 17);
          asset.instanceWords[instanceIndex * 17 + 16] = instanceIndex * objectCount * 3;
        });
        statusChanged = asset.objectRows(asset.objects.data, first.asset.meshes, list, palette.defaultMaterial, allocation).changed || statusChanged;
        gl.bindBuffer(gl.ARRAY_BUFFER, asset.instances);
        gl.bufferData(gl.ARRAY_BUFFER, asset.instanceData, gl.DYNAMIC_DRAW);
        metrics.instanceUploads++;
        gl.activeTexture(gl.TEXTURE1);
        if (statusChanged) {
          uploadTexture(asset.objects, allocation);
          metrics.statusUploads++;
          asset.visibilityRevision++;
        } else
          gl.bindTexture(gl.TEXTURE_2D, asset.objects.texture);
      }
      const runs = [], next = new Map;
      for (const draw of draws) {
        const key = draw.asset.key, start = next.get(key) ?? 0, previous = runs.at(-1);
        next.set(key, start + 1);
        if (previous?.key === key && previous.flat === draw.flat)
          previous.count++;
        else
          runs.push({ key, start, count: 1, flat: draw.flat });
      }
      gl.uniform1i(uniforms.uArchitecturePass, 0);
      gl.depthMask(true);
      for (const run of runs) {
        const asset = cache.get(run.key), selection = visiblePacket(asset, run.start, run.count);
        gl.activeTexture(gl.TEXTURE1);
        gl.bindTexture(gl.TEXTURE_2D, asset.objects.texture);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, asset.materials.texture);
        gl.uniform1i(uniforms.uMaterialWidth, asset.materials.width);
        gl.uniform1i(uniforms.uObjectWidth, asset.objects.width);
        gl.uniform1i(uniforms.uFlat, Number(run.flat));
        const instancesAt = (vao) => {
          gl.bindVertexArray(vao);
          gl.bindBuffer(gl.ARRAY_BUFFER, asset.instances);
          for (let column = 0;column < 4; column++)
            gl.vertexAttribPointer(5 + column, 4, gl.FLOAT, false, 17 * 4, run.start * 17 * 4 + column * 16);
          gl.vertexAttribIPointer(9, 1, gl.UNSIGNED_INT, 17 * 4, run.start * 17 * 4 + 64);
        };
        gl.disable(gl.BLEND);
        gl.depthFunc(gl.GREATER);
        gl.uniform1i(uniforms.uLines, 0);
        gl.disable(gl.POLYGON_OFFSET_FILL);
        instancesAt(asset.vao);
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, selection.solid);
        gl.drawElementsInstanced(gl.TRIANGLES, selection.solidCount, gl.UNSIGNED_INT, 0, run.count);
        metrics.draws++;
        if (selection.lineCount) {
          gl.depthFunc(gl.GEQUAL);
          gl.disable(gl.POLYGON_OFFSET_FILL);
          gl.enable(gl.BLEND);
          gl.blendEquationSeparate(gl.FUNC_ADD, gl.FUNC_ADD);
          gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
          gl.uniform1i(uniforms.uLines, 1);
          instancesAt(asset.lineVao);
          gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, selection.lines);
          gl.drawElementsInstanced(gl.LINES, selection.lineCount, gl.UNSIGNED_INT, 0, run.count);
          metrics.draws++;
        }
      }
      for (const asset of cache.values())
        for (const [key, value] of asset.visible)
          if (value.lastUsed !== frame) {
            releaseVisible(value);
            asset.visible.delete(key);
          }
      const actualRequired = [...required].reduce((bytes, key) => {
        const value = cache.get(key);
        return bytes + value.geometryBytes + [...value.visible.values()].reduce((sum, packet) => sum + indexBytes(packet), 0) + value.instanceData.byteLength + value.materials.data.byteLength + value.objects.data.byteLength;
      }, 0);
      metrics.peakRequiredBytes = Math.max(metrics.peakRequiredBytes, actualRequired);
      evictUnused(required);
    },
    dispose() {
      if (disposed)
        return;
      const buffers = [...cache.values()].flatMap((value) => [value.solid, value.lines, value.instances, ...[...value.visible.values()].flatMap((packet) => [packet.solid, packet.lines])]), textures = [...cache.values()].flatMap((value) => [value.materials.texture, value.objects.texture]);
      for (const value of cache.values())
        release(value);
      cache.clear();
      gl.deleteProgram(ownedProgram);
      metrics.programs = 0;
      disposed = true;
      metrics.liveBuffersAfterDisposal = buffers.filter((buffer) => gl.isBuffer(buffer)).length;
      metrics.liveProgramsAfterDisposal = Number(gl.isProgram(ownedProgram));
      metrics.liveTexturesAfterDisposal = textures.filter((value) => gl.isTexture(value)).length;
    }
  };
};

// src/ui/map/physical-scene/spatial-index.ts
var area4 = (b) => {
  const x = b.max[0] - b.min[0], y = b.max[1] - b.min[1], z = b.max[2] - b.min[2];
  return 2 * (x * y + y * z + z * x);
};
var union2 = (values, ids, first = 0, end = ids.length) => {
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (let at = first;at < end; at++)
    for (let axis = 0;axis < 3; axis++) {
      const id = ids[at];
      min[axis] = Math.min(min[axis], values[id].min[axis]);
      max[axis] = Math.max(max[axis], values[id].max[axis]);
    }
  return { min, max };
};
var createPhysicalSpatialIndex2 = (values, query = "ray") => {
  if (query === "overlap")
    return createPhysicalOverlapSpatialIndex2(values);
  const nodes = [], order = [];
  const build = (ids, bounds = union2(values, ids)) => {
    const index = nodes.length, node = { bounds, left: -1, right: -1, first: 0, count: 0 };
    nodes.push(node);
    const parentArea = area4(bounds);
    if (ids.length > 1 && parentArea > 0) {
      const spans = bounds.max.map((value, axis2) => value - bounds.min[axis2]), axis = spans.indexOf(Math.max(...spans));
      ids.sort((a, b) => values[a].min[axis] + values[a].max[axis] - values[b].min[axis] - values[b].max[axis] || a - b);
      const middle = Math.floor(ids.length / 2), left = ids.slice(0, middle), right = ids.slice(middle), leftBounds = union2(values, left), rightBounds = union2(values, right);
      const splitCost = 1 + (area4(leftBounds) * left.length + area4(rightBounds) * right.length) / parentArea;
      if (splitCost < ids.length) {
        node.left = build(left, leftBounds);
        node.right = build(right, rightBounds);
        return index;
      }
    }
    node.first = order.length;
    node.count = ids.length;
    order.push(...ids.sort((a, b) => a - b));
    return index;
  };
  if (values.length)
    build(values.map((_, index) => index));
  return { bounds: Float64Array.from(nodes.flatMap((node) => [...node.bounds.min, ...node.bounds.max])), children: Int32Array.from(nodes.flatMap((node) => [node.left, node.right])), ranges: Uint32Array.from(nodes.flatMap((node) => [node.first, node.count])), order: Uint32Array.from(order) };
};
var createPhysicalOverlapSpatialIndex2 = (values) => {
  const nodes = [], order = [];
  const sorted = [0, 1, 2].map((axis) => Uint32Array.from(values.map((_, id) => id).sort((a, b) => values[a].min[axis] + values[a].max[axis] - values[b].min[axis] - values[b].max[axis] || a - b)));
  const rank = sorted.map((ids) => {
    const result = new Uint32Array(values.length);
    ids.forEach((id, at) => {
      result[id] = at;
    });
    return result;
  }), scratch = new Uint32Array(values.length);
  const build = (first, end, bounds = union2(values, sorted[0], first, end)) => {
    const count = end - first, index = nodes.length, node = { bounds, left: -1, right: -1, first: 0, count: 0 };
    nodes.push(node);
    const parentArea = area4(bounds);
    if (count > 1 && parentArea > 0) {
      const middle = first + Math.floor(count / 2), leftCount = middle - first;
      let best;
      for (let axis = 0;axis < 3; axis++) {
        const left = union2(values, sorted[axis], first, middle), right = union2(values, sorted[axis], middle, end);
        const cost = 1 + (area4(left) * leftCount + area4(right) * (count - leftCount)) / parentArea;
        if (!best || cost < best.cost)
          best = { axis, cost, left, right };
      }
      if (best.cost < count) {
        const ranks = rank[best.axis], pivot = ranks[sorted[best.axis][middle]];
        for (let axis = 0;axis < 3; axis++) {
          const ids = sorted[axis];
          let left = first, right = middle;
          for (let at = first;at < end; at++) {
            const id = ids[at];
            scratch[ranks[id] < pivot ? left++ : right++] = id;
          }
          ids.set(scratch.subarray(first, end), first);
        }
        node.left = build(first, middle, best.left);
        node.right = build(middle, end, best.right);
        return index;
      }
    }
    node.first = order.length;
    node.count = count;
    order.push(...Array.from(sorted[0].subarray(first, end)).sort((a, b) => a - b));
    return index;
  };
  if (values.length)
    build(0, values.length);
  return { bounds: Float64Array.from(nodes.flatMap((node) => [...node.bounds.min, ...node.bounds.max])), children: Int32Array.from(nodes.flatMap((node) => [node.left, node.right])), ranges: Uint32Array.from(nodes.flatMap((node) => [node.first, node.count])), order: Uint32Array.from(order) };
};

// src/ui/map/physical-scene/picking.ts
var meshIndices2 = new WeakMap;
var sceneIndices2 = new WeakMap;
var inverses2 = new WeakMap;
var vertex2 = (mesh, at) => [mesh.vertices[at], mesh.vertices[at + 1], mesh.vertices[at + 2]];
var preparePhysicalMeshAcceleration2 = (mesh) => {
  const cached = meshIndices2.get(mesh);
  if (cached)
    return cached;
  const bounds = [];
  for (let at = 0;at < mesh.vertices.length; at += 21) {
    const a = vertex2(mesh, at), b = vertex2(mesh, at + 7), c = vertex2(mesh, at + 14);
    bounds.push({ min: [Math.min(a[0], b[0], c[0]), Math.min(a[1], b[1], c[1]), Math.min(a[2], b[2], c[2])], max: [Math.max(a[0], b[0], c[0]), Math.max(a[1], b[1], c[1]), Math.max(a[2], b[2], c[2])] });
  }
  const result = { triangles: createPhysicalSpatialIndex2(bounds) };
  meshIndices2.set(mesh, result);
  return result;
};
var preparePhysicalPickAcceleration2 = (meshes) => {
  const cached = sceneIndices2.get(meshes);
  if (cached)
    return cached;
  const result = { meshes: createPhysicalSpatialIndex2(meshes.map((mesh) => ({ min: mesh.bounds.min.map((value, axis) => value + mesh.offset[axis]), max: mesh.bounds.max.map((value, axis) => value + mesh.offset[axis]) }))), triangles: meshes.map(preparePhysicalMeshAcceleration2) };
  sceneIndices2.set(meshes, result);
  return result;
};
var derivePhysicalPickAcceleration2 = (meshes, source) => {
  for (const mesh of meshes) {
    const index = mesh.assetIndex;
    if (index === undefined || !source.triangles[index])
      throw new Error("Filtered physical fragment lost its source index");
    meshIndices2.set(mesh, source.triangles[index]);
  }
  preparePhysicalPickAcceleration2(meshes);
};

// src/ui/map/physical-scene/surface-ownership.ts
var visible2 = new WeakMap;
var indexed2 = new WeakSet;
var visiblePhysicalSurfaceOwners2 = (meshes, acceleration) => {
  let selected = visible2.get(meshes);
  if (!selected) {
    const candidates = new Set(meshes.map((mesh) => mesh.key));
    selected = meshes.some((mesh) => mesh.occludedBy?.length) ? meshes.filter((mesh) => !mesh.occludedBy?.some((owner) => candidates.has(owner))) : meshes;
    visible2.set(meshes, selected);
  }
  if (acceleration && selected !== meshes && !indexed2.has(selected)) {
    derivePhysicalPickAcceleration2(selected, acceleration);
    indexed2.add(selected);
  }
  return selected;
};

// src/ui/map/physical-scene/architecture-opacity.ts
var physicalArchitectureOpacity2 = (object, view) => object.kind === "wall" ? view.wallOpacity ?? 1 : object.kind === "slab" ? view.floorOpacity ?? 1 : 1;

// src/ui/map/physical-scene/object-table.ts
var write2 = (data, at, a, b, c, d) => {
  let changed = false;
  if (data[at] !== Math.fround(a)) {
    data[at] = a;
    changed = true;
  }
  if (data[at + 1] !== Math.fround(b)) {
    data[at + 1] = b;
    changed = true;
  }
  if (data[at + 2] !== Math.fround(c)) {
    data[at + 2] = c;
    changed = true;
  }
  if (data[at + 3] !== Math.fround(d)) {
    data[at + 3] = d;
    changed = true;
  }
  return changed;
};
var createPhysicalObjectTableRows2 = () => {
  const states = [], shownCache = new WeakMap;
  let target = null;
  return (data, base, draws, fallback, force = false) => {
    const allocated = force || target?.deref() !== data;
    target = new WeakRef(data);
    let changed = false, updatedInstances = 0, reusedInstances = 0;
    for (let instance = 0;instance < draws.length; instance++) {
      const draw = draws[instance], previous = states[instance], wall = draw.architecture?.wallOpacity ?? 1, floor = draw.architecture?.floorOpacity ?? 1, highlight = draw.highlight?.color ?? null;
      const sameHighlight = previous?.highlighted === draw.highlight?.occurrenceId && (previous?.highlight === highlight || previous?.highlight !== null && highlight !== null && previous?.highlight?.every((value, axis) => value === highlight[axis]));
      if (!allocated && previous && previous.asset.deref() === draw.asset && previous.base.deref() === base && previous.meshes.deref() === draw.meshes && previous.styles.deref() === draw.styles && previous.wall === wall && previous.floor === floor && previous.red === fallback[0] && previous.green === fallback[1] && previous.blue === fallback[2] && sameHighlight) {
        reusedInstances++;
        continue;
      }
      updatedInstances++;
      let shown = shownCache.get(draw.meshes);
      if (!shown || shown.base.deref() !== base) {
        const values = new Map;
        for (const mesh of draw.meshes)
          values.set(mesh.assetIndex ?? base.indexOf(mesh), mesh);
        shown = { base: new WeakRef(base), values };
        shownCache.set(draw.meshes, shown);
      }
      for (let object = 0;object < base.length; object++) {
        const mesh = base[object], displayed = shown.values.get(object), style = draw.styles[object], at = (instance * base.length + object) * 12, color = style?.color ?? fallback, offset = displayed?.offset ?? mesh.offset;
        changed = write2(data, at, color[0], color[1], color[2], style?.color ? style.emphasis : 0) || changed;
        changed = write2(data, at + 4, offset[0], offset[1], offset[2], displayed ? physicalArchitectureOpacity2(mesh.object, draw.architecture ?? {}) : 0) || changed;
        const selection = draw.highlight?.occurrenceId === mesh.object.id ? draw.highlight.color : null;
        changed = write2(data, at + 8, selection?.[0] ?? 0, selection?.[1] ?? 0, selection?.[2] ?? 0, selection ? 0.24 : 0) || changed;
      }
      states[instance] = { asset: new WeakRef(draw.asset), base: new WeakRef(base), meshes: new WeakRef(draw.meshes), styles: new WeakRef(draw.styles), wall, floor, red: fallback[0], green: fallback[1], blue: fallback[2], highlighted: draw.highlight?.occurrenceId, highlight: highlight ? [...highlight] : null };
    }
    states.length = draws.length;
    return { changed, updatedInstances, reusedInstances };
  };
};

// tests/browser/physical-scene/visible-index-reference.ts
var physicalMaterialColor2 = (palette, role) => {
  if (role === "line")
    return palette.line;
  if (role.startsWith("continuation/")) {
    const [, material, radius] = role.split("/");
    if (!material || !Number.isFinite(Number(radius)) || !(Number(radius) > 0))
      throw Error(`Invalid physical continuation material: ${role}`);
    return palette.materials[material] ?? palette.defaultMaterial;
  }
  if (role.startsWith("surface/")) {
    const [, accent, material] = role.split("/");
    if (accent !== "access" && accent !== "outage" || !material)
      throw Error(`Invalid physical surface decoration role: ${role}`);
    const base = palette.materials[material] ?? palette.defaultMaterial, overlay = palette.materials[accent] ?? palette.defaultMaterial;
    return base.map((value, axis) => value * 0.58 + overlay[axis] * 0.42);
  }
  return palette.materials[role] ?? palette.defaultMaterial;
};
var physicalVertexSource2 = `#version 300 es
precision highp float;
precision highp int;
layout(location=0) in vec3 position;
layout(location=1) in vec3 normal;
layout(location=2) in float materialIndex;
layout(location=3) in float objectIndex;
layout(location=4) in float strokeStyle;
layout(location=5) in mat4 instanceMatrix;
layout(location=9) in uint instanceData;
layout(location=10) in vec3 sourcePosition;
uniform sampler2D uObjects;
uniform int uObjectWidth;
uniform bool uOrdered;
out vec3 vNormal;
out vec3 vLocalPosition;
out float vCameraDepth;
flat out int vMaterial;
flat out int vObject;
flat out float vStroke;
flat out float vOpacity;
vec4 objectData(int i){return texelFetch(uObjects,ivec2(i%uObjectWidth,i/uObjectWidth),0);}
void main(){
  int i=int(instanceData)+int(objectIndex)*3;
  vec4 placement=objectData(i+1);
  gl_Position=placement.w<=0.?vec4(2.,2.,2.,1.):instanceMatrix*vec4(position+placement.xyz,1.);
  vCameraDepth=gl_Position.w;
  vLocalPosition=uOrdered?sourcePosition:position;
  vNormal=normal;vMaterial=int(materialIndex);vObject=i;vStroke=strokeStyle;vOpacity=placement.w;
}
`;
var physicalFragmentSource2 = `#version 300 es
precision highp float;
precision highp int;
in vec3 vNormal;
in vec3 vLocalPosition;
in float vCameraDepth;
flat in int vMaterial;
flat in int vObject;
flat in float vStroke;
flat in float vOpacity;
uniform sampler2D uMaterials;
uniform sampler2D uObjects;
uniform int uMaterialWidth;
uniform int uObjectWidth;
uniform float uDepthNear;
uniform bool uFlat;
uniform bool uLines;
uniform bool uArchitecturePass;
uniform vec2 uLineOpacity;
uniform vec3 uIllustrationLine;
out vec4 outColor;
void main(){
  if(vOpacity<=0.||(!uArchitecturePass&&vOpacity<1.))discard;
  // Original clip coordinates still own clipping and screen coverage. A
  // reversed floating camera depth avoids subtracting two almost equal clip
  // coordinates for widely viewed, genuinely thin physical objects.
  gl_FragDepth=uFlat||uDepthNear==0.?1.-gl_FragCoord.z:uDepthNear/vCameraDepth;
  vec3 n=normalize(vNormal);
  // Preserve the accepted illustration's Y-up lighting in scene-local Z-up.
  float light=uFlat?1.:.60+.10*n.z+.28*max(dot(n,normalize(vec3(-.45,.55,.88))),0.)+.12*max(dot(n,normalize(vec3(.65,-.8,.4))),0.);
  vec4 surface=texelFetch(uMaterials,ivec2(vMaterial%uMaterialWidth,vMaterial/uMaterialWidth),0);
  vec3 material=surface.rgb;
  vec4 state=texelFetch(uObjects,ivec2(vObject%uObjectWidth,vObject/uObjectWidth),0);
  float edgeAlpha=uFlat||vStroke>1.5?1.:vStroke>.5?uLineOpacity.y:uLineOpacity.x;
  // Operational severity accents the existing drawing contours. Recolouring
  // solid faces destroys the authored material hierarchy and, in Plan, turns
  // neighbouring machines into one opaque alarm block. The owner-qualified
  // status badge remains the explicit alarm/count target in either view.
  vec3 edge=mix(material,state.rgb,state.a);
  vec3 solid=material*light;
  // Interaction tint belongs to the existing surface, so it has exactly the
  // same depth/occlusion as its machinery. It is independent of alarm colour.
  int selectionAt=vObject+2;
  vec4 selection=texelFetch(uObjects,ivec2(selectionAt%uObjectWidth,selectionAt/uObjectWidth),0);
  solid=mix(solid,selection.rgb*light,selection.a);
  if(selection.a>0.)edge=selection.rgb;
  if(!uLines&&surface.a>.5){
    // Hatch is part of the owning floor fragment's material. Its local metre
    // coordinates are stable under pan/orbit; derivatives keep a fine stroke
    // without another coincident depth-tested line surface.
    float phase=(vLocalPosition.x-vLocalPosition.y)/.8;
    float width=fwidth(phase);
    float ink=1.-smoothstep(.5*width,1.5*width,abs(fract(phase+.5)-.5));
    solid=mix(solid,uIllustrationLine,ink*uLineOpacity.x*.42);
  }
  if(!uLines&&surface.a<0.){
    // A true clipping cap carries an architectural continuation hatch in its
    // owning material; no coplanar decal, added Z, or new physical occurrence.
    vec3 axis=abs(n);
    vec2 uv=axis.z>=axis.x&&axis.z>=axis.y?vLocalPosition.xy:axis.y>=axis.x?vLocalPosition.xz:vLocalPosition.yz;
    float phase=(uv.x-uv.y)/(-surface.a*.5);
    float width=fwidth(phase);
    float ink=1.-smoothstep(.5*width,1.5*width,abs(fract(phase+.5)-.5));
    solid=mix(solid,uIllustrationLine,ink*.65);
  }
  float alpha=(uLines?max(max(edgeAlpha,state.a),selection.a>0.?1.:0.):1.)*vOpacity;
  vec3 color=uLines?edge:solid;
  outColor=vec4(color,alpha);
}
`;
var createPhysicalBackend2 = (gl, initialPalette) => {
  let palette = initialPalette, disposed = false, frame = 0;
  const shaders = [], cache = new Map, maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE);
  let program = null;
  try {
    for (const [kind, source] of [[gl.VERTEX_SHADER, physicalVertexSource2], [gl.FRAGMENT_SHADER, physicalFragmentSource2]]) {
      const shader = gl.createShader(kind);
      if (!shader)
        throw new Error("Unable to allocate physical scene shader");
      shaders.push(shader);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS))
        throw new Error(gl.getShaderInfoLog(shader) ?? "Physical scene shader compilation failed");
    }
    program = gl.createProgram();
    if (!program)
      throw new Error("Unable to allocate physical scene program");
    for (const shader of shaders)
      gl.attachShader(program, shader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS))
      throw new Error(gl.getProgramInfoLog(program) ?? "Physical scene program linking failed");
  } catch (error) {
    if (program)
      gl.deleteProgram(program);
    throw error;
  } finally {
    for (const shader of shaders)
      gl.deleteShader(shader);
  }
  const ownedProgram = program, uniforms = Object.fromEntries(["uDepthNear", "uObjects", "uMaterials", "uObjectWidth", "uMaterialWidth", "uFlat", "uLines", "uArchitecturePass", "uOrdered", "uLineOpacity", "uIllustrationLine"].map((name) => [name, gl.getUniformLocation(ownedProgram, name)]));
  const metrics = { geometryUploads: 0, geometryBytes: 0, residentCpuBytes: 0, draws: 0, buffers: 0, programs: 1, textures: 0, textureBytes: 0, instanceBytes: 0, instanceUploads: 0, statusUploads: 0, paletteUploads: 0, evictions: 0, peakRequiredBytes: 0, liveBuffersAfterDisposal: null, liveProgramsAfterDisposal: null, liveTexturesAfterDisposal: null };
  const texture = () => {
    const value = gl.createTexture();
    if (!value)
      throw new Error("Unable to allocate physical material/status table");
    metrics.textures++;
    return { texture: value, width: 0, height: 0, data: new Float32Array };
  };
  const dimensions = (pixels) => {
    const width = Math.min(maxTextureSize, Math.max(1, pixels)), height = Math.max(1, Math.ceil(pixels / width));
    if (height > maxTextureSize)
      throw new Error("Physical instance table exceeds this GPU texture allocation");
    return { width, height };
  };
  const resizeTexture = (value, pixels) => {
    const next = dimensions(pixels);
    if (next.width === value.width && next.height === value.height)
      return false;
    metrics.textureBytes -= value.data.byteLength;
    value.width = next.width;
    value.height = next.height;
    value.data = new Float32Array(value.width * value.height * 4);
    metrics.textureBytes += value.data.byteLength;
    return true;
  };
  const uploadTexture = (value, allocation) => {
    gl.bindTexture(gl.TEXTURE_2D, value.texture);
    if (allocation) {
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, value.width, value.height, 0, gl.RGBA, gl.FLOAT, value.data);
    } else
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, value.width, value.height, gl.RGBA, gl.FLOAT, value.data);
  };
  const updatePalette = (asset) => {
    const colors = asset.roles.map((role) => physicalMaterialColor2(palette, role)), signature = JSON.stringify(colors);
    if (signature === asset.paletteSignature)
      return;
    const allocation = resizeTexture(asset.materials, colors.length);
    colors.forEach((color, index) => {
      const role = asset.roles[index], pattern = role.startsWith("continuation/") ? -Number(role.split("/")[2]) : role.startsWith("surface/outage/") ? 1 : 0;
      asset.materials.data.set([color[0], color[1], color[2], pattern], index * 4);
    });
    gl.activeTexture(gl.TEXTURE0);
    uploadTexture(asset.materials, allocation);
    asset.paletteSignature = signature;
    metrics.paletteUploads++;
  };
  const release = (asset) => {
    gl.deleteBuffer(asset.solid);
    gl.deleteBuffer(asset.lines);
    gl.deleteBuffer(asset.instances);
    gl.deleteVertexArray(asset.vao);
    gl.deleteVertexArray(asset.lineVao);
    gl.deleteTexture(asset.materials.texture);
    gl.deleteTexture(asset.objects.texture);
    metrics.geometryBytes -= asset.geometryBytes;
    metrics.instanceBytes -= asset.instanceData.byteLength;
    metrics.textureBytes -= asset.materials.data.byteLength + asset.objects.data.byteLength;
    metrics.buffers -= 3;
    metrics.textures -= 2;
  };
  const createAsset = (draw) => {
    const solid = gl.createBuffer(), lines = gl.createBuffer(), instances = gl.createBuffer(), vao = gl.createVertexArray(), lineVao = gl.createVertexArray();
    if (!solid || !lines || !instances || !vao || !lineVao) {
      for (const buffer of [solid, lines, instances])
        if (buffer)
          gl.deleteBuffer(buffer);
      for (const array of [vao, lineVao])
        if (array)
          gl.deleteVertexArray(array);
      throw new Error("Unable to allocate physical render buffers");
    }
    let materials = null, objects = null;
    try {
      materials = texture();
      objects = texture();
      const setupInstances = () => {
        gl.bindBuffer(gl.ARRAY_BUFFER, instances);
        for (let column = 0;column < 4; column++) {
          const location = 5 + column;
          gl.enableVertexAttribArray(location);
          gl.vertexAttribPointer(location, 4, gl.FLOAT, false, 17 * 4, column * 16);
          gl.vertexAttribDivisor(location, 1);
        }
        gl.enableVertexAttribArray(9);
        gl.vertexAttribIPointer(9, 1, gl.UNSIGNED_INT, 17 * 4, 64);
        gl.vertexAttribDivisor(9, 1);
      };
      gl.bindVertexArray(vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, solid);
      gl.bufferData(gl.ARRAY_BUFFER, draw.asset.buffers.vertices, gl.STATIC_DRAW);
      for (const [location, components, offset] of [[0, 3, 0], [1, 3, 12], [2, 1, 24], [3, 1, 28]]) {
        gl.enableVertexAttribArray(location);
        gl.vertexAttribPointer(location, components, gl.FLOAT, false, 32, offset);
      }
      gl.disableVertexAttribArray(4);
      setupInstances();
      gl.bindVertexArray(lineVao);
      gl.bindBuffer(gl.ARRAY_BUFFER, lines);
      gl.bufferData(gl.ARRAY_BUFFER, draw.asset.buffers.lines, gl.STATIC_DRAW);
      for (const [location, components, offset] of [[0, 3, 0], [2, 1, 12], [3, 1, 16], [4, 1, 20]]) {
        gl.enableVertexAttribArray(location);
        gl.vertexAttribPointer(location, components, gl.FLOAT, false, 24, offset);
      }
      gl.disableVertexAttribArray(1);
      setupInstances();
      const geometryBytes = draw.asset.buffers.vertices.byteLength + draw.asset.buffers.lines.byteLength;
      const value = { identity: draw.asset.identity, solid, lines, instances, vao, lineVao, count: draw.asset.buffers.vertices.length / 8, lineCount: draw.asset.buffers.lines.length / 6, geometryBytes, materials, objects, objectRows: createPhysicalObjectTableRows2(), instanceData: new Float32Array, instanceWords: new Uint32Array, lastUsed: frame, roles: draw.asset.buffers.roles, paletteSignature: "" };
      metrics.geometryUploads++;
      metrics.geometryBytes += geometryBytes;
      metrics.buffers += 3;
      return value;
    } catch (error) {
      for (const buffer of [solid, lines, instances])
        gl.deleteBuffer(buffer);
      gl.deleteVertexArray(vao);
      gl.deleteVertexArray(lineVao);
      for (const table of [materials, objects])
        if (table) {
          gl.deleteTexture(table.texture);
          metrics.textures--;
        }
      throw error;
    }
  };
  const ownedBytes = () => metrics.geometryBytes + metrics.instanceBytes + metrics.textureBytes;
  const evictUnused = (required) => {
    for (const [key, value] of [...cache].filter(([key2]) => !required.has(key2)).sort(([, a], [, b]) => a.lastUsed - b.lastUsed)) {
      if (ownedBytes() <= metrics.peakRequiredBytes)
        break;
      release(value);
      cache.delete(key);
      metrics.evictions++;
    }
  };
  return {
    metrics,
    setPalette(value) {
      palette = value;
    },
    retainGeometryIdentities(identities) {
      let changed = false;
      for (const [key, value] of cache)
        if (!identities.has(value.identity)) {
          release(value);
          cache.delete(key);
          changed = true;
        }
      if (changed)
        metrics.peakRequiredBytes = 0;
    },
    draw(draws, depthNear = 0) {
      if (disposed)
        throw new Error("Physical scene renderer has been disposed");
      frame++;
      const groups = new Map;
      draws = draws.map((draw) => ({ ...draw, meshes: visiblePhysicalSurfaceOwners2(draw.meshes) }));
      for (const draw of draws) {
        const list = groups.get(draw.asset.key) ?? [];
        list.push(draw);
        groups.set(draw.asset.key, list);
      }
      let requiredBytes = 0;
      for (const list of groups.values()) {
        const first = list[0];
        requiredBytes += first.asset.buffers.vertices.byteLength + first.asset.buffers.lines.byteLength + list.length * (17 + first.asset.meshes.length * 12) * 4 + first.asset.buffers.roles.length * 16;
      }
      metrics.peakRequiredBytes = Math.max(metrics.peakRequiredBytes, requiredBytes);
      const required = new Set(groups.keys());
      evictUnused(required);
      gl.enable(gl.DEPTH_TEST);
      gl.depthFunc(gl.GEQUAL);
      gl.depthMask(true);
      gl.disable(gl.CULL_FACE);
      gl.disable(gl.STENCIL_TEST);
      gl.colorMask(true, true, true, true);
      gl.useProgram(ownedProgram);
      gl.uniform1f(uniforms.uDepthNear, depthNear);
      gl.bindSampler(0, null);
      gl.bindSampler(1, null);
      gl.uniform1i(uniforms.uMaterials, 0);
      gl.uniform1i(uniforms.uObjects, 1);
      gl.uniform1i(uniforms.uOrdered, 0);
      gl.uniform2f(uniforms.uLineOpacity, palette.lineOpacity ?? 1, palette.contextLineOpacity ?? palette.lineOpacity ?? 1);
      gl.uniform3f(uniforms.uIllustrationLine, ...palette.line);
      gl.lineWidth(palette.lineWidth ?? 1);
      for (const [key, list] of groups) {
        const first = list[0], asset = cache.get(key) ?? createAsset(first);
        cache.set(key, asset);
        asset.lastUsed = frame;
        updatePalette(asset);
        const objectCount = first.asset.meshes.length, allocation = resizeTexture(asset.objects, list.length * objectCount * 3);
        let statusChanged = allocation;
        if (asset.instanceData.length !== list.length * 17) {
          metrics.instanceBytes -= asset.instanceData.byteLength;
          asset.instanceData = new Float32Array(list.length * 17);
          asset.instanceWords = new Uint32Array(asset.instanceData.buffer);
          metrics.instanceBytes += asset.instanceData.byteLength;
        }
        list.forEach((draw, instanceIndex) => {
          asset.instanceData.set(draw.matrix, instanceIndex * 17);
          asset.instanceWords[instanceIndex * 17 + 16] = instanceIndex * objectCount * 3;
        });
        statusChanged = asset.objectRows(asset.objects.data, first.asset.meshes, list, palette.defaultMaterial, allocation).changed || statusChanged;
        gl.bindBuffer(gl.ARRAY_BUFFER, asset.instances);
        gl.bufferData(gl.ARRAY_BUFFER, asset.instanceData, gl.DYNAMIC_DRAW);
        metrics.instanceUploads++;
        gl.activeTexture(gl.TEXTURE1);
        if (statusChanged) {
          uploadTexture(asset.objects, allocation);
          metrics.statusUploads++;
        } else
          gl.bindTexture(gl.TEXTURE_2D, asset.objects.texture);
      }
      const runs = [], next = new Map;
      for (const draw of draws) {
        const key = draw.asset.key, start = next.get(key) ?? 0, previous = runs.at(-1);
        next.set(key, start + 1);
        if (previous?.key === key && previous.flat === draw.flat)
          previous.count++;
        else
          runs.push({ key, start, count: 1, flat: draw.flat });
      }
      gl.uniform1i(uniforms.uArchitecturePass, 0);
      gl.depthMask(true);
      for (const run of runs) {
        const asset = cache.get(run.key);
        gl.activeTexture(gl.TEXTURE1);
        gl.bindTexture(gl.TEXTURE_2D, asset.objects.texture);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, asset.materials.texture);
        gl.uniform1i(uniforms.uMaterialWidth, asset.materials.width);
        gl.uniform1i(uniforms.uObjectWidth, asset.objects.width);
        gl.uniform1i(uniforms.uFlat, Number(run.flat));
        const instancesAt = (vao) => {
          gl.bindVertexArray(vao);
          gl.bindBuffer(gl.ARRAY_BUFFER, asset.instances);
          for (let column = 0;column < 4; column++)
            gl.vertexAttribPointer(5 + column, 4, gl.FLOAT, false, 17 * 4, run.start * 17 * 4 + column * 16);
          gl.vertexAttribIPointer(9, 1, gl.UNSIGNED_INT, 17 * 4, run.start * 17 * 4 + 64);
        };
        gl.disable(gl.BLEND);
        gl.depthFunc(gl.GREATER);
        gl.uniform1i(uniforms.uLines, 0);
        gl.disable(gl.POLYGON_OFFSET_FILL);
        instancesAt(asset.vao);
        gl.drawArraysInstanced(gl.TRIANGLES, 0, asset.count, run.count);
        metrics.draws++;
        if (asset.lineCount) {
          gl.depthFunc(gl.GEQUAL);
          gl.disable(gl.POLYGON_OFFSET_FILL);
          gl.enable(gl.BLEND);
          gl.blendEquationSeparate(gl.FUNC_ADD, gl.FUNC_ADD);
          gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
          gl.uniform1i(uniforms.uLines, 1);
          instancesAt(asset.lineVao);
          gl.drawArraysInstanced(gl.LINES, 0, asset.lineCount, run.count);
          metrics.draws++;
        }
      }
      const actualRequired = [...required].reduce((bytes, key) => {
        const value = cache.get(key);
        return bytes + value.geometryBytes + value.instanceData.byteLength + value.materials.data.byteLength + value.objects.data.byteLength;
      }, 0);
      metrics.peakRequiredBytes = Math.max(metrics.peakRequiredBytes, actualRequired);
      evictUnused(required);
    },
    dispose() {
      if (disposed)
        return;
      const buffers = [...cache.values()].flatMap((value) => [value.solid, value.lines, value.instances]), textures = [...cache.values()].flatMap((value) => [value.materials.texture, value.objects.texture]);
      for (const value of cache.values())
        release(value);
      cache.clear();
      gl.deleteProgram(ownedProgram);
      metrics.programs = 0;
      disposed = true;
      metrics.liveBuffersAfterDisposal = buffers.filter((buffer) => gl.isBuffer(buffer)).length;
      metrics.liveProgramsAfterDisposal = Number(gl.isProgram(ownedProgram));
      metrics.liveTexturesAfterDisposal = textures.filter((value) => gl.isTexture(value)).length;
    }
  };
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/render-pass.ts
var createPhysicalRenderPass = (gl) => {
  const colorSamples = [...gl.getInternalformatParameter(gl.RENDERBUFFER, gl.RGBA8, gl.SAMPLES)];
  const depthSamples = new Set([...gl.getInternalformatParameter(gl.RENDERBUFFER, gl.DEPTH_COMPONENT32F, gl.SAMPLES)]);
  const samples = Math.max(0, ...colorSamples.filter((value) => depthSamples.has(value)));
  const shaders = [];
  let program = null, vao = null;
  try {
    for (const [kind, source] of [[gl.VERTEX_SHADER, `#version 300 es
precision highp float;out vec2 uv;void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));uv=p;gl_Position=vec4(p*2.-1.,0.,1.);}`], [gl.FRAGMENT_SHADER, `#version 300 es
precision highp float;
in vec2 uv;uniform sampler2D image;out vec4 color;
void main(){color=texture(image,uv);}`]]) {
      const shader = gl.createShader(kind);
      if (!shader)
        throw Error("Unable to allocate physical composite shader");
      shaders.push(shader);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS))
        throw Error(gl.getShaderInfoLog(shader) ?? "physical composite shader compilation failed");
    }
    program = gl.createProgram();
    if (!program)
      throw Error("Unable to allocate physical composite program");
    for (const shader of shaders)
      gl.attachShader(program, shader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS))
      throw Error(gl.getProgramInfoLog(program) ?? "physical composite linking failed");
    vao = gl.createVertexArray();
    if (!vao)
      throw Error("Unable to allocate physical composite vertex array");
  } catch (error) {
    if (vao)
      gl.deleteVertexArray(vao);
    if (program)
      gl.deleteProgram(program);
    throw error;
  } finally {
    for (const shader of shaders)
      gl.deleteShader(shader);
  }
  const ownedProgram = program, ownedVao = vao, image = gl.getUniformLocation(ownedProgram, "image");
  let targets = null, disposed = false, allocations = 0, composites = 0;
  const final = { liveTextures: null, livePrograms: null, liveFramebuffers: null, liveRenderbuffers: null };
  const releaseTargets = (value) => {
    gl.deleteTexture(value.texture);
    gl.deleteRenderbuffer(value.depth);
    if (value.color)
      gl.deleteRenderbuffer(value.color);
    gl.deleteFramebuffer(value.resolve);
    if (value.draw !== value.resolve)
      gl.deleteFramebuffer(value.draw);
  };
  const allocate = (width, height, samples2) => {
    const texture = gl.createTexture(), resolve = gl.createFramebuffer(), depth = gl.createRenderbuffer(), color = samples2 > 0 ? gl.createRenderbuffer() : null, draw = samples2 > 0 ? gl.createFramebuffer() : resolve;
    const clean = () => {
      if (texture)
        gl.deleteTexture(texture);
      if (depth)
        gl.deleteRenderbuffer(depth);
      if (color)
        gl.deleteRenderbuffer(color);
      if (resolve)
        gl.deleteFramebuffer(resolve);
      if (draw && draw !== resolve)
        gl.deleteFramebuffer(draw);
    };
    if (!texture || !resolve || !depth || !draw || samples2 > 0 && !color) {
      clean();
      throw Error("Unable to allocate owned physical render target");
    }
    try {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
      gl.bindFramebuffer(gl.FRAMEBUFFER, resolve);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
      gl.bindFramebuffer(gl.FRAMEBUFFER, draw);
      gl.bindRenderbuffer(gl.RENDERBUFFER, depth);
      if (samples2 > 0)
        gl.renderbufferStorageMultisample(gl.RENDERBUFFER, samples2, gl.DEPTH_COMPONENT32F, width, height);
      else
        gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT32F, width, height);
      gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depth);
      if (color) {
        gl.bindRenderbuffer(gl.RENDERBUFFER, color);
        gl.renderbufferStorageMultisample(gl.RENDERBUFFER, samples2, gl.RGBA8, width, height);
        gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.RENDERBUFFER, color);
      }
      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE)
        throw Error("Owned physical render target is incomplete");
      gl.bindFramebuffer(gl.FRAMEBUFFER, resolve);
      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE)
        throw Error("Owned physical colour resolve target is incomplete");
      allocations++;
      return { width, height, samples: samples2, texture, draw, resolve, depth, color };
    } catch (error) {
      clean();
      throw error;
    }
  };
  return {
    begin(width, height) {
      if (disposed)
        throw Error("physical pass has been disposed");
      if (!targets || targets.width !== width || targets.height !== height || targets.samples !== samples) {
        if (targets)
          releaseTargets(targets);
        targets = null;
        targets = allocate(width, height, samples);
      }
      gl.bindFramebuffer(gl.FRAMEBUFFER, targets.draw);
      gl.viewport(0, 0, width, height);
      gl.disable(gl.SCISSOR_TEST);
      gl.depthRange(0, 1);
      gl.colorMask(true, true, true, true);
      gl.depthMask(true);
      gl.clearColor(0, 0, 0, 0);
      gl.clearDepth(0);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    },
    composite(draw, read, viewport) {
      if (!targets)
        throw Error("physical render target was not initialized");
      if (targets.draw !== targets.resolve) {
        gl.bindFramebuffer(gl.READ_FRAMEBUFFER, targets.draw);
        gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, targets.resolve);
        gl.blitFramebuffer(0, 0, targets.width, targets.height, 0, 0, targets.width, targets.height, gl.COLOR_BUFFER_BIT, gl.NEAREST);
      }
      gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, draw);
      gl.bindFramebuffer(gl.READ_FRAMEBUFFER, read);
      gl.viewport(...viewport);
      gl.disable(gl.SCISSOR_TEST);
      gl.disable(gl.DEPTH_TEST);
      gl.depthMask(false);
      gl.disable(gl.STENCIL_TEST);
      gl.disable(gl.CULL_FACE);
      gl.disable(gl.POLYGON_OFFSET_FILL);
      gl.enable(gl.BLEND);
      gl.blendEquationSeparate(gl.FUNC_ADD, gl.FUNC_ADD);
      gl.blendFuncSeparate(gl.ONE, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      gl.colorMask(true, true, true, true);
      gl.useProgram(ownedProgram);
      gl.bindVertexArray(ownedVao);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, targets.texture);
      gl.bindSampler(0, null);
      gl.uniform1i(image, 0);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      composites++;
    },
    metrics: () => ({ depthFormat: "float32", samples: targets?.samples ?? samples, programs: disposed ? 0 : 1, textures: targets ? 1 : 0, framebuffers: targets ? targets.draw === targets.resolve ? 1 : 2 : 0, renderbuffers: targets ? targets.color ? 2 : 1 : 0, bytes: targets ? targets.width * targets.height * 4 * (1 + (targets.color ? targets.samples * 2 : 1)) : 0, textureBytes: targets ? targets.width * targets.height * 4 : 0, allocations, composites, ...final }),
    dispose() {
      if (disposed)
        return;
      const prior = targets;
      if (prior)
        releaseTargets(prior);
      targets = null;
      gl.deleteProgram(ownedProgram);
      gl.deleteVertexArray(ownedVao);
      disposed = true;
      final.liveTextures = prior ? Number(gl.isTexture(prior.texture)) : 0;
      final.livePrograms = Number(gl.isProgram(ownedProgram));
      final.liveFramebuffers = prior ? Number(gl.isFramebuffer(prior.draw)) + (prior.draw !== prior.resolve ? Number(gl.isFramebuffer(prior.resolve)) : 0) : 0;
      final.liveRenderbuffers = prior ? Number(gl.isRenderbuffer(prior.depth)) + (prior.color ? Number(gl.isRenderbuffer(prior.color)) : 0) : 0;
    }
  };
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/architecture-bsp.ts
var position2 = (v) => [v[0], v[1], v[2]];
var cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
var subtract3 = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
var makePlane = (a, b, c) => {
  const normal = cross3(subtract3(b, a), subtract3(c, a)), magnitude = normal.map(Math.abs), axis = magnitude[0] >= magnitude[1] && magnitude[0] >= magnitude[2] ? 0 : magnitude[1] >= magnitude[2] ? 1 : 2;
  if (normal[axis] === 0)
    return null;
  if (!normal.every(Number.isFinite))
    throw new Error("Architecture BSP plane arithmetic is not finite");
  return { points: [a, b, c], normal, axes: [(axis + 1) % 3, (axis + 2) % 3] };
};
var signedDistance = (plane, p) => {
  const [a, b, c] = plane.points, ax = a[0] - p[0], ay = a[1] - p[1], az = a[2] - p[2], bx = b[0] - p[0], by = b[1] - p[1], bz = b[2] - p[2], cx = c[0] - p[0], cy = c[1] - p[1], cz = c[2] - p[2];
  const p0 = bx * cy, p1 = cx * by, p2 = cx * ay, p3 = ax * cy, p4 = ax * by, p5 = bx * ay;
  const determinant = az * (p0 - p1) + bz * (p2 - p3) + cz * (p4 - p5), permanent = Math.abs(az) * (Math.abs(p0) + Math.abs(p1)) + Math.abs(bz) * (Math.abs(p2) + Math.abs(p3)) + Math.abs(cz) * (Math.abs(p4) + Math.abs(p5));
  if (!Number.isFinite(determinant) || !Number.isFinite(permanent))
    throw new Error("Architecture BSP classification arithmetic is not finite");
  return Math.abs(determinant) <= (7 + 56 * Number.EPSILON) * Number.EPSILON * permanent ? 0 : -determinant;
};
var distance2 = (a, b, p, axes) => {
  const [x, y] = axes, left = (b[x] - a[x]) * (p[y] - a[y]), right = (b[y] - a[y]) * (p[x] - a[x]), value = left - right;
  return Math.abs(value) <= (3 + 16 * Number.EPSILON) * Number.EPSILON * (Math.abs(left) + Math.abs(right)) ? 0 : value;
};
var polygonArea = (vertices, axes) => {
  let sum = 0, magnitude = 0;
  for (let i = 1;i < vertices.length - 1; i++) {
    const value = distance2(vertices[0], vertices[i], vertices[i + 1], axes);
    sum += value;
    magnitude += Math.abs(value);
  }
  return Math.abs(sum) > (vertices.length * 4 + 2) * Number.EPSILON * magnitude ? Math.abs(sum) / 2 : 0;
};
var interpolate2 = (a, b, fraction) => a.map((value, index) => value + (b[index] - value) * fraction);
var splitPolygon2 = (vertices, distances) => {
  const front = [], back = [];
  for (let index = 0;index < vertices.length; index++) {
    const a = vertices[index], b = vertices[(index + 1) % vertices.length], da = distances[index], db = distances[(index + 1) % vertices.length];
    if (da >= 0)
      front.push(a);
    if (da <= 0)
      back.push(a);
    if (da > 0 && db < 0 || da < 0 && db > 0) {
      const cut = interpolate2(a, b, da / (da - db));
      front.push(cut);
      back.push(cut);
    }
  }
  return { front, back };
};
var bounds = (vertices) => {
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (const v of vertices)
    for (let axis = 0;axis < 3; axis++) {
      min[axis] = Math.min(min[axis], v[axis]);
      max[axis] = Math.max(max[axis], v[axis]);
    }
  return { min, max };
};
var partitionRegion = (region, cover) => {
  if (region.blockers.includes(cover.owner))
    return { regions: [region], overlap: false };
  const axes = cover.plane.axes, orientation = Math.sign(cover.plane.normal[3 - axes[0] - axes[1]]), pieces = [];
  let remaining = region.vertices;
  for (let edge = 0;edge < cover.vertices.length && remaining.length; edge++) {
    const distances = remaining.map((v) => distance2(cover.vertices[edge], cover.vertices[(edge + 1) % cover.vertices.length], v, axes) * orientation);
    if (distances.every((value) => value >= 0))
      continue;
    if (distances.every((value) => value <= 0))
      return { regions: [region], overlap: false };
    const result = splitPolygon2(remaining, distances);
    if (polygonArea(result.back, axes) > 0)
      pieces.push({ vertices: result.back, blockers: region.blockers });
    remaining = result.front;
  }
  if (!(polygonArea(remaining, axes) > 0))
    return { regions: [region], overlap: false };
  pieces.push({ vertices: remaining, blockers: [...region.blockers, cover.owner] });
  return { regions: pieces, overlap: true };
};
var transformVertex = (source, at, matrix, normal = true) => {
  const x = source[at], y = source[at + 1], z = source[at + 2];
  const common = [matrix[0] * x + matrix[4] * y + matrix[8] * z + matrix[12], matrix[1] * x + matrix[5] * y + matrix[9] * z + matrix[13], matrix[2] * x + matrix[6] * y + matrix[10] * z + matrix[14]];
  if (!common.every(Number.isFinite))
    throw new Error("Architecture BSP placement arithmetic is not finite");
  return [common[0], common[1], common[2], normal ? source[at + 3] : 0, normal ? source[at + 4] : 0, normal ? source[at + 5] : 0, x, y, z];
};
var validateInput = (input) => {
  if (typeof input.key !== "string" || !input.key)
    throw new Error("Architecture BSP requires an exact cohort key");
  const ids = new Set;
  for (const source of input.sources) {
    if (!source.id || ids.has(source.id) || !source.sceneId || !source.assetKey || !source.occurrenceId || !Number.isInteger(source.meshIndex) || source.meshIndex < 0)
      throw new Error("Architecture BSP source provenance is invalid or duplicated");
    ids.add(source.id);
    if (source.preparedOwnershipCohort !== undefined && (typeof source.preparedOwnershipCohort !== "string" || !source.preparedOwnershipCohort))
      throw new Error("Architecture BSP prepared ownership provenance is invalid");
    if (source.matrix.length !== 16 || !Array.from(source.matrix).every(Number.isFinite) || source.matrix[3] !== 0 || source.matrix[7] !== 0 || source.matrix[11] !== 0 || source.matrix[15] !== 1)
      throw new Error("Architecture BSP requires a finite affine placement matrix");
    if (source.vertices.length % 21 || source.lines.length % 6 || !Array.from(source.vertices).every(Number.isFinite) || !Array.from(source.lines).every(Number.isFinite))
      throw new Error("Architecture BSP source numeric buffers are invalid");
    if (!source.materials.length || source.materials.some((value) => typeof value !== "string" || !value))
      throw new Error("Architecture BSP source materials are invalid");
    for (let at = 6;at < source.vertices.length; at += 7)
      if (!Number.isInteger(source.vertices[at]) || !source.materials[source.vertices[at]])
        throw new Error("Architecture BSP material index is invalid");
    if (source.lineMaterials && source.lineMaterials.length !== source.lines.length / 6 || source.lineStyles && source.lineStyles.length !== source.lines.length / 6)
      throw new Error("Architecture BSP authored line metadata is invalid");
    if (source.lineMaterials?.some((value) => typeof value !== "string" || !value) || source.lineStyles?.some((value) => !["feature", "context", "section"].includes(value)))
      throw new Error("Architecture BSP authored line role is invalid");
  }
};
var choosePlane = (polygons, lines) => {
  if (!polygons.length) {
    return lines[0].plane;
  }
  const groups = [[], [], []];
  for (const polygon of polygons) {
    const axis = 3 - polygon.plane.axes[0] - polygon.plane.axes[1];
    groups[axis].push(polygon);
  }
  let selected = polygons[0].plane, score = Infinity;
  for (let axis = 0;axis < 3; axis++) {
    const group = groups[axis];
    if (!group.length)
      continue;
    group.sort((a, b) => {
      const ac = a.vertices.reduce((s, v) => s + v[axis], 0) / a.vertices.length, bc = b.vertices.reduce((s, v) => s + v[axis], 0) / b.vertices.length;
      return ac - bc || a.owner - b.owner || a.ordinal - b.ordinal;
    });
    const candidate = group[Math.floor(group.length / 2)].plane;
    let front = 0, back = 0, splits = 0;
    for (const polygon of polygons) {
      let positive = false, negative = false;
      for (const v of polygon.vertices) {
        const d = polygon.plane === candidate ? 0 : signedDistance(candidate, position2(v));
        positive ||= d > 0;
        negative ||= d < 0;
      }
      if (positive)
        front++;
      if (negative)
        back++;
      if (positive && negative)
        splits++;
    }
    const candidateScore = Math.max(front, back) + splits;
    if (candidateScore < score) {
      score = candidateScore;
      selected = candidate;
    }
  }
  return selected;
};
var preparePhysicalArchitectureBsp = (input) => {
  validateInput(input);
  const polygons = [], lines = [];
  let inputTriangles = 0, inputLines = 0, splitPolygons = 0, splitLines = 0, coplanarOverlaps = 0, retainedAlternatives = 0;
  input.sources.forEach((source, owner) => {
    for (let at = 0;at < source.vertices.length; at += 21) {
      const vertices2 = [transformVertex(source.vertices, at, source.matrix), transformVertex(source.vertices, at + 7, source.matrix), transformVertex(source.vertices, at + 14, source.matrix)], plane = makePlane(position2(vertices2[0]), position2(vertices2[1]), position2(vertices2[2]));
      inputTriangles++;
      if (!plane)
        continue;
      polygons.push({ vertices: vertices2, plane, owner, material: source.materials[source.vertices[at + 20]], ordinal: at / 21 });
    }
    for (let at = 0;at < source.lines.length; at += 6) {
      const a = transformVertex(source.lines, at, source.matrix, false), b = transformVertex(source.lines, at + 3, source.matrix, false);
      inputLines++;
      if (a[0] === b[0] && a[1] === b[1] && a[2] === b[2])
        continue;
      const direction = subtract3(position2(b), position2(a)), magnitudes = direction.map(Math.abs), axis = magnitudes.indexOf(Math.min(...magnitudes)), c = [a[0], a[1], a[2]];
      c[axis] = a[axis] === 0 ? 1 : 0;
      const plane = makePlane(position2(a), position2(b), c);
      if (!plane)
        throw new Error("Architecture BSP authored line cannot define a partition");
      lines.push({ plane, vertices: [a, b], owner, material: source.lineMaterials?.[at / 6] ?? "line", style: source.lineStyles?.[at / 6] ?? "feature", ordinal: at / 6 });
    }
  });
  const nodes = [], fragments = [], values = [];
  const append2 = (vertices2, kind, ownerIndex, material, occludedBy, strokeStyle) => {
    const first = values.length / 9;
    if (kind === "line")
      for (const vertex3 of vertices2)
        values.push(...vertex3);
    else
      for (let corner = 1;corner < vertices2.length - 1; corner++)
        for (const vertex3 of [vertices2[0], vertices2[corner], vertices2[corner + 1]])
          values.push(...vertex3);
    const id = fragments.length;
    fragments.push({ kind, ownerIndex, material, first, count: values.length / 9 - first, occludedBy, ...strokeStyle ? { strokeStyle } : {} });
    return id;
  };
  const tasks = [{ polygons, lines, parent: -1, side: "front" }];
  let root = -1;
  while (tasks.length) {
    const task = tasks.pop();
    if (!task.polygons.length && !task.lines.length)
      continue;
    const plane = choosePlane(task.polygons, task.lines), front = [], back = [], on = [], frontLines = [], backLines = [], onLines = [];
    const nodeIndex = nodes.length;
    nodes.push({ plane: plane.points, normal: plane.normal, front: -1, back: -1, fragments: [] });
    if (task.parent < 0)
      root = nodeIndex;
    else
      nodes[task.parent] = { ...nodes[task.parent], [task.side]: nodeIndex };
    for (const polygon of task.polygons) {
      const distances = polygon.vertices.map((v) => polygon.plane === plane ? 0 : signedDistance(plane, position2(v))), positive = distances.some((value) => value > 0), negative = distances.some((value) => value < 0);
      if (!positive && !negative)
        on.push(polygon);
      else if (!negative)
        front.push(polygon);
      else if (!positive)
        back.push(polygon);
      else {
        const result = splitPolygon2(polygon.vertices, distances);
        if (polygonArea(result.front, polygon.plane.axes) > 0)
          front.push({ ...polygon, vertices: result.front });
        if (polygonArea(result.back, polygon.plane.axes) > 0)
          back.push({ ...polygon, vertices: result.back });
        splitPolygons++;
      }
    }
    for (const line of task.lines) {
      const a = line.vertices[0], b = line.vertices[1];
      if (a[0] === b[0] && a[1] === b[1] && a[2] === b[2])
        continue;
      const da = line.plane === plane ? 0 : signedDistance(plane, position2(a)), db = line.plane === plane ? 0 : signedDistance(plane, position2(b));
      if (da === 0 && db === 0)
        onLines.push(line);
      else if (da >= 0 && db >= 0)
        frontLines.push(line);
      else if (da <= 0 && db <= 0)
        backLines.push(line);
      else {
        const cut = interpolate2(a, b, da / (da - db));
        if (da > 0) {
          frontLines.push({ ...line, vertices: [a, cut] });
          backLines.push({ ...line, vertices: [cut, b] });
        } else {
          backLines.push({ ...line, vertices: [a, cut] });
          frontLines.push({ ...line, vertices: [cut, b] });
        }
        splitLines++;
      }
    }
    on.sort((a, b) => a.owner - b.owner || a.ordinal - b.ordinal);
    const onBounds = on.map((polygon) => bounds(polygon.vertices)), index = createPhysicalSpatialIndex(onBounds, "overlap"), nodeFragments = [];
    on.forEach((polygon, ordinal) => {
      const candidates = [], priorCohort = input.sources[polygon.owner].preparedOwnershipCohort;
      visitPhysicalSpatialBounds(index, onBounds[ordinal], (candidate) => {
        if (priorCohort !== undefined && priorCohort === input.sources[on[candidate].owner].preparedOwnershipCohort)
          return;
        if (candidate >= ordinal || !physicalSpatialBoundsOverlap(onBounds[ordinal], onBounds[candidate]))
          return;
        const axes = plane.axes, a = onBounds[ordinal], b = onBounds[candidate];
        if (axes.some((axis) => Math.min(a.max[axis], b.max[axis]) <= Math.max(a.min[axis], b.min[axis])))
          return;
        candidates.push(candidate);
      });
      candidates.sort((a, b) => a - b);
      let regions = [{ vertices: polygon.vertices, blockers: [] }];
      for (const candidate of candidates) {
        const cover = on[candidate], next = [];
        for (const region of regions) {
          const result = partitionRegion(region, cover);
          if (result.overlap)
            coplanarOverlaps++;
          for (const piece of result.regions)
            if (!piece.blockers.includes(polygon.owner))
              next.push(piece);
        }
        regions = next;
        if (!regions.length)
          break;
      }
      for (const region of regions) {
        if (region.blockers.length)
          retainedAlternatives++;
        nodeFragments.push(append2(region.vertices, "triangle", polygon.owner, polygon.material, region.blockers));
      }
    });
    onLines.sort((a, b) => a.owner - b.owner || a.ordinal - b.ordinal);
    for (const line of onLines)
      nodeFragments.push(append2(line.vertices, "line", line.owner, line.material, [], line.style));
    nodes[nodeIndex] = { ...nodes[nodeIndex], fragments: nodeFragments };
    tasks.push({ polygons: back, lines: backLines, parent: nodeIndex, side: "back" }, { polygons: front, lines: frontLines, parent: nodeIndex, side: "front" });
  }
  const vertices = new Float64Array(values);
  return { key: input.key, owners: input.sources.map(({ id, sceneId, assetKey, meshIndex, occurrenceId }) => ({ id, sceneId, assetKey, meshIndex, occurrenceId })), vertices, fragments, nodes, root, diagnostics: { inputTriangles, inputLines, splitPolygons, splitLines, coplanarOverlaps, retainedAlternatives, vertexBytes: vertices.byteLength } };
};
var traversals = new WeakMap;
var orderedPhysicalArchitectureFragments = (bsp, eye, visibleOwners) => {
  if (eye.length !== 4 || !eye.every(Number.isFinite))
    throw new Error("Architecture BSP requires a finite homogeneous camera");
  const eyeScale = Math.max(Math.abs(eye[0]), Math.abs(eye[1]), Math.abs(eye[2]), Math.abs(eye[3]));
  if (eyeScale === 0)
    throw new Error("Architecture BSP camera has no point or direction");
  const ex = eye[0] / eyeScale, ey = eye[1] / eyeScale, ez = eye[2] / eyeScale, ew = eye[3] / eyeScale, orientation = eye[3] < 0 ? -1 : 1;
  let state = traversals.get(bsp);
  if (!state) {
    const normals = new Float64Array(bsp.nodes.length * 3);
    bsp.nodes.forEach((node, index) => {
      const n = node.normal, scale = Math.max(Math.abs(n[0]), Math.abs(n[1]), Math.abs(n[2]));
      normals[index * 3] = n[0] / scale;
      normals[index * 3 + 1] = n[1] / scale;
      normals[index * 3 + 2] = n[2] / scale;
    });
    state = { normals, currentOwners: new Uint8Array(bsp.owners.length), previousOwners: new Uint8Array(bsp.owners.length), currentSides: new Uint8Array(bsp.nodes.length), previousSides: new Uint8Array(bsp.nodes.length), order: null };
    traversals.set(bsp, state);
  }
  const { currentOwners: active, currentSides: sides } = state;
  active.fill(0);
  for (const owner of visibleOwners) {
    if (!Number.isInteger(owner) || owner < 0 || owner >= active.length)
      throw new Error("Architecture BSP visibility refers to an unknown owner");
    active[owner] = 1;
  }
  let changed = state.order === null;
  for (let index = 0;index < active.length; index++)
    if (active[index] !== state.previousOwners[index])
      changed = true;
  for (let index = 0;index < bsp.nodes.length; index++) {
    const a = bsp.nodes[index].plane[0], at = index * 3, n = state.normals, side = (n[at] * (ex - a[0] * ew) + n[at + 1] * (ey - a[1] * ew) + n[at + 2] * (ez - a[2] * ew)) * orientation;
    sides[index] = Number(side >= 0);
    if (sides[index] !== state.previousSides[index])
      changed = true;
  }
  if (!changed)
    return state.order;
  const result = [], stack = bsp.root < 0 ? [] : [bsp.root + 1];
  while (stack.length) {
    const token = stack.pop(), index = Math.abs(token) - 1, node = bsp.nodes[index];
    if (token < 0) {
      for (const id of node.fragments) {
        const fragment = bsp.fragments[id];
        if (!active[fragment.ownerIndex])
          continue;
        let blocked = false;
        for (const owner of fragment.occludedBy)
          if (active[owner]) {
            blocked = true;
            break;
          }
        if (!blocked)
          result.push(id);
      }
      continue;
    }
    const far = sides[index] ? node.back : node.front, near = sides[index] ? node.front : node.back;
    if (near >= 0)
      stack.push(near + 1);
    stack.push(-token);
    if (far >= 0)
      stack.push(far + 1);
  }
  state.previousOwners.set(active);
  state.previousSides.set(sides);
  state.order = result;
  return result;
};
var physicalArchitectureBspTraversalBytes = (bsp) => {
  const state = traversals.get(bsp);
  return state ? state.normals.byteLength + state.currentOwners.byteLength + state.previousOwners.byteLength + state.currentSides.byteLength + state.previousSides.byteLength : 0;
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/architecture-backend.ts
var createPhysicalArchitectureBackend = (gl, initialPalette) => {
  let palette = initialPalette, bsp = null, packet = null, program = null, disposed = false;
  let ownerState = new Float32Array, ownerPlacementKeys = [];
  let members = new Map;
  let opaqueSelections = new WeakMap;
  let uniforms = {};
  const maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE);
  const counts2 = { geometryUploads: 0, orderUploads: 0, instanceUploads: 0, statusUploads: 0, paletteUploads: 0, draws: 0 };
  const final = { liveBuffersAfterDisposal: null, liveProgramsAfterDisposal: null, liveTexturesAfterDisposal: null };
  const createProgram = () => {
    const shaders = [], value = gl.createProgram();
    if (!value)
      throw Error("Unable to allocate architecture ordering shader");
    try {
      for (const [kind, source] of [[gl.VERTEX_SHADER, physicalVertexSource], [gl.FRAGMENT_SHADER, physicalFragmentSource]]) {
        const shader = gl.createShader(kind);
        if (!shader)
          throw Error("Unable to allocate architecture shader");
        shaders.push(shader);
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS))
          throw Error(gl.getShaderInfoLog(shader) ?? "Architecture shader compilation failed");
        gl.attachShader(value, shader);
      }
      gl.linkProgram(value);
      if (!gl.getProgramParameter(value, gl.LINK_STATUS))
        throw Error(gl.getProgramInfoLog(value) ?? "Architecture shader linking failed");
      uniforms = Object.fromEntries(["uDepthNear", "uObjects", "uMaterials", "uObjectWidth", "uMaterialWidth", "uFlat", "uLines", "uArchitecturePass", "uOrdered", "uLineOpacity", "uIllustrationLine"].map((name) => [name, gl.getUniformLocation(value, name)]));
      return value;
    } catch (error) {
      gl.deleteProgram(value);
      throw error;
    } finally {
      for (const shader of shaders)
        gl.deleteShader(shader);
    }
  };
  const table = () => {
    const handle = gl.createTexture();
    if (!handle)
      throw Error("Unable to allocate architecture material/owner table");
    return { handle, width: 0, height: 0, data: new Float32Array };
  };
  const upload = (value, pixels, next) => {
    const width = Math.min(maxTextureSize, Math.max(1, pixels)), height = Math.max(1, Math.ceil(pixels / width));
    if (height > maxTextureSize)
      throw Error("Architecture owner table exceeds this GPU texture allocation");
    const allocate2 = width !== value.width || height !== value.height;
    const changed = allocate2 || next.some((item, index) => item !== value.data[index]);
    gl.bindTexture(gl.TEXTURE_2D, value.handle);
    if (!changed)
      return false;
    value.width = width;
    value.height = height;
    if (allocate2)
      value.data = new Float32Array(width * height * 4);
    value.data.fill(0);
    value.data.set(next);
    if (allocate2) {
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, width, height, 0, gl.RGBA, gl.FLOAT, value.data);
    } else
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, width, height, gl.RGBA, gl.FLOAT, value.data);
    return true;
  };
  const release = (value) => {
    gl.deleteBuffer(value.solid);
    gl.deleteBuffer(value.order);
    gl.deleteBuffer(value.instance);
    gl.deleteVertexArray(value.vao);
    gl.deleteTexture(value.objects.handle);
    gl.deleteTexture(value.materials.handle);
  };
  const allocate = (source) => {
    const solid = gl.createBuffer(), order = gl.createBuffer(), instance = gl.createBuffer(), vao = gl.createVertexArray();
    if (!solid || !order || !instance || !vao) {
      for (const value of [solid, order, instance])
        if (value)
          gl.deleteBuffer(value);
      if (vao)
        gl.deleteVertexArray(vao);
      throw Error("Unable to allocate derived architecture buffers");
    }
    let objects = null, materials = null;
    try {
      objects = table();
      materials = table();
      const roles = [], byRole = new Map, vertices = new Float32Array(source.vertices.length / 9 * 12);
      for (const fragment of source.fragments) {
        let role = byRole.get(fragment.material);
        if (role === undefined) {
          role = roles.length;
          roles.push(fragment.material);
          byRole.set(fragment.material, role);
        }
        for (let index = fragment.first;index < fragment.first + fragment.count; index++) {
          const at = index * 12, from = index * 9;
          for (let component = 0;component < 6; component++)
            vertices[at + component] = source.vertices[from + component];
          vertices[at + 6] = role;
          vertices[at + 7] = fragment.ownerIndex;
          vertices[at + 8] = fragment.strokeStyle === "section" ? 2 : fragment.strokeStyle === "context" ? 1 : 0;
          for (let component = 0;component < 3; component++)
            vertices[at + 9 + component] = source.vertices[from + 6 + component];
        }
      }
      gl.bindVertexArray(vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, solid);
      gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
      for (const [location, size, offset] of [[0, 3, 0], [1, 3, 12], [2, 1, 24], [3, 1, 28], [4, 1, 32], [10, 3, 36]]) {
        gl.enableVertexAttribArray(location);
        gl.vertexAttribPointer(location, size, gl.FLOAT, false, 48, offset);
      }
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, order);
      gl.bindBuffer(gl.ARRAY_BUFFER, instance);
      for (let column = 0;column < 4; column++) {
        const location = 5 + column;
        gl.enableVertexAttribArray(location);
        gl.vertexAttribPointer(location, 4, gl.FLOAT, false, 68, column * 16);
        gl.vertexAttribDivisor(location, 1);
      }
      gl.enableVertexAttribArray(9);
      gl.vertexAttribIPointer(9, 1, gl.UNSIGNED_INT, 68, 64);
      gl.vertexAttribDivisor(9, 1);
      counts2.geometryUploads++;
      return { solid, order, instance, vao, objects, materials, vertices, roles, indices: new Uint32Array, fragments: [], runs: [], paletteKey: "" };
    } catch (error) {
      for (const value of [solid, order, instance])
        gl.deleteBuffer(value);
      gl.deleteVertexArray(vao);
      if (objects)
        gl.deleteTexture(objects.handle);
      if (materials)
        gl.deleteTexture(materials.handle);
      throw error;
    }
  };
  return {
    setAsset(value) {
      if (disposed)
        return;
      if (bsp === value)
        return;
      if (bsp?.key === value?.key && value !== null)
        throw Error("Immutable architecture cohort changed its prepared asset");
      if (packet)
        release(packet);
      packet = null;
      bsp = value;
      ownerState = new Float32Array((value?.owners.length ?? 0) * 12);
      ownerPlacementKeys = value?.owners.map((owner) => JSON.stringify([owner.sceneId, owner.assetKey])) ?? [];
      members = new Map;
      opaqueSelections = new WeakMap;
      value?.owners.forEach((owner, index) => {
        const key = ownerPlacementKeys[index], group = members.get(key) ?? new Set;
        group.add(owner.meshIndex);
        members.set(key, group);
      });
    },
    setPalette(value) {
      palette = value;
    },
    opaqueDraws(draws) {
      if (!bsp || !draws.some((draw) => [draw.architecture?.wallOpacity ?? 1, draw.architecture?.floorOpacity ?? 1].some((alpha) => alpha > 0 && alpha < 1)))
        return draws;
      return draws.map((draw) => {
        const group = draw.sceneId === undefined ? undefined : members.get(JSON.stringify([draw.sceneId, draw.asset.key]));
        if (!group)
          return draw;
        let selections = opaqueSelections.get(draw.meshes);
        if (!selections) {
          selections = new Map;
          opaqueSelections.set(draw.meshes, selections);
        }
        let selected = selections.get(group);
        if (!selected) {
          selected = draw.meshes.filter((mesh) => !group.has(mesh.assetIndex ?? draw.asset.meshes.indexOf(mesh)));
          selections.set(group, selected);
        }
        return { ...draw, meshes: selected };
      });
    },
    draw(draws, depthNear = 0, commonMatrix) {
      if (disposed)
        throw Error("Architecture renderer has been disposed");
      if (!bsp || !bsp.owners.length)
        return;
      if (!draws.some((draw) => [draw.architecture?.wallOpacity ?? 1, draw.architecture?.floorOpacity ?? 1].some((alpha) => alpha > 0 && alpha < 1)))
        return;
      const placementKey = (sceneId, assetKey) => JSON.stringify([sceneId, assetKey]);
      const byPlacement = new Map(draws.filter((draw) => draw.sceneId !== undefined).map((draw) => [placementKey(draw.sceneId, draw.asset.key), draw]));
      const shown = new Map(draws.map((draw) => [draw, new Set(draw.meshes.map((mesh) => mesh.assetIndex ?? draw.asset.meshes.indexOf(mesh)))]));
      const basis = bsp.owners[0], reference = byPlacement.get(placementKey(basis.sceneId, basis.assetKey));
      const visible3 = new Set, ownerData = ownerState;
      ownerData.fill(0);
      let visibleDraw;
      bsp.owners.forEach((owner, index) => {
        const draw = byPlacement.get(ownerPlacementKeys[index]);
        if (!draw)
          return;
        const mesh = draw.asset.meshes[owner.meshIndex];
        if (!mesh || mesh.object.id !== owner.occurrenceId)
          throw Error("Architecture owner provenance differs from its prepared source");
        const displayed = shown.get(draw).has(owner.meshIndex);
        const alpha = displayed ? physicalArchitectureOpacity(mesh.object, draw.architecture ?? {}) : 0;
        if (alpha <= 0)
          return;
        visible3.add(index);
        visibleDraw ??= draw;
        const at = index * 12, style = draw.styles[owner.meshIndex], color = style?.color ?? palette.defaultMaterial;
        ownerData.set([...color, style?.color ? style.emphasis : 0], at);
        ownerData[at + 7] = alpha;
        if (draw.highlight?.occurrenceId === owner.occurrenceId)
          ownerData.set([...draw.highlight.color, 0.24], at + 8);
      });
      if (!visible3.size)
        return;
      const matrix = commonMatrix ?? reference?.matrix;
      if (!matrix)
        throw Error("Architecture cohort has no reference transform");
      const projection = inverse(matrix), eye = [-projection[8], -projection[9], -projection[10], -projection[11]];
      const ordered = orderedPhysicalArchitectureFragments(bsp, eye, visible3);
      if (!ordered.length)
        return;
      program ??= createProgram();
      packet ??= allocate(bsp);
      const value = packet;
      gl.useProgram(program);
      gl.bindVertexArray(value.vao);
      if (ordered !== value.fragments && (ordered.length !== value.fragments.length || ordered.some((id, at) => id !== value.fragments[at]))) {
        const indices = new Uint32Array(ordered.reduce((sum, id) => sum + bsp.fragments[id].count, 0));
        let at = 0;
        const runs = [];
        for (const id of ordered) {
          const fragment = bsp.fragments[id], previous = runs.at(-1);
          if (previous?.kind === fragment.kind)
            previous.count += fragment.count;
          else
            runs.push({ kind: fragment.kind, start: at, count: fragment.count });
          for (let index = 0;index < fragment.count; index++)
            indices[at++] = fragment.first + index;
        }
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, value.order);
        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.DYNAMIC_DRAW);
        value.indices = indices;
        value.runs = runs;
        counts2.orderUploads++;
      }
      value.fragments = ordered;
      const instance = new Float32Array(17);
      instance.set(matrix);
      gl.bindBuffer(gl.ARRAY_BUFFER, value.instance);
      gl.bufferData(gl.ARRAY_BUFFER, instance, gl.DYNAMIC_DRAW);
      counts2.instanceUploads++;
      gl.activeTexture(gl.TEXTURE1);
      if (upload(value.objects, bsp.owners.length * 3, ownerData))
        counts2.statusUploads++;
      gl.activeTexture(gl.TEXTURE0);
      const colors = value.roles.map((role) => physicalMaterialColor(palette, role)), paletteKey = JSON.stringify(colors);
      if (value.paletteKey !== paletteKey) {
        const data = new Float32Array(colors.length * 4);
        colors.forEach((color, at) => {
          const role = value.roles[at], pattern = role.startsWith("continuation/") ? -Number(role.split("/")[2]) : role.startsWith("surface/outage/") ? 1 : 0;
          data.set([...color, pattern], at * 4);
        });
        if (upload(value.materials, colors.length, data))
          counts2.paletteUploads++;
        value.paletteKey = paletteKey;
      } else
        gl.bindTexture(gl.TEXTURE_2D, value.materials.handle);
      gl.bindSampler(0, null);
      gl.bindSampler(1, null);
      gl.uniform1i(uniforms.uMaterials, 0);
      gl.uniform1i(uniforms.uObjects, 1);
      gl.uniform1i(uniforms.uMaterialWidth, value.materials.width);
      gl.uniform1i(uniforms.uObjectWidth, value.objects.width);
      gl.uniform1i(uniforms.uFlat, Number(visibleDraw.flat));
      gl.uniform1i(uniforms.uOrdered, 1);
      gl.uniform1i(uniforms.uArchitecturePass, 1);
      gl.uniform1f(uniforms.uDepthNear, depthNear);
      gl.uniform2f(uniforms.uLineOpacity, palette.lineOpacity ?? 1, palette.contextLineOpacity ?? palette.lineOpacity ?? 1);
      gl.uniform3f(uniforms.uIllustrationLine, ...palette.line);
      gl.lineWidth(palette.lineWidth ?? 1);
      gl.enable(gl.DEPTH_TEST);
      gl.depthMask(false);
      gl.disable(gl.CULL_FACE);
      gl.disable(gl.STENCIL_TEST);
      gl.disable(gl.POLYGON_OFFSET_FILL);
      gl.colorMask(true, true, true, true);
      gl.enable(gl.BLEND);
      gl.blendEquationSeparate(gl.FUNC_ADD, gl.FUNC_ADD);
      gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      for (const run of value.runs) {
        gl.uniform1i(uniforms.uLines, Number(run.kind === "line"));
        gl.depthFunc(run.kind === "line" ? gl.GEQUAL : gl.GREATER);
        gl.drawElementsInstanced(run.kind === "line" ? gl.LINES : gl.TRIANGLES, run.count, gl.UNSIGNED_INT, run.start * 4, 1);
        counts2.draws++;
      }
    },
    metrics: () => ({ ...counts2, geometryBytes: packet?.vertices.byteLength ?? 0, orderBytes: packet?.indices.byteLength ?? 0, instanceBytes: packet ? 68 : 0, traversalBytes: bsp ? physicalArchitectureBspTraversalBytes(bsp) : 0, residentCpuBytes: (bsp?.vertices.byteLength ?? 0) + (bsp ? physicalArchitectureBspTraversalBytes(bsp) : 0) + ownerState.byteLength + (packet ? packet.vertices.byteLength + packet.indices.byteLength + packet.objects.data.byteLength + packet.materials.data.byteLength : 0), buffers: packet ? 3 : 0, programs: program ? 1 : 0, textures: packet ? 2 : 0, textureBytes: packet ? packet.objects.data.byteLength + packet.materials.data.byteLength : 0, ...final }),
    dispose() {
      if (disposed)
        return;
      const prior = packet, priorProgram = program;
      if (prior)
        release(prior);
      if (priorProgram)
        gl.deleteProgram(priorProgram);
      final.liveBuffersAfterDisposal = prior ? [prior.solid, prior.order, prior.instance].filter((value) => gl.isBuffer(value)).length : 0;
      final.liveTexturesAfterDisposal = prior ? [prior.objects.handle, prior.materials.handle].filter((value) => gl.isTexture(value)).length : 0;
      final.liveProgramsAfterDisposal = priorProgram ? Number(gl.isProgram(priorProgram)) : 0;
      packet = null;
      bsp = null;
      program = null;
      ownerState = new Float32Array;
      ownerPlacementKeys = [];
      members.clear();
      opaqueSelections = new WeakMap;
      disposed = true;
    }
  };
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/layer-demand.ts
var layers = new WeakMap;
var physicalHiddenLayers = (scene, view) => new Set(view.hiddenLayerIds ?? scene.layers?.filter((layer) => !layer.defaultVisible).map((layer) => layer.id) ?? []);
var physicalMeshDemandScene = (scene, view) => {
  const hidden = physicalHiddenLayers(scene, view);
  if (!hidden.size)
    return scene;
  const objects = scene.objects.filter((object) => !object.layerId || !hidden.has(object.layerId)), planAnnotations = scene.planAnnotations?.filter((annotation) => !annotation.layerId || !hidden.has(annotation.layerId));
  return { ...scene, objects, ...planAnnotations ? { planAnnotations } : {} };
};

// ../../../Leitbild-campus-integration/apps/world/src/core/packs/scene-transfer.ts
var copyPhysicalSceneForTransfer = (scene) => {
  const transfers = new Set;
  const coordinates = new Map;
  const indices = new Map;
  const coordinateCopy = (values) => {
    const existing = coordinates.get(values);
    if (existing)
      return existing;
    const owned = new Float64Array(values);
    coordinates.set(values, owned);
    transfers.add(owned.buffer);
    return owned;
  };
  const indexCopy = (values) => {
    const existing = indices.get(values);
    if (existing)
      return existing;
    const owned = new Uint32Array(values);
    indices.set(values, owned);
    transfers.add(owned.buffer);
    return owned;
  };
  const objects = scene.objects.map((object) => ({
    ...object,
    positions: coordinateCopy(object.positions),
    ...object.normals === undefined ? {} : { normals: coordinateCopy(object.normals) },
    ...object.indices === undefined ? {} : { indices: indexCopy(object.indices) },
    ...object.materialIndices === undefined ? {} : { materialIndices: indexCopy(object.materialIndices) },
    ...object.featureLines === undefined ? {} : { featureLines: object.featureLines.map((line) => ({ ...line, positions: coordinateCopy(line.positions) })) },
    ...object.planLines === undefined ? {} : { planLines: object.planLines.map((line) => ({ ...line, positions: coordinateCopy(line.positions) })) }
  }));
  return { scene: { ...scene, objects }, transfers: [...transfers] };
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/surface-annotations.ts
var cross4 = (a, b, p) => (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]);
var interpolate3 = (a, b, fraction) => [a[0] + (b[0] - a[0]) * fraction, a[1] + (b[1] - a[1]) * fraction];
var area5 = (polygon) => polygon.reduce((sum, point, index) => {
  const next = polygon[(index + 1) % polygon.length];
  return sum + point[0] * next[1] - next[0] * point[1];
}, 0) / 2;
var clip = (polygon, triangle) => {
  let output = [...polygon];
  const orientation = Math.sign(area5(triangle));
  for (let edge = 0;edge < 3 && output.length; edge++) {
    const a = triangle[edge], b = triangle[(edge + 1) % 3], result = [];
    for (let index = 0;index < output.length; index++) {
      const start = output[index], end = output[(index + 1) % output.length], from = cross4(a, b, start) * orientation, to = cross4(a, b, end) * orientation;
      if (from >= 0)
        result.push(start);
      if (from >= 0 !== to >= 0)
        result.push(interpolate3(start, end, from / (from - to)));
    }
    output = result;
  }
  return output;
};
var physicalSurfaceAnnotations = (scene, view, meshes) => {
  if (view.mode !== "3d" || !scene.planAnnotations?.some((annotation) => annotation.kind === "hatch"))
    return meshes;
  const decorations = [];
  for (const annotation of scene.planAnnotations) {
    if (annotation.kind !== "hatch" || view.levelId !== "all" && !annotation.levelIds.includes(view.levelId) && !annotation.levelIds.includes("site"))
      continue;
    const z = annotation.outline[0][2];
    if (annotation.outline.some((point) => point[2] !== z))
      continue;
    const outline2 = annotation.outline.map((point) => [point[0], point[1]]), indices = earcut(outline2.flat(), undefined, 2);
    const minX = Math.min(...outline2.map((point) => point[0])), maxX = Math.max(...outline2.map((point) => point[0])), minY = Math.min(...outline2.map((point) => point[1])), maxY = Math.max(...outline2.map((point) => point[1]));
    for (const mesh of meshes) {
      if (mesh.object.kind !== "slab" && mesh.object.kind !== "pavement")
        continue;
      if (mesh.object.levelId === "site" ? !annotation.levelIds.includes("site") : mesh.levelId !== undefined && !annotation.levelIds.includes(mesh.levelId))
        continue;
      if (mesh.bounds.min[0] >= maxX || mesh.bounds.max[0] <= minX || mesh.bounds.min[1] >= maxY || mesh.bounds.max[1] <= minY || mesh.bounds.min[2] > z || mesh.bounds.max[2] < z)
        continue;
      if (!mesh.object.scopeIds?.some((id) => annotation.scopeIds.includes(id)))
        continue;
      const vertices = [], roles = [];
      for (let at = 0;at < mesh.vertices.length; at += 21) {
        const raw = mesh.vertices, ids = [at, at + 7, at + 14], face = ids.map((index) => [raw[index], raw[index + 1]]);
        if (ids.some((index) => raw[index + 2] !== z || raw[index + 5] <= 0) || area5(face) === 0)
          continue;
        const base = mesh.materials?.[raw[at + 6]] ?? mesh.object.materials?.[raw[at + 6]] ?? mesh.object.material ?? mesh.object.kind;
        const role = `surface/${annotation.role === "access" ? "access" : "outage"}/${base}`;
        let material = roles.indexOf(role);
        if (material < 0) {
          material = roles.length;
          roles.push(role);
        }
        for (let index = 0;index < indices.length; index += 3) {
          const polygon = clip(indices.slice(index, index + 3).map((id) => outline2[id]), face);
          if (polygon.length < 3 || !(area5(polygon) > 0))
            continue;
          for (let corner = 1;corner < polygon.length - 1; corner++)
            for (const point of [polygon[0], polygon[corner], polygon[corner + 1]])
              vertices.push(point[0], point[1], z, 0, 0, 1, material);
        }
      }
      if (!vertices.length)
        continue;
      decorations.push({ ...mesh, key: `${mesh.key}/annotation/${annotation.id}`, vertices: Float64Array.from(vertices), lines: new Float64Array, materials: roles, lineMaterials: [], lineStyles: [], bounds: meshBounds(vertices), annotation: { id: annotation.id, scopeIds: annotation.scopeIds, ...annotation.layerId ? { layerId: annotation.layerId } : {} } });
    }
  }
  return decorations.length ? [...decorations, ...meshes] : meshes;
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/scope-regions.ts
var physicalScopeRegions = (scene, scopeId) => {
  if (!scopeId)
    return [];
  const scopes = new Map((scene.scopes ?? []).map((scope) => [scope.id, scope])), selected = scopes.get(scopeId);
  if (!selected)
    throw Error(`Unknown physical inspection scope: ${scopeId}`);
  const members = selected.kind === "area" ? selected.members.map((id) => scopes.get(id)) : [selected];
  if (members.some((scope) => !scope))
    throw Error(`Physical inspection area has an unresolved member: ${scopeId}`);
  const unique = new Map(members.map((scope) => [JSON.stringify(scope.bounds), scope.bounds]));
  return [...unique.values()];
};
var subtract4 = (source, other) => {
  const low = source.min.map((value, axis) => Math.max(value, other.min[axis])), high = source.max.map((value, axis) => Math.min(value, other.max[axis]));
  if (low.some((value, axis) => value >= high[axis]))
    return [source];
  const min = [...source.min], max = [...source.max], result = [];
  for (let axis = 0;axis < 3; axis++) {
    if (min[axis] < low[axis]) {
      const end = [...max];
      end[axis] = low[axis];
      result.push({ min: [...min], max: end });
      min[axis] = low[axis];
    }
    if (max[axis] > high[axis]) {
      const begin = [...min];
      begin[axis] = high[axis];
      result.push({ min: begin, max: [...max] });
      max[axis] = high[axis];
    }
  }
  return result;
};
var disjointPhysicalScopeRegions = (regions) => {
  const result = [];
  for (const region of regions) {
    if (region.min.some((value, axis) => value >= region.max[axis]))
      throw Error("Scoped 3D route inspection requires positive spatial volume");
    let remaining = [region];
    for (const previous of result)
      remaining = remaining.flatMap((piece) => subtract4(piece, previous));
    result.push(...remaining);
  }
  return result;
};
var subtractRectangle = (face, other) => {
  const low = face.min.map((value, index) => Math.max(value, other.min[face.axes[index]])), high = face.max.map((value, index) => Math.min(value, other.max[face.axes[index]]));
  if (low.some((value, index) => value >= high[index]))
    return [face];
  const min = [...face.min], max = [...face.max], result = [];
  for (let axis = 0;axis < 2; axis++) {
    if (min[axis] < low[axis]) {
      const end = [...max];
      end[axis] = low[axis];
      result.push({ ...face, min: [...min], max: end });
      min[axis] = low[axis];
    }
    if (max[axis] > high[axis]) {
      const begin = [...min];
      begin[axis] = high[axis];
      result.push({ ...face, min: begin, max: [...max] });
      max[axis] = high[axis];
    }
  }
  return result;
};
var physicalScopeBoundaryFaces = (regions) => regions.flatMap((region, index) => [0, 1, 2].flatMap((axis) => [-1, 1].flatMap((outward) => {
  const coordinate = outward === -1 ? region.min[axis] : region.max[axis], axes = [(axis + 1) % 3, (axis + 2) % 3];
  let faces = [{ axis, coordinate, outward, axes, min: axes.map((axis2) => region.min[axis2]), max: axes.map((axis2) => region.max[axis2]) }];
  for (let other = 0;other < regions.length; other++)
    if (other !== index) {
      const next = regions[other], across = outward === 1 ? next.min[axis] <= coordinate && next.max[axis] > coordinate : next.min[axis] < coordinate && next.max[axis] >= coordinate;
      if (across)
        faces = faces.flatMap((face) => subtractRectangle(face, next));
    }
  return faces;
})));

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/scope-clipping.ts
var position3 = (p) => [p[0], p[1], p[2]];
var compare = (a, b) => a[0] - b[0] || a[1] - b[1] || a[2] - b[2];
var crossing = (a, b, axis, coordinate) => {
  if (compare(a, b) > 0)
    [a, b] = [b, a];
  const ratio = (coordinate - a[axis]) / (b[axis] - a[axis]);
  return a.map((value, component) => component === axis ? coordinate : component === 6 ? a[6] : value + (b[component] - value) * ratio);
};
var clipPlane = (polygon, axis, coordinate, keepAbove) => {
  const result = [];
  for (let i = 0;i < polygon.length; i++) {
    const a = polygon[i], b = polygon[(i + 1) % polygon.length], insideA = keepAbove ? a[axis] >= coordinate : a[axis] <= coordinate, insideB = keepAbove ? b[axis] >= coordinate : b[axis] <= coordinate;
    if (insideA)
      result.push(a);
    if (insideA !== insideB)
      result.push(crossing(a, b, axis, coordinate));
  }
  return result;
};
var clipBox = (polygon, box) => {
  let result = [...polygon];
  for (let axis = 0;axis < 3 && result.length; axis++)
    result = clipPlane(clipPlane(result, axis, box.min[axis], true), axis, box.max[axis], false);
  return result;
};
var append2 = (output, polygon) => {
  for (let i = 1;i < polygon.length - 1; i++) {
    const a = polygon[0], b = polygon[i], c = polygon[i + 1], u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
    if (Math.hypot(u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]) > 0)
      output.push(...a, ...b, ...c);
  }
};
var vertex3 = (values, at) => [values[at], values[at + 1], values[at + 2], values[at + 3], values[at + 4], values[at + 5], values[at + 6]];
var raw = (object) => {
  const result = [], count = object.indices?.length ?? object.positions.length / 3;
  for (let at = 0;at < count; at += 3) {
    const ids = [0, 1, 2].map((offset) => object.indices?.[at + offset] ?? at + offset), p = ids.map((index) => object.positions.slice(index * 3, index * 3 + 3)), a = p[1].map((v, axis) => v - p[0][axis]), b = p[2].map((v, axis) => v - p[0][axis]), n = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], length = Math.hypot(...n);
    for (const index of ids)
      result.push(object.positions[index * 3], object.positions[index * 3 + 1], object.positions[index * 3 + 2], object.normals?.[index * 3] ?? n[0] / (length || 1), object.normals?.[index * 3 + 1] ?? n[1] / (length || 1), object.normals?.[index * 3 + 2] ?? n[2] / (length || 1), object.materialIndices?.[index] ?? 0);
  }
  return Float64Array.from(result);
};
var area6 = (points, axes) => points.reduce((sum, p, index) => {
  const q = points[(index + 1) % points.length];
  return sum + p[axes[0]] * q[axes[1]] - q[axes[0]] * p[axes[1]];
}, 0) / 2;
var contains = (loop, p, axes) => {
  let inside = false;
  const [x, y] = axes;
  for (let i = 0, j = loop.length - 1;i < loop.length; j = i++) {
    const a = loop[i], b = loop[j];
    if (a[y] > p[y] !== b[y] > p[y] && p[x] < (b[x] - a[x]) * (p[y] - a[y]) / (b[y] - a[y]) + a[x])
      inside = !inside;
  }
  return inside;
};
var section = (vertices, face, material, label, coordinateScale) => {
  const points = [], edges = new Set, neighbours = new Map;
  const error = 32 * Number.EPSILON * coordinateScale;
  const pointId = (p) => {
    const found = points.findIndex((q) => p.every((value, axis) => Math.abs(value - q[axis]) <= error));
    if (found >= 0)
      return found;
    points.push(p);
    return points.length - 1;
  };
  for (let at = 0;at < vertices.length; at += 21) {
    const triangle = [vertex3(vertices, at), vertex3(vertices, at + 7), vertex3(vertices, at + 14)];
    if (triangle.every((p) => p[face.axis] === face.coordinate))
      continue;
    const intersections = [];
    for (let edge = 0;edge < 3; edge++) {
      const a = triangle[edge], b = triangle[(edge + 1) % 3], da = a[face.axis] - face.coordinate, db = b[face.axis] - face.coordinate;
      if (!da)
        intersections.push(pointId(position3(a)));
      if (da < 0 && db > 0 || da > 0 && db < 0)
        intersections.push(pointId(position3(crossing(a, b, face.axis, face.coordinate))));
    }
    const ids = [...new Set(intersections)];
    if (ids.length !== 2)
      continue;
    const key = [...ids].sort((a, b) => a - b).join(",");
    if (edges.has(key))
      continue;
    edges.add(key);
    for (const [a, b] of [ids, [...ids].reverse()]) {
      const set = neighbours.get(a) ?? new Set;
      set.add(b);
      neighbours.set(a, set);
    }
  }
  const loops = [], visited = new Set;
  for (const start of neighbours.keys()) {
    if (visited.has(start))
      continue;
    const component = [], pending = [start];
    while (pending.length) {
      const id = pending.pop();
      if (visited.has(id))
        continue;
      visited.add(id);
      component.push(id);
      pending.push(...neighbours.get(id));
    }
    if (component.some((id) => neighbours.get(id).size !== 2)) {
      const a = points[component[0]], b = points[component[1]], [x, y] = face.axes;
      if (component.every((id) => {
        const p = points[id], left = (b[x] - a[x]) * (p[y] - a[y]), right = (b[y] - a[y]) * (p[x] - a[x]);
        return Math.abs(left - right) <= 32 * Number.EPSILON * (Math.abs(left) + Math.abs(right));
      }))
        continue;
      throw Error(`Unable to form a closed inspection cut for ${label}`);
    }
    const loop = [];
    let previous = -1, current = start;
    do {
      loop.push(points[current]);
      const next = [...neighbours.get(current)].find((id) => id !== previous);
      previous = current;
      current = next;
    } while (current !== start);
    if (Math.abs(area6(loop, face.axes)) > 0)
      loops.push(loop);
  }
  const sizes = loops.map((loop) => Math.abs(area6(loop, face.axes))), parents = loops.map((loop, index) => {
    let parent = -1;
    for (let other = 0;other < loops.length; other++)
      if (sizes[other] > sizes[index] && contains(loops[other], loop[0], face.axes) && (parent < 0 || sizes[other] < sizes[parent]))
        parent = other;
    return parent;
  });
  const depth = (index) => parents[index] < 0 ? 0 : 1 + depth(parents[index]);
  const normal = [0, 0, 0];
  normal[face.axis] = face.outward;
  const result = [];
  for (let index = 0;index < loops.length; index++) {
    if (depth(index) % 2)
      continue;
    const polygon = [...loops[index]], holes = [];
    for (let child = 0;child < loops.length; child++)
      if (parents[child] === index) {
        holes.push(polygon.length);
        polygon.push(...loops[child]);
      }
    const indices = earcut(polygon.flatMap((p) => [p[face.axes[0]], p[face.axes[1]]]), holes, 2);
    for (let at = 0;at < indices.length; at += 3) {
      const triangle = indices.slice(at, at + 3).map((index2) => polygon[index2]);
      if (Math.sign(area6(triangle, face.axes)) !== face.outward)
        triangle.reverse();
      result.push(triangle.map((p) => [...p, ...normal, material]));
    }
  }
  return result;
};
var clipPhysicalMeshesToScope = (scene, view, meshes) => {
  if (view.mode !== "3d")
    return meshes;
  const selected = physicalScopeRegions(scene, view.scopeId);
  if (!selected.length && view.levelId === "all" && view.separation === 0)
    return meshes;
  return meshes.flatMap((mesh) => {
    const object = mesh.object;
    if (!object.clipToScope)
      return [mesh];
    if (!object.spatialPath)
      throw Error(`Scoped physical route has no spatial path: ${object.id}`);
    const bounds2 = object.bounds ?? mesh.bounds, floor = object.levelId !== "site" && (view.levelId !== "all" || view.separation > 0) ? object.inspectionLevels?.find((level) => level.levelId === mesh.levelId) : undefined;
    const regions = (selected.length ? selected : [bounds2]).map((region) => ({ min: region.min.map((value, axis) => axis === 2 && floor ? Math.max(value, floor.low) : value), max: region.max.map((value, axis) => axis === 2 && floor ? Math.min(value, floor.high) : value) })).filter((region) => region.min.every((value, axis) => value < region.max[axis]));
    if (!regions.some((region) => region.min.every((value, axis) => value < bounds2.max[axis] && region.max[axis] > bounds2.min[axis])))
      return [];
    const tagged = { ...mesh, ...view.scopeId ? { inspectionScopeId: view.scopeId } : {} };
    if (regions.some((region) => region.min.every((value, axis) => value <= bounds2.min[axis] && region.max[axis] >= bounds2.max[axis])))
      return [tagged];
    const cells = disjointPhysicalScopeRegions(regions), boundary = physicalScopeBoundaryFaces(cells), source = raw(object), output = [], roles = [...mesh.materials ?? object.materials ?? [object.material ?? object.kind]], coordinateScale = Math.max(...bounds2.min.map(Math.abs), ...bounds2.max.map(Math.abs));
    const continuation = `continuation/${object.material ?? roles[0]}/${object.spatialPath.radius}`, material = roles.length;
    roles.push(continuation);
    for (let at = 0;at < source.length; at += 21)
      for (const cell of cells)
        append2(output, clipBox([vertex3(source, at), vertex3(source, at + 7), vertex3(source, at + 14)], cell));
    const sections = new Map;
    for (const face of boundary) {
      if (face.coordinate <= bounds2.min[face.axis] || face.coordinate >= bounds2.max[face.axis])
        continue;
      const key = `${face.axis}/${face.coordinate}/${face.outward}`;
      let caps = sections.get(key);
      if (!caps) {
        caps = section(source, face, material, object.id, coordinateScale);
        sections.set(key, caps);
      }
      for (const triangle of caps) {
        let polygon = [...triangle];
        for (let axis = 0;axis < 2 && polygon.length; axis++)
          polygon = clipPlane(clipPlane(polygon, face.axes[axis], face.min[axis], true), face.axes[axis], face.max[axis], false);
        append2(output, polygon);
      }
    }
    if (!output.length)
      return [];
    const lines = [], materials = [], styles = [], seen = new Set;
    for (let at = 0;at < mesh.lines.length; at += 6)
      for (const cell of cells) {
        let a = mesh.lines.slice(at, at + 3), b = mesh.lines.slice(at + 3, at + 6), visible3 = true;
        for (let axis = 0;axis < 3; axis++)
          for (const [coordinate, above] of [[cell.min[axis], true], [cell.max[axis], false]]) {
            const inA = above ? a[axis] >= coordinate : a[axis] <= coordinate, inB = above ? b[axis] >= coordinate : b[axis] <= coordinate;
            if (!inA && !inB) {
              visible3 = false;
              break;
            }
            if (inA !== inB) {
              const p = position3(crossing([...a, 0, 0, 1, 0], [...b, 0, 0, 1, 0], axis, coordinate));
              if (inA)
                b = p;
              else
                a = p;
            }
          }
        if (!visible3 || a.every((value, axis) => value === b[axis]))
          continue;
        const role = mesh.lineMaterials?.[at / 6] ?? "line", style = mesh.lineStyles?.[at / 6] ?? "feature", key = [a.join(","), b.join(",")].sort().join("|") + `/${role}/${style}`;
        if (seen.has(key))
          continue;
        seen.add(key);
        lines.push(...a, ...b);
        materials.push(role);
        styles.push(style);
      }
    return [{ ...tagged, key: `${mesh.key}/spatial/${view.scopeId ?? "floors"}`, vertices: Float64Array.from(output), lines: Float64Array.from(lines), materials: roles, lineMaterials: materials, lineStyles: styles, bounds: meshBounds(output) }];
  });
};

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/preparation.ts
var preparePhysicalGeometry = (scene, view, key, identity = key) => {
  const demand = physicalMeshDemandScene(scene, view);
  const owned = preparePhysicalSurfaceOwnership(physicalSurfaceAnnotations(demand, view, clipPhysicalMeshesToScope(demand, view, buildVisibleMeshes(demand, view)))), meshes = owned.meshes.map((mesh, index) => ({ ...mesh, assetKey: key, assetIndex: index }));
  return { key, identity, meshes, acceleration: preparePhysicalPickAcceleration(meshes), buffers: preparePhysicalRenderBuffers(meshes), surfaceOwnership: owned.diagnostics };
};
var released = () => Object.assign(new Error("Physical preparation source lease was released"), { name: "AbortError" });
var physicalPreparedGeometryBuffers = (value) => {
  const buffers = new Set([value.buffers.vertices.buffer, value.buffers.lines.buffer]);
  for (const mesh of value.meshes)
    for (const values of [mesh.vertices, mesh.lines])
      if (ArrayBuffer.isView(values))
        buffers.add(values.buffer);
  for (const index of [value.acceleration.meshes, ...value.acceleration.triangles.map((item) => item.triangles)])
    for (const values of [index.bounds, index.children, index.ranges, index.order])
      buffers.add(values.buffer);
  return buffers;
};
var physicalPreparationWorkerBudget = (reported) => {
  if (reported === undefined)
    return 1;
  if (!Number.isInteger(reported) || reported < 1)
    throw new Error("Physical preparation requires a positive reported logical CPU count");
  return Math.max(1, reported - 1);
};
var createPhysicalPreparationPool = (workerFactory = () => {
  if (typeof Worker === "undefined")
    throw new Error("Physical layout preparation requires a module Worker");
  return new Worker(new URL("./preparation-worker.ts", import.meta.url), { type: "module" });
}, hardwareConcurrency = () => typeof navigator === "undefined" ? undefined : navigator.hardwareConcurrency) => {
  const sources = new Map, clients = new Map, jobs = new Map;
  const workers = new Set, affinity = new Map, workerBudget = physicalPreparationWorkerBudget(hardwareConcurrency());
  const shared = new Map;
  const pending = new Map, viewQueue = [];
  let sequence = 0, clientSequence = 0, registrations = 0, viewRequests = 0, transferredBytes = 0, cacheHits = 0, skippedViews = 0;
  const stopWorker = (worker) => {
    workers.delete(worker);
    worker.port.onmessage = null;
    worker.port.onerror = null;
    worker.port.terminate();
    for (const [identity, assigned] of affinity)
      if (assigned === worker)
        affinity.delete(identity);
  };
  const stopIfUnused = () => {
    for (const worker of workers)
      if (!worker.sources.size && ![...jobs.values()].some((job) => job.worker === worker))
        stopWorker(worker);
  };
  const releaseSource = (source) => {
    if (source.owners.size || source.pins || sources.get(source.key) !== source)
      return;
    if (source.registered)
      source.worker?.port.postMessage({ kind: "release", sourceKey: source.key }, []);
    const worker = source.worker;
    worker?.sources.delete(source);
    source.worker = null;
    sources.delete(source.key);
    if (worker && ![...worker.sources].some((candidate) => candidate.identity === source.identity))
      affinity.delete(source.identity);
    for (const [key, entry] of shared)
      if (entry.sourceKey === source.key)
        shared.delete(key);
    stopIfUnused();
  };
  const forgetPending = (job) => {
    if (pending.get(job.key)?.demands === job.demands)
      pending.delete(job.key);
  };
  const cancelUnneededQueued = () => {
    for (let at = viewQueue.length - 1;at >= 0; at--) {
      const id = viewQueue[at], job = jobs.get(id);
      if (job?.kind !== "view" || job.demands.size && job.source.owners.size)
        continue;
      viewQueue.splice(at, 1);
      jobs.delete(id);
      forgetPending(job);
      skippedViews++;
      job.reject(released());
    }
  };
  const dispatchView = () => {
    cancelUnneededQueued();
    for (let at = 0;at < viewQueue.length; ) {
      const id = viewQueue[at], job = jobs.get(id);
      if (job?.kind !== "view") {
        viewQueue.splice(at, 1);
        continue;
      }
      if (job.worker.activeView !== null) {
        at++;
        continue;
      }
      viewQueue.splice(at, 1);
      job.worker.activeView = id;
      try {
        job.worker.port.postMessage({ kind: "prepare", id, sourceKey: job.source.key, key: job.key, identity: job.identity, view: job.view }, []);
        viewRequests++;
      } catch (error) {
        job.worker.activeView = null;
        jobs.delete(id);
        forgetPending(job);
        job.reject(error instanceof Error ? error : new Error(String(error)));
      }
    }
  };
  const demand = (client, key, request, signal) => {
    if (signal?.aborted)
      return Promise.reject(released());
    const token = Symbol();
    request.demands.add(token);
    return new Promise((resolve, reject) => {
      const lease = { identity: request.identity, cancel: () => abort() };
      const cleanup = () => {
        signal?.removeEventListener("abort", abort);
        request.demands.delete(token);
        client.requests.delete(lease);
      };
      const abort = () => {
        cleanup();
        reject(released());
        cancelUnneededQueued();
        const running = [...workers].some((worker) => {
          const job = worker.activeView === null ? null : jobs.get(worker.activeView);
          return job?.kind === "view" && job.demands === request.demands;
        });
        if (!request.demands.size && !running && pending.get(key) === request)
          pending.delete(key);
      };
      client.requests.add(lease);
      signal?.addEventListener("abort", abort, { once: true });
      request.task.then((value) => {
        cleanup();
        resolve(value);
      }, (error) => {
        cleanup();
        reject(error);
      });
    });
  };
  const stopLastClient = () => {
    for (const worker of workers)
      stopWorker(worker);
    viewQueue.length = 0;
    const abandoned = [...jobs.values()];
    for (const source of sources.values())
      source.owners.clear();
    jobs.clear();
    sources.clear();
    shared.clear();
    pending.clear();
    for (const job of abandoned)
      job.reject(released());
  };
  const createWorker = () => {
    const owned = workerFactory(), worker = { port: owned, sources: new Set, activeView: null };
    workers.add(worker);
    owned.onmessage = (event) => {
      if (!workers.has(worker))
        return;
      const result = event.data, job = jobs.get(result.id);
      if (!job || job.worker !== worker)
        return;
      jobs.delete(result.id);
      if (job.kind === "view")
        worker.activeView = null;
      try {
        if (result.kind === "error")
          throw new Error(result.message);
        if (job.kind === "registration") {
          if (result.kind !== "registered" || result.sourceKey !== job.source.key)
            throw new Error("Physical source registration returned an incompatible identity");
          job.source.registered = true;
          job.resolve();
          return;
        }
        if (result.kind !== "prepared" || result.key !== job.key || result.identity !== job.identity || result.sourceKey !== job.source.key)
          throw new Error("Physical preparation returned an incompatible result");
        const meshes = result.meshes.map(({ objectIndex, ...mesh }) => {
          const object = job.scene.objects[objectIndex];
          if (!object)
            throw new Error("Prepared fragment names an unknown occurrence");
          return { ...mesh, object };
        });
        admitPhysicalPickAcceleration(meshes, result.acceleration);
        const value = { key: job.key, identity: job.identity, meshes, acceleration: result.acceleration, buffers: result.buffers, surfaceOwnership: result.surfaceOwnership };
        shared.set(job.key, { sourceKey: job.source.key, identity: job.identity, value: new WeakRef(value) });
        job.resolve(value);
      } catch (error) {
        job.reject(error instanceof Error ? error : new Error(String(error)));
      } finally {
        dispatchView();
      }
    };
    owned.onerror = (event) => {
      if (!workers.has(worker))
        return;
      stopWorker(worker);
      for (const source of worker.sources) {
        source.registered = false;
        source.registration = null;
        source.worker = null;
        source.bytes = 0;
      }
      worker.sources.clear();
      const error = new Error(`Physical preparation worker failed: ${event.message}`);
      for (const [id, job] of jobs)
        if (job.worker === worker) {
          jobs.delete(id);
          if (job.kind === "view")
            forgetPending(job);
          job.reject(error);
        }
      for (let at = viewQueue.length - 1;at >= 0; at--)
        if (!jobs.has(viewQueue[at]))
          viewQueue.splice(at, 1);
      dispatchView();
    };
    return worker;
  };
  const requireWorker = (source) => {
    if (source.worker)
      return source.worker;
    let worker = affinity.get(source.identity);
    if (!worker) {
      if (workers.size < workerBudget)
        worker = createWorker();
      else {
        const load = (value) => [...jobs.values()].filter((job) => job.worker === value).length;
        const bytes = (value) => [...value.sources].reduce((sum, source2) => sum + source2.bytes, 0);
        worker = [...workers].reduce((best, candidate) => {
          const comparison = load(candidate) - load(best) || bytes(candidate) - bytes(best) || candidate.sources.size - best.sources.size;
          return comparison < 0 ? candidate : best;
        });
      }
      affinity.set(source.identity, worker);
    }
    worker.sources.add(source);
    source.worker = worker;
    return worker;
  };
  const register = (source) => {
    if (source.registration)
      return source.registration;
    const task = new Promise((resolve, reject) => {
      const id = ++sequence;
      try {
        const worker = requireWorker(source);
        jobs.set(id, { kind: "registration", source, worker, resolve, reject });
        const packed = copyPhysicalSceneForTransfer(source.scene), bytes = packed.transfers.reduce((sum, buffer) => sum + buffer.byteLength, 0);
        worker.port.postMessage({ kind: "register", id, sourceKey: source.key, scene: packed.scene }, packed.transfers);
        source.bytes = bytes;
        registrations++;
        transferredBytes += bytes;
      } catch (error) {
        jobs.delete(id);
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
    source.registration = task;
    task.catch(() => {
      if (source.registration === task)
        source.registration = null;
    });
    return task;
  };
  const sourceFor = (scene, identity, sourceKey) => {
    let source = sources.get(sourceKey);
    if (source) {
      if (source.identity !== identity)
        throw new Error("Physical source registration key reused by a different geometry identity");
      return source;
    }
    source = { key: sourceKey, identity, scene, owners: new Set([...clients].filter(([, client]) => client.identities.has(identity)).map(([id]) => id)), pins: 0, registered: false, registration: null, bytes: 0, worker: null };
    sources.set(sourceKey, source);
    return source;
  };
  const diagnostics = () => {
    const retained = [...shared.values()].flatMap((entry) => {
      const value = entry.value.deref();
      return value ? [value] : [];
    });
    const buffers = new Set(retained.flatMap((value) => [...physicalPreparedGeometryBuffers(value)]));
    return { workerAlive: workers.size > 0, workerCount: workers.size, workerBudget, activeWorkers: [...workers].filter((worker) => worker.activeView !== null).length, clients: clients.size, registeredSources: [...sources.values()].filter((source) => source.registered).length, registeredBytes: [...sources.values()].reduce((bytes, source) => bytes + source.bytes, 0), leases: [...sources.values()].reduce((sum, source) => sum + source.owners.size, 0), inFlightJobs: jobs.size, pinnedSources: [...sources.values()].filter((source) => source.pins > 0).length, registrations, viewRequests, transferredBytes, retainedViews: retained.length, retainedViewBytes: [...buffers].reduce((bytes, buffer) => bytes + buffer.byteLength, 0), cacheHits, queuedViews: viewQueue.length, skippedViews };
  };
  return {
    createPreparer() {
      const owner = ++clientSequence, client = { identities: new Set, requests: new Set, explicit: false };
      clients.set(owner, client);
      let destroyed = false;
      const prepare = (scene, view, key, identity = key, sourceKey = identity, signal) => {
        if (destroyed || signal?.aborted)
          return Promise.reject(released());
        if (client.explicit && !client.identities.has(identity))
          return Promise.reject(released());
        if (!client.explicit)
          client.identities.add(identity);
        const source = sourceFor(scene, identity, sourceKey);
        source.owners.add(owner);
        for (const [name, value] of shared)
          if (!value.value.deref() && !pending.has(name))
            shared.delete(name);
        const cached = shared.get(key), cachedValue = cached?.value.deref();
        if (cachedValue) {
          if (cached.sourceKey !== sourceKey || cached.identity !== identity)
            return Promise.reject(new Error("Physical prepared key reused by a different source"));
          cacheHits++;
          return demand(client, key, { sourceKey, identity, demands: new Set, task: Promise.resolve(cachedValue) }, signal);
        }
        const existing = pending.get(key);
        if (existing) {
          if (existing.sourceKey !== sourceKey || existing.identity !== identity)
            return Promise.reject(new Error("Physical pending key reused by a different source"));
          return demand(client, key, existing, signal);
        }
        source.pins++;
        const demands = new Set;
        const task = (async () => {
          try {
            await register(source);
            if (!source.owners.size || !demands.size)
              throw released();
            return await new Promise((resolve, reject) => {
              const worker = source.worker;
              if (!worker) {
                reject(new Error("Registered physical source has no preparation worker"));
                return;
              }
              const id = ++sequence;
              jobs.set(id, { kind: "view", source, worker, scene, key, identity, view, demands, resolve, reject });
              viewQueue.push(id);
              dispatchView();
            });
          } finally {
            source.pins--;
            releaseSource(source);
          }
        })();
        const request = { sourceKey, identity, demands, task };
        pending.set(key, request);
        const clear = () => {
          if (pending.get(key) === request)
            pending.delete(key);
        };
        task.then(clear, clear);
        return demand(client, key, request, signal);
      };
      return Object.assign(prepare, {
        diagnostics,
        retainIdentities(identities) {
          if (destroyed)
            return;
          client.explicit = true;
          client.identities.clear();
          for (const identity of identities)
            client.identities.add(identity);
          for (const request of [...client.requests])
            if (!identities.has(request.identity))
              request.cancel();
          for (const source of sources.values()) {
            if (identities.has(source.identity))
              source.owners.add(owner);
            else
              source.owners.delete(owner);
            releaseSource(source);
          }
          cancelUnneededQueued();
        },
        destroy() {
          if (destroyed)
            return;
          destroyed = true;
          clients.delete(owner);
          for (const request of [...client.requests])
            request.cancel();
          if (!clients.size) {
            stopLastClient();
            return;
          }
          for (const source of sources.values()) {
            source.owners.delete(owner);
            releaseSource(source);
          }
          cancelUnneededQueued();
          stopIfUnused();
        }
      });
    },
    diagnostics
  };
};
var sharedPool = createPhysicalPreparationPool();
var physicalPreparationDiagnostics = sharedPool.diagnostics;

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/types.ts
var defaultPhysicalSceneView = (levels) => ({ mode: "2d", levelId: levels[0]?.id ?? "all", cutaway: true, separation: 0, detail: "auto", live: true, surroundings: false });

// ../../../Leitbild-campus-integration/apps/world/src/ui/map/physical-scene/gl-state.ts
var captureSceneGlState = (gl) => {
  const activeTexture = gl.getParameter(gl.ACTIVE_TEXTURE);
  gl.activeTexture(gl.TEXTURE0);
  const texture0 = gl.getParameter(gl.TEXTURE_BINDING_2D);
  const sampler0 = gl.getParameter(gl.SAMPLER_BINDING);
  gl.activeTexture(gl.TEXTURE1);
  const texture1 = gl.getParameter(gl.TEXTURE_BINDING_2D);
  const sampler1 = gl.getParameter(gl.SAMPLER_BINDING);
  gl.activeTexture(activeTexture);
  return {
    activeTexture,
    texture0,
    texture1,
    sampler0,
    sampler1,
    drawFramebuffer: gl.getParameter(gl.DRAW_FRAMEBUFFER_BINDING),
    readFramebuffer: gl.getParameter(gl.READ_FRAMEBUFFER_BINDING),
    renderbuffer: gl.getParameter(gl.RENDERBUFFER_BINDING),
    viewport: Array.from(gl.getParameter(gl.VIEWPORT)),
    scissor: gl.isEnabled(gl.SCISSOR_TEST),
    depthRange: Array.from(gl.getParameter(gl.DEPTH_RANGE)),
    clearColor: Array.from(gl.getParameter(gl.COLOR_CLEAR_VALUE)),
    clearDepth: gl.getParameter(gl.DEPTH_CLEAR_VALUE),
    program: gl.getParameter(gl.CURRENT_PROGRAM),
    vao: gl.getParameter(gl.VERTEX_ARRAY_BINDING),
    arrayBuffer: gl.getParameter(gl.ARRAY_BUFFER_BINDING),
    depthTest: gl.isEnabled(gl.DEPTH_TEST),
    depthFunction: gl.getParameter(gl.DEPTH_FUNC),
    depthMask: gl.getParameter(gl.DEPTH_WRITEMASK),
    blend: gl.isEnabled(gl.BLEND),
    blendEquationRgb: gl.getParameter(gl.BLEND_EQUATION_RGB),
    blendEquationAlpha: gl.getParameter(gl.BLEND_EQUATION_ALPHA),
    blendSrcRgb: gl.getParameter(gl.BLEND_SRC_RGB),
    blendDstRgb: gl.getParameter(gl.BLEND_DST_RGB),
    blendSrcAlpha: gl.getParameter(gl.BLEND_SRC_ALPHA),
    blendDstAlpha: gl.getParameter(gl.BLEND_DST_ALPHA),
    lineWidth: gl.getParameter(gl.LINE_WIDTH),
    cull: gl.isEnabled(gl.CULL_FACE),
    stencil: gl.isEnabled(gl.STENCIL_TEST),
    polygonOffset: gl.isEnabled(gl.POLYGON_OFFSET_FILL),
    polygonFactor: gl.getParameter(gl.POLYGON_OFFSET_FACTOR),
    polygonUnits: gl.getParameter(gl.POLYGON_OFFSET_UNITS),
    colorMask: gl.getParameter(gl.COLOR_WRITEMASK)
  };
};
var restoreSceneGlState = (gl, state) => {
  const toggle = (capability, enabled) => enabled ? gl.enable(capability) : gl.disable(capability);
  gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, state.drawFramebuffer);
  gl.bindFramebuffer(gl.READ_FRAMEBUFFER, state.readFramebuffer);
  gl.bindRenderbuffer(gl.RENDERBUFFER, state.renderbuffer);
  gl.viewport(...state.viewport);
  toggle(gl.SCISSOR_TEST, state.scissor);
  gl.depthRange(...state.depthRange);
  gl.clearColor(...state.clearColor);
  gl.clearDepth(state.clearDepth);
  gl.useProgram(state.program);
  gl.bindVertexArray(state.vao);
  gl.bindBuffer(gl.ARRAY_BUFFER, state.arrayBuffer);
  toggle(gl.DEPTH_TEST, state.depthTest);
  gl.depthFunc(state.depthFunction);
  gl.depthMask(state.depthMask);
  toggle(gl.BLEND, state.blend);
  gl.blendEquationSeparate(state.blendEquationRgb, state.blendEquationAlpha);
  gl.blendFuncSeparate(state.blendSrcRgb, state.blendDstRgb, state.blendSrcAlpha, state.blendDstAlpha);
  gl.lineWidth(state.lineWidth);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, state.texture0);
  gl.activeTexture(gl.TEXTURE1);
  gl.bindTexture(gl.TEXTURE_2D, state.texture1);
  gl.bindSampler(0, state.sampler0);
  gl.bindSampler(1, state.sampler1);
  gl.activeTexture(state.activeTexture);
  toggle(gl.CULL_FACE, state.cull);
  toggle(gl.STENCIL_TEST, state.stencil);
  toggle(gl.POLYGON_OFFSET_FILL, state.polygonOffset);
  gl.polygonOffset(state.polygonFactor, state.polygonUnits);
  gl.colorMask(...state.colorMask);
};

// tests/browser/physical-scene/gl-probes.ts
var fullGlState = (gl) => {
  const parameters = ["CURRENT_PROGRAM", "VERTEX_ARRAY_BINDING", "ARRAY_BUFFER_BINDING", "FRAMEBUFFER_BINDING", "READ_FRAMEBUFFER_BINDING", "RENDERBUFFER_BINDING", "VIEWPORT", "SCISSOR_BOX", "DEPTH_FUNC", "DEPTH_WRITEMASK", "DEPTH_RANGE", "BLEND_SRC_RGB", "BLEND_DST_RGB", "BLEND_SRC_ALPHA", "BLEND_DST_ALPHA", "BLEND_EQUATION_RGB", "BLEND_EQUATION_ALPHA", "BLEND_COLOR", "CULL_FACE_MODE", "FRONT_FACE", "STENCIL_FUNC", "STENCIL_REF", "STENCIL_VALUE_MASK", "STENCIL_WRITEMASK", "STENCIL_FAIL", "STENCIL_PASS_DEPTH_FAIL", "STENCIL_PASS_DEPTH_PASS", "STENCIL_BACK_FUNC", "STENCIL_BACK_REF", "STENCIL_BACK_VALUE_MASK", "STENCIL_BACK_WRITEMASK", "STENCIL_BACK_FAIL", "STENCIL_BACK_PASS_DEPTH_FAIL", "STENCIL_BACK_PASS_DEPTH_PASS", "POLYGON_OFFSET_FACTOR", "POLYGON_OFFSET_UNITS", "COLOR_WRITEMASK", "ACTIVE_TEXTURE", "TEXTURE_BINDING_2D", "TEXTURE_BINDING_CUBE_MAP", "LINE_WIDTH", "COLOR_CLEAR_VALUE", "DEPTH_CLEAR_VALUE", "STENCIL_CLEAR_VALUE"];
  const values = new Map(parameters.map((name) => {
    const value = gl.getParameter(gl[name]);
    return [name, ArrayBuffer.isView(value) ? Array.from(value) : value];
  }));
  const active = gl.getParameter(gl.ACTIVE_TEXTURE);
  for (const unit of [gl.TEXTURE0, gl.TEXTURE1]) {
    gl.activeTexture(unit);
    values.set(`texture2D/${unit}`, gl.getParameter(gl.TEXTURE_BINDING_2D));
    values.set(`sampler/${unit}`, gl.getParameter(gl.SAMPLER_BINDING));
  }
  gl.activeTexture(active);
  for (const name of ["SCISSOR_TEST", "DEPTH_TEST", "BLEND", "CULL_FACE", "STENCIL_TEST", "POLYGON_OFFSET_FILL", "DITHER"])
    values.set(name, gl.isEnabled(gl[name]));
  return values;
};
var stateDifferences = (a, b) => [...a].flatMap(([key, value]) => {
  const other = b.get(key);
  return Array.isArray(value) && Array.isArray(other) ? JSON.stringify(value) === JSON.stringify(other) ? [] : [key] : value === other ? [] : [key];
});

// tests/browser/physical-scene/visible-index-probe.ts
var canvas = document.querySelector("canvas");
var gl = canvas.getContext("webgl2", { antialias: false, preserveDrawingBuffer: true });
if (!gl)
  throw Error("Visible-index differential fixture needs WebGL2");
canvas.width = canvas.height = 160 * devicePixelRatio;
var unit = new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
var palette = { materials: { red: [1, 0, 0], green: [0, 1, 0], blue: [0, 0, 1] }, defaultMaterial: [0.1, 0.2, 0.3], line: [0.1, 0.1, 0.1], lineOpacity: 0.37, contextLineOpacity: 0.19 };
var source = (id, architecture = false) => ({
  id,
  revision: "test-only-visible-index",
  targetObjectId: id,
  anchor: [0, 0],
  bearing: 0,
  bounds: { min: [-1, -1, -1], max: [1, 1, 1] },
  levels: [{ id: "ground", label: "Ground", elevation: -1, cutHeight: 2 }],
  objects: ["red", "green", "blue"].map((material, index) => {
    const x = -0.88 + index * 0.51, right = x + 0.7, z = 0.3 - index * 0.2;
    return {
      id: `${id}/${material}`,
      label: material,
      kind: architecture ? index === 0 ? "wall" : index === 1 ? "slab" : "equipment" : "equipment",
      levelId: "site",
      subjectIds: [`${id}/${material}`],
      materials: [material],
      positions: [x, -0.66, z, right, -0.66, z, right, 0.66, z, x, -0.66, z, right, 0.66, z, x, 0.66, z],
      normals: Array.from({ length: 6 }, () => [0, 0, 1]).flat(),
      edgePolicy: "authored",
      featureLines: [{ material: "line", positions: [x, -0.66, z, right, -0.66, z, right, -0.66, z, right, 0.66, z, right, 0.66, z, x, 0.66, z, x, 0.66, z, x, -0.66, z, x, -0.66, z, right, 0.66, z] }]
    };
  })
});
var prepare = (scene) => preparePhysicalGeometry(scene, { ...defaultPhysicalSceneView(scene.levels), mode: "3d", levelId: "all", cutaway: false }, scene.id, scene.id);
var asset = prepare(source("family"));
var foreign = prepare(source("foreign"));
var archAsset = prepare(source("architecture", true));
var actual = createPhysicalBackend(gl, palette);
var reference = createPhysicalBackend2(gl, palette);
var ordered = createPhysicalArchitectureBackend(gl, palette);
var pass = createPhysicalRenderPass(gl);
var indexMetrics = () => actual.metrics;
var expectIndices = Boolean(window.visibleIndexConfig?.expectIndices);
var host = fullGlState(gl);
var results = [];
var matrix = (x = 0, y = 0, scale = 1) => {
  const value = unit.slice();
  value[0] = value[5] = scale;
  value[12] = x;
  value[13] = y;
  return value;
};
var draw = (key, selected, offset = matrix(), from = asset) => ({ sceneId: key, asset: from, meshes: selected.map((index) => from.meshes[index]), styles: [], matrix: offset, flat: true, architecture: { wallOpacity: 1, floorOpacity: 1 } });
var all = [0, 1, 2];
var capture = (backend, draws, fractional = false) => {
  const saved = captureSceneGlState(gl);
  try {
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.disable(gl.SCISSOR_TEST);
    gl.colorMask(true, true, true, true);
    gl.clearColor(1, 1, 1, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);
    pass.begin(canvas.width, canvas.height);
    backend.draw(fractional ? ordered.opaqueDraws(draws) : draws);
    if (fractional)
      ordered.draw(draws, 0, unit);
    pass.composite(null, null, [0, 0, canvas.width, canvas.height]);
    const pixels = new Uint8Array(canvas.width * canvas.height * 4);
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER, null);
    gl.readPixels(0, 0, canvas.width, canvas.height, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
    return pixels;
  } finally {
    restoreSceneGlState(gl, saved);
  }
};
var compare2 = (name, draws, fractional = false, allowEmpty = false) => {
  const before = fullGlState(gl), a = capture(reference, draws, fractional), b = capture(actual, draws, fractional);
  let differentPixels = 0, maximum = 0, painted = 0;
  for (let at = 0;at < a.length; at += 4) {
    let different = false;
    for (let channel = 0;channel < 4; channel++) {
      const d = Math.abs(a[at + channel] - b[at + channel]);
      if (d)
        different = true;
      maximum = Math.max(maximum, d);
    }
    if (different)
      differentPixels++;
    if (a[at] !== 255 || a[at + 1] !== 255 || a[at + 2] !== 255)
      painted++;
  }
  const state = stateDifferences(before, fullGlState(gl)), error = gl.getError();
  results.push({ name, differentPixels, maximum, painted, state, error, passed: differentPixels === 0 && (allowEmpty || painted > 0) && !state.length && !error });
};
for (let mask = 0;mask < 8; mask++)
  compare2(`every-visible-subset-${mask}`, [draw("one", all.filter((index) => mask & 1 << index))], false, mask === 0);
compare2("contiguous-instances-different-masks", [draw("A", [0], matrix(-0.42, 0, 0.54)), draw("B", [1, 2], matrix(0.42, 0, 0.54))]);
compare2("contiguous-instances-same-union-reversed-masks", [draw("A", [1, 2], matrix(-0.42, 0, 0.54)), draw("B", [0], matrix(0.42, 0, 0.54))]);
compare2("A1-foreign-B-A2-native-coplanar-order", [draw("A1", [0, 2]), draw("foreign-B", [0, 1, 2], matrix(), foreign), draw("A2", [1, 2])]);
compare2("A2-foreign-B-A1-native-coplanar-order", [draw("A2", [1, 2]), draw("foreign-B", [0, 1, 2], matrix(), foreign), draw("A1", [0, 2])]);
compare2("offscreen-and-clipped-native-lines", [draw("left", [0, 2], matrix(-0.7, 0.2, 1.3)), draw("right", [1], matrix(0.9, -0.2, 0.6))]);
var stable = [draw("warm", all)];
var uploads = actual.metrics.statusUploads;
compare2("warm-current-metadata", stable);
var warmedUploads = actual.metrics.statusUploads;
var warmedVisibility = indexMetrics().visibilityUploads;
var warmedIndexBytes = indexMetrics().indexBytes;
compare2("camera-only-stable-metadata", [{ ...stable[0], matrix: matrix(0.05, 0.03, 0.91) }]);
var cameraUploads = actual.metrics.statusUploads;
var cameraVisibility = indexMetrics().visibilityUploads;
var cameraIndexBytes = indexMetrics().indexBytes;
results.push({ name: "camera-does-not-upload-owner-metadata-or-indices", uploads, warmedUploads, cameraUploads, warmedVisibility, cameraVisibility, warmedIndexBytes, cameraIndexBytes, residentCpuBytes: actual.metrics.residentCpuBytes, expectIndices, passed: cameraUploads === warmedUploads && (!expectIndices || typeof warmedVisibility === "number" && cameraVisibility === warmedVisibility && typeof warmedIndexBytes === "number" && warmedIndexBytes > 0 && cameraIndexBytes === warmedIndexBytes) });
compare2("status-only-original-authored-contours", [{ ...stable[0], styles: asset.meshes.map(() => ({ color: [0.8, 0.1, 0.6], emphasis: 0.65 })) }]);
compare2("highlight-occurrence-and-colour", [{ ...stable[0], highlight: { sceneId: "warm", occurrenceId: asset.meshes[1].object.id, color: [0.2, 0.8, 0.9] } }]);
compare2("highlight-colour-changes-on-same-occurrence", [{ ...stable[0], highlight: { sceneId: "warm", occurrenceId: asset.meshes[1].object.id, color: [0.9, 0.8, 0.2] } }]);
var dusk = { ...palette, materials: { red: [0.42, 0.12, 0.1], green: [0.1, 0.35, 0.2], blue: [0.1, 0.2, 0.49] }, line: [0.8, 0.85, 0.7], defaultMaterial: [0.6, 0.7, 0.8] };
actual.setPalette(dusk);
reference.setPalette(dusk);
compare2("palette-theme-and-fallback", stable);
actual.setPalette(palette);
reference.setPalette(palette);
var architectural = [draw("architecture", all, unit, archAsset)];
compare2("architecture-full-opacity", architectural);
compare2("ordinary-alpha-uses-actual-Float32-row", [{ ...architectural[0], architecture: { wallOpacity: 1 - 2 ** -26, floorOpacity: 1 } }]);
compare2("architecture-zero-opacity", [{ ...architectural[0], architecture: { wallOpacity: 0, floorOpacity: 0 } }]);
var archOwners = archAsset.meshes.flatMap((mesh, meshIndex) => mesh.object.kind === "wall" || mesh.object.kind === "slab" ? [{ mesh, meshIndex }] : []);
ordered.setAsset(preparePhysicalArchitectureBsp({ key: "visible-index-cohort", sources: archOwners.map(({ mesh, meshIndex }) => ({ id: `owner/${meshIndex}`, sceneId: "architecture", assetKey: archAsset.key, meshIndex, occurrenceId: mesh.object.id, matrix: new Float64Array(unit), vertices: mesh.vertices, lines: mesh.lines, materials: mesh.materials ?? mesh.object.materials ?? [], lineMaterials: mesh.lineMaterials ?? Array.from({ length: mesh.lines.length / 6 }, () => "line"), ...mesh.lineStyles ? { lineStyles: mesh.lineStyles } : {} })) }));
compare2("fractional-global-architecture-handoff", [{ ...architectural[0], architecture: { wallOpacity: 0.4, floorOpacity: 1 } }], true);
compare2("fractional-and-zero-global-architecture-handoff", [{ ...architectural[0], architecture: { wallOpacity: 0, floorOpacity: 0.4 } }], true);
var beforeWithdrawal = { ...indexMetrics() };
compare2("withdraw-all-current-instance-runs", [], false, true);
results.push({ name: "withdrawn-run-releases-current-index-packets", before: beforeWithdrawal.indexBytes, after: indexMetrics().indexBytes, residentCpuBytes: actual.metrics.residentCpuBytes, expectIndices, passed: !expectIndices || indexMetrics().indexBytes === 0 });
var metrics = { actual: { ...actual.metrics }, beforeWithdrawal, reference: { ...reference.metrics }, ordered: ordered.metrics(), pass: pass.metrics() };
actual.dispose();
reference.dispose();
ordered.dispose();
pass.dispose();
var disposal = { actual: { buffers: actual.metrics.liveBuffersAfterDisposal, programs: actual.metrics.liveProgramsAfterDisposal, textures: actual.metrics.liveTexturesAfterDisposal, residentCpuBytes: actual.metrics.residentCpuBytes, indexBytes: indexMetrics().indexBytes ?? 0 }, reference: { buffers: reference.metrics.liveBuffersAfterDisposal, programs: reference.metrics.liveProgramsAfterDisposal, textures: reference.metrics.liveTexturesAfterDisposal }, ordered: ordered.metrics(), pass: pass.metrics() };
var released2 = Object.values(disposal.actual).every((value) => value === 0) && Object.values(disposal.reference).every((value) => value === 0) && disposal.ordered.liveBuffersAfterDisposal === 0 && disposal.ordered.liveProgramsAfterDisposal === 0 && disposal.ordered.liveTexturesAfterDisposal === 0 && disposal.pass.liveTextures === 0 && disposal.pass.livePrograms === 0 && disposal.pass.liveFramebuffers === 0 && disposal.pass.liveRenderbuffers === 0;
var hostState = stateDifferences(host, fullGlState(gl));
window.visibleIndexProof = { passed: results.every((value) => value.passed) && released2 && !hostState.length, results, metrics, disposal, hostState, dpr: devicePixelRatio, samples: metrics.pass.samples };
